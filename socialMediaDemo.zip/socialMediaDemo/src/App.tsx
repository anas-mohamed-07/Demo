import { useEffect } from 'react';
import { Navigation } from './pages/navigation';

import { Footer } from './pages/footer';
import { environmentConfig } from './pages/environment_config';
import { HomePage } from './pages/home_page';
import { AboutPage } from './pages/about_page';
import { BookingsPage } from './pages/booking_page';
import { GrantsPage } from './pages/grants_page';
import { GalleryPage } from './pages/gallery_page';
import { DonationPage } from './pages/donation_page';
import { ContactPage } from './pages/contact_page';
import { LocalizationProvider } from './pages/localization_context';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import "../src/assets/styles/globals.css";

export default function App() {
  useEffect(() => {
    environmentConfig.logConfigurationStatus();
  }, []);

  return (
    <BrowserRouter>
      <LocalizationProvider>
        <div className="min-h-screen flex flex-col">
          <Navigation />
          <Routes>
            <Route path={''} element={<HomePage />} />
            <Route path={'/about'} element={<AboutPage />} />
            <Route path={'/bookings'} element={<BookingsPage />} />
            <Route path={'/grants'} element={<GrantsPage />} />
            <Route path={'/gallery'} element={<GalleryPage />} />
            <Route path={'/donation'} element={<DonationPage />} />
            <Route path={'/contact'} element={<ContactPage />} />
          </Routes>
          <Footer />
        </div>
      </LocalizationProvider>
    </BrowserRouter>
  );
}