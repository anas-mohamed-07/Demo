// Firebase Integration Example for Arulmigu Anjaneya Aalayam
// This file shows how to replace localStorage with Firebase Firestore

import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit,
  updateDoc,
  doc,
  deleteDoc,
  onSnapshot,
  Timestamp 
} from 'firebase/firestore';

// Firebase configuration (replace with your actual config)
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "anjaneya-aalayam.firebaseapp.com",
  projectId: "anjaneya-aalayam",
  storageBucket: "anjaneya-aalayam.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Updated Booking interface for Firebase
export interface FirebaseBooking {
  id?: string; // Firestore document ID
  sevaId: string;
  sevaName: string;
  date: string;
  time: string;
  devoteeName: string;
  phone: string;
  email: string;
  amount: number;
  transactionId?: string;
  paymentStatus?: 'pending' | 'paid' | 'failed' | 'refunded';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

// Updated BookingService with Firebase integration
export class FirebaseBookingService {
  private static instance: FirebaseBookingService;
  private db = db;

  private constructor() {}

  public static getInstance(): FirebaseBookingService {
    if (!FirebaseBookingService.instance) {
      FirebaseBookingService.instance = new FirebaseBookingService();
    }
    return FirebaseBookingService.instance;
  }

  // Create a new booking
  async makeBooking(booking: Omit<FirebaseBooking, 'id' | 'createdAt' | 'updatedAt'>): Promise<{
    success: boolean;
    message: string;
    bookingId?: string;
  }> {
    try {
      // Check availability first
      const availability = await this.getAvailableSlots(booking.sevaId, new Date(booking.date));
      if (!availability.isAvailable && booking.paymentStatus === 'paid') {
        return {
          success: false,
          message: 'No slots available for this seva on the selected date'
        };
      }

      // Create booking document
      const bookingData = {
        ...booking,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now()
      };

      const docRef = await addDoc(collection(this.db, 'bookings'), bookingData);

      // Generate a readable booking ID
      const readableId = `BK${Date.now()}${Math.random().toString(36).substr(2, 6)}`;
      await updateDoc(docRef, { readableId });

      return {
        success: true,
        message: booking.paymentStatus === 'paid' ? 'Booking confirmed successfully!' : 'Booking created successfully!',
        bookingId: readableId
      };
    } catch (error) {
      console.error('Error creating booking:', error);
      return {
        success: false,
        message: 'Failed to create booking. Please try again.'
      };
    }
  }

  // Get available slots for a seva on a specific date
  async getAvailableSlots(sevaId: string, date: Date): Promise<{
    available: number;
    total: number;
    isAvailable: boolean;
  }> {
    try {
      // Get seva configuration (this would also be in Firestore in production)
      const sevaConfig = this.getSevaConfigById(sevaId);
      if (!sevaConfig) {
        return { available: 0, total: 0, isAvailable: false };
      }

      // Get bookings for this seva on this date
      const dateString = date.toISOString().split('T')[0];
      const q = query(
        collection(this.db, 'bookings'),
        where('sevaId', '==', sevaId),
        where('date', '==', dateString),
        where('paymentStatus', '!=', 'failed')
      );

      const querySnapshot = await getDocs(q);
      const bookingsCount = querySnapshot.size;

      const available = sevaConfig.dailyLimit - bookingsCount;
      return {
        available: Math.max(0, available),
        total: sevaConfig.dailyLimit,
        isAvailable: available > 0
      };
    } catch (error) {
      console.error('Error checking availability:', error);
      return { available: 0, total: 0, isAvailable: false };
    }
  }

  // Get all bookings with optional filters
  async getBookings(filters?: {
    sevaId?: string;
    date?: string;
    devoteeName?: string;
    paymentStatus?: string;
    limit?: number;
  }): Promise<FirebaseBooking[]> {
    try {
      let q = query(collection(this.db, 'bookings'));

      // Apply filters
      if (filters?.sevaId) {
        q = query(q, where('sevaId', '==', filters.sevaId));
      }
      if (filters?.date) {
        q = query(q, where('date', '==', filters.date));
      }
      if (filters?.paymentStatus) {
        q = query(q, where('paymentStatus', '==', filters.paymentStatus));
      }

      // Order by creation date (newest first)
      q = query(q, orderBy('createdAt', 'desc'));

      // Apply limit
      if (filters?.limit) {
        q = query(q, limit(filters.limit));
      }

      const querySnapshot = await getDocs(q);
      const bookings: FirebaseBooking[] = [];

      querySnapshot.forEach((doc) => {
        bookings.push({
          id: doc.id,
          ...doc.data()
        } as FirebaseBooking);
      });

      // Client-side filtering for devotee name (Firestore doesn't support case-insensitive search)
      if (filters?.devoteeName) {
        return bookings.filter(booking =>
          booking.devoteeName.toLowerCase().includes(filters.devoteeName!.toLowerCase())
        );
      }

      return bookings;
    } catch (error) {
      console.error('Error fetching bookings:', error);
      return [];
    }
  }

  // Update booking payment status
  async updateBookingPaymentStatus(
    bookingId: string,
    status: 'pending' | 'paid' | 'failed' | 'refunded',
    transactionId?: string
  ): Promise<{ success: boolean; message: string }> {
    try {
      // Find booking by readable ID
      const q = query(
        collection(this.db, 'bookings'),
        where('readableId', '==', bookingId)
      );
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        return { success: false, message: 'Booking not found' };
      }

      const bookingDoc = querySnapshot.docs[0];
      const updateData: any = {
        paymentStatus: status,
        updatedAt: Timestamp.now()
      };

      if (transactionId) {
        updateData.transactionId = transactionId;
      }

      await updateDoc(bookingDoc.ref, updateData);

      return { success: true, message: 'Payment status updated successfully' };
    } catch (error) {
      console.error('Error updating payment status:', error);
      return { success: false, message: 'Failed to update payment status' };
    }
  }

  // Get booking by transaction ID
  async getBookingByTransactionId(transactionId: string): Promise<FirebaseBooking | null> {
    try {
      const q = query(
        collection(this.db, 'bookings'),
        where('transactionId', '==', transactionId)
      );
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        return null;
      }

      const doc = querySnapshot.docs[0];
      return {
        id: doc.id,
        ...doc.data()
      } as FirebaseBooking;
    } catch (error) {
      console.error('Error fetching booking by transaction ID:', error);
      return null;
    }
  }

  // Cancel booking
  async cancelBooking(bookingId: string): Promise<{ success: boolean; message: string }> {
    try {
      const q = query(
        collection(this.db, 'bookings'),
        where('readableId', '==', bookingId)
      );
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        return { success: false, message: 'Booking not found' };
      }

      const bookingDoc = querySnapshot.docs[0];
      const booking = bookingDoc.data() as FirebaseBooking;

      // If booking was paid, mark for refund instead of deleting
      if (booking.paymentStatus === 'paid') {
        await updateDoc(bookingDoc.ref, {
          paymentStatus: 'refunded',
          updatedAt: Timestamp.now()
        });
        return { success: true, message: 'Booking cancelled and refund initiated' };
      } else {
        await deleteDoc(bookingDoc.ref);
        return { success: true, message: 'Booking cancelled successfully' };
      }
    } catch (error) {
      console.error('Error cancelling booking:', error);
      return { success: false, message: 'Failed to cancel booking' };
    }
  }

  // Get booking statistics
  async getBookingStats(dateRange?: { start: Date; end: Date }): Promise<{
    totalBookings: number;
    paidBookings: number;
    totalRevenue: number;
    pendingPayments: number;
    sevaBreakdown: Record<string, { count: number; revenue: number; pending: number }>;
  }> {
    try {
      let q = query(collection(this.db, 'bookings'));

      // Apply date range filter
      if (dateRange) {
        const startDate = dateRange.start.toISOString().split('T')[0];
        const endDate = dateRange.end.toISOString().split('T')[0];
        // Note: Firestore range queries need composite indexes
        q = query(q, where('date', '>=', startDate), where('date', '<=', endDate));
      }

      const querySnapshot = await getDocs(q);
      const bookings: FirebaseBooking[] = [];

      querySnapshot.forEach((doc) => {
        bookings.push(doc.data() as FirebaseBooking);
      });

      // Calculate statistics
      const paidBookings = bookings.filter(booking => booking.paymentStatus === 'paid');
      const pendingBookings = bookings.filter(booking => booking.paymentStatus === 'pending');

      const stats = {
        totalBookings: bookings.length,
        paidBookings: paidBookings.length,
        totalRevenue: paidBookings.reduce((sum, booking) => sum + booking.amount, 0),
        pendingPayments: pendingBookings.length,
        sevaBreakdown: {} as Record<string, { count: number; revenue: number; pending: number }>
      };

      // Calculate seva breakdown
      bookings.forEach(booking => {
        if (!stats.sevaBreakdown[booking.sevaId]) {
          stats.sevaBreakdown[booking.sevaId] = { count: 0, revenue: 0, pending: 0 };
        }
        stats.sevaBreakdown[booking.sevaId].count++;

        if (booking.paymentStatus === 'paid') {
          stats.sevaBreakdown[booking.sevaId].revenue += booking.amount;
        } else if (booking.paymentStatus === 'pending') {
          stats.sevaBreakdown[booking.sevaId].pending++;
        }
      });

      return stats;
    } catch (error) {
      console.error('Error fetching booking statistics:', error);
      return {
        totalBookings: 0,
        paidBookings: 0,
        totalRevenue: 0,
        pendingPayments: 0,
        sevaBreakdown: {}
      };
    }
  }

  // Real-time listener for bookings (useful for admin dashboard)
  subscribeToBookings(
    callback: (bookings: FirebaseBooking[]) => void,
    filters?: { sevaId?: string; date?: string }
  ): () => void {
    let q = query(collection(this.db, 'bookings'));

    if (filters?.sevaId) {
      q = query(q, where('sevaId', '==', filters.sevaId));
    }
    if (filters?.date) {
      q = query(q, where('date', '==', filters.date));
    }

    q = query(q, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const bookings: FirebaseBooking[] = [];
      querySnapshot.forEach((doc) => {
        bookings.push({
          id: doc.id,
          ...doc.data()
        } as FirebaseBooking);
      });
      callback(bookings);
    });

    return unsubscribe;
  }

  // Helper method to get seva configuration (should also be in Firestore)
  private getSevaConfigById(sevaId: string): { dailyLimit: number } | null {
    const sevaConfigs: Record<string, { dailyLimit: number }> = {
      'thirumanjanam': { dailyLimit: 10 },
      'vadamalai': { dailyLimit: 50 },
      'santhana-kaapu': { dailyLimit: 10 },
      'vennai-kaapu': { dailyLimit: 10 },
      'senthoora-kaapu': { dailyLimit: 10 }
    };

    return sevaConfigs[sevaId] || null;
  }
}

// Export singleton instance
export const firebaseBookingService = FirebaseBookingService.getInstance();

// Firebase Security Rules (to be added in Firebase Console)
const firestoreSecurityRules = `
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Allow read access to bookings for authenticated users
    match /bookings/{bookingId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    
    // Allow read access to seva configurations for everyone
    match /sevas/{sevaId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    // Allow read access to temple settings for everyone
    match /settings/{settingId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
`;

// Usage example in React component
const ExampleUsage = () => {
  const [bookings, setBookings] = useState<FirebaseBooking[]>([]);
  const bookingService = FirebaseBookingService.getInstance();

  useEffect(() => {
    // Load bookings
    const loadBookings = async () => {
      const data = await bookingService.getBookings({ limit: 10 });
      setBookings(data);
    };

    loadBookings();

    // Set up real-time listener
    const unsubscribe = bookingService.subscribeToBookings((newBookings) => {
      setBookings(newBookings);
    });

    return () => unsubscribe();
  }, []);

  const handleNewBooking = async (bookingData: any) => {
    const result = await bookingService.makeBooking(bookingData);
    if (result.success) {
      console.log('Booking created:', result.bookingId);
    } else {
      console.error('Booking failed:', result.message);
    }
  };

  return (
    <div>
      <h2>Bookings</h2>
      {bookings.map(booking => (
        <div key={booking.id}>
          {booking.devoteeName} - {booking.sevaName} - {booking.date}
        </div>
      ))}
    </div>
  );
};