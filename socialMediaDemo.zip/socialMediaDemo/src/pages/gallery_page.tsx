import { useEffect, useState } from 'react';
import { Button } from '../components/button';
// import { Dialog, DialogContent, DialogTrigger } from '../components/dialog';
import { Card } from '../components/Card';
import { ImageWithFallback } from '../components/ImageWithFallback';


export function GalleryPage() {
  const [selectedFilter, setSelectedFilter] = useState('all');

  const galleryImages = [
    {
      id: 1,
      src: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop',
      alt: 'Vennai Kaapu Ceremony',
      category: 'vennai-kaapu',
      title: 'Vennai Kaapu'
    },
    {
      id: 2,
      src: 'https://images.unsplash.com/photo-1604623842888-8ab8cf339ead?w=800&h=600&fit=crop',
      alt: 'Santhana Kaapu Ritual',
      category: 'santhana-kaapu',
      title: 'Santhana Kaapu'
    },
    {
      id: 3,
      src: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=800&h=600&fit=crop',
      alt: 'Temple Exterior',
      category: 'temple-exterior',
      title: 'Temple Entrance'
    },
    {
      id: 4,
      src: 'https://images.unsplash.com/photo-1566996533071-82ad21517ea7?w=800&h=600&fit=crop',
      alt: 'Senthoora Kaapu',
      category: 'senthoora-kaapu',
      title: 'Senthoora Kaapu'
    },
    {
      id: 5,
      src: 'https://images.unsplash.com/photo-1599501900915-c5f6b9a5e0b6?w=800&h=600&fit=crop',
      alt: 'Thirumanjanam',
      category: 'thirumanjanam',
      title: 'Thirumanjanam'
    },
    {
      id: 6,
      src: 'https://images.unsplash.com/photo-1580500282019-1b699b5c30d0?w=800&h=600&fit=crop',
      alt: 'Vadamalai Ceremony',
      category: 'vadamalai',
      title: 'Vadamalai'
    },
    {
      id: 7,
      src: 'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=800&h=600&fit=crop',
      alt: 'Festival Celebration',
      category: 'festivals',
      title: 'Festival Celebrations'
    },
    {
      id: 8,
      src: 'https://images.unsplash.com/photo-1543719727-2b47c5eaf162?w=800&h=600&fit=crop',
      alt: 'Temple Interior',
      category: 'temple-interior',
      title: 'Main Sanctum'
    },
    {
      id: 9,
      src: 'https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=800&h=600&fit=crop',
      alt: 'Evening Aarti',
      category: 'daily-rituals',
      title: 'Evening Aarti'
    }
  ];

  const filters = [
    { id: 'all', label: 'All Images' },
    { id: 'vennai-kaapu', label: 'Vennai Kaapu' },
    { id: 'santhana-kaapu', label: 'Santhana Kaapu' },
    { id: 'senthoora-kaapu', label: 'Senthoora Kaapu' },
    { id: 'thirumanjanam', label: 'Thirumanjanam' },
    { id: 'vadamalai', label: 'Vadamalai' },
    { id: 'festivals', label: 'Festivals' },
    { id: 'temple-exterior', label: 'Temple Exterior' },
    { id: 'temple-interior', label: 'Temple Interior' },
    { id: 'daily-rituals', label: 'Daily Rituals' }
  ];

  const filteredImages = selectedFilter === 'all'
    ? galleryImages
    : galleryImages.filter(image => image.category === selectedFilter);


  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [])
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-[var(--temple-dark-brown)]">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[var(--temple-dark-brown)]">Temple Gallery</h1>
          <p className="text-xl text-[var(--temple-dark-brown)]/80">Experience the Divine Beauty of Our Sacred Ceremonies</p>
        </div>
      </div>

      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Filter Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Browse by Category</h2>
          <div className="flex flex-wrap justify-center gap-2">
            {filters.map((filter) => (
              <Button
                key={filter.id}
                variant={selectedFilter === filter.id ? "default" : "outline"}
                onClick={() => setSelectedFilter(filter.id)}
                className={selectedFilter === filter.id
                  ? "bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
                  : "border-[var(--temple-saffron)] text-[var(--temple-saffron)] hover:bg-[var(--temple-saffron)] hover:text-white"
                }
              >
                {filter.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredImages.map((image) => (
            <img src={image.src} />
            // <Dialog key={image.id}>
            //   <DialogTrigger>
            //     <Card className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow divine-glow">
            //       <div className="aspect-square relative group">
            //         <ImageWithFallback
            //           src={image.src}
            //           alt={image.alt}
            //           className="w-full h-full object-cover transition-transform group-hover:scale-105"
            //         />
            //         <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-70 transition-opacity">
            //           <div className="absolute bottom-4 left-4 text-white">
            //             <h3 className="font-semibold">{image.title}</h3>
            //           </div>
            //         </div>
            //       </div>
            //     </Card>
            //   </DialogTrigger>
            //   <DialogContent className="max-w-4xl">
            //     <div className="relative">
            //       <ImageWithFallback
            //         src={image.src}
            //         alt={image.alt}
            //         className="w-full h-auto max-h-[80vh] object-contain"
            //       />
            //       <div className="mt-4 text-center">
            //         <h3 className="text-xl font-semibold text-[var(--temple-saffron)]">{image.title}</h3>
            //         <p className="text-gray-600 mt-2">{image.alt}</p>
            //       </div>
            //     </div>
            //   </DialogContent>
            // </Dialog>
          ))}
        </div>

        {/* Info Section */}
        <div className="mt-12 bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] rounded-lg p-8 text-[var(--temple-dark-brown)] text-center">
          <h3 className="text-2xl font-bold mb-4 text-[var(--temple-dark-brown)]">Capture Divine Moments</h3>
          <p className="text-lg text-[var(--temple-dark-brown)]/80 max-w-3xl mx-auto">
            Our gallery showcases the beautiful rituals, ceremonies, and architectural beauty of Arulmigu Anjaneya Aalayam.
            Each image captures the devotion and spiritual energy that fills our sacred space during various sevas and festivals.
          </p>
          <p className="mt-4 text-sm text-[var(--temple-dark-brown)]/70">
            For high-resolution images or photography permissions, please contact the temple administration.
          </p>
        </div>
      </div>
    </div>
  );
}