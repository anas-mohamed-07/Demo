// Payment Gateway Service with BasisPay.in Integration
// Supports BasisPay.in for production with mock fallback for development

export interface PaymentMethod {
  id: string;
  name: string;
  type: 'card' | 'upi' | 'netbanking' | 'wallet';
  icon: string;
  enabled: boolean;
}

export interface PaymentRequest {
  amount: number;
  currency: string;
  orderId: string;
  description: string;
  customerDetails: {
    name: string;
    email: string;
    phone: string;
  };
  metadata?: Record<string, any>;
}

export interface PaymentResponse {
  success: boolean;
  transactionId: string;
  orderId: string;
  amount: number;
  currency: string;
  status: 'success' | 'failed' | 'pending';
  message: string;
  gatewayResponse?: any;
  receipt?: {
    receiptId: string;
    timestamp: Date;
    paymentMethod: string;
    transactionFee: number;
  };
}

// BasisPay specific interfaces
export interface BasisPayOrder {
  id: string;
  entity: string;
  amount: number;
  currency: string;
  receipt: string;
  status: string;
  created_at: number;
  notes: Record<string, any>;
}

export interface BasisPayPayment {
  id: string;
  amount: number;
  currency: string;
  status: string;
  order_id: string;
  method: string;
  captured: boolean;
  fee: number;
  tax: number;
  created_at: number;
}

// Extend window object for BasisPay SDK
declare global {
  interface Window {
    BasisPay: any;
  }
}

export class PaymentService {
  private static instance: PaymentService;
  
  // BasisPay.in Configuration - Will be initialized in constructor
  private basisPayConfig: {
    keyId: string;
    keySecret: string;
    baseUrl: string;
    enabled: boolean;
  };

  // Safe environment variable getter for browser
  private getEnvVar(key: string, defaultValue: string): string {
    // Try different environment variable sources
    if (typeof window !== 'undefined') {
      // Browser environment - check if variables are passed via window
      const windowEnv = (window as any).__ENV__;
      if (windowEnv && windowEnv[key]) {
        return windowEnv[key];
      }
    }
    
    // Try import.meta.env (Vite)
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      const viteEnv = import.meta.env[`VITE_${key}`];
      if (viteEnv) return viteEnv;
    }
    
    // Try process.env (Node.js) - safely
    if (typeof process !== 'undefined' && process.env) {
      const nodeEnv = process.env[key];
      if (nodeEnv) return nodeEnv;
    }
    
    return defaultValue;
  }

  // Safe production check
  private isProduction(): boolean {
    // Check various ways to determine environment
    if (typeof window !== 'undefined') {
      // Browser - check hostname
      const hostname = window.location.hostname;
      if (hostname.includes('localhost') || hostname.includes('127.0.0.1')) {
        return false;
      }
    }
    
    // Try import.meta.env
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      return import.meta.env.MODE === 'production';
    }
    
    // Try process.env safely
    if (typeof process !== 'undefined' && process.env) {
      return process.env.NODE_ENV === 'production';
    }
    
    // Default to development
    return false;
  }
  
  // Mock payment methods available
  private paymentMethods: PaymentMethod[] = [
    { id: 'card', name: 'Credit/Debit Card', type: 'card', icon: '💳', enabled: true },
    { id: 'upi', name: 'UPI', type: 'upi', icon: '📱', enabled: true },
    { id: 'netbanking', name: 'Net Banking', type: 'netbanking', icon: '🏦', enabled: true },
    { id: 'paytm', name: 'Paytm Wallet', type: 'wallet', icon: '💰', enabled: true },
    { id: 'googlepay', name: 'Google Pay', type: 'upi', icon: '🔍', enabled: true },
    { id: 'phonepe', name: 'PhonePe', type: 'upi', icon: '📞', enabled: true }
  ];

  private constructor() {
    // Initialize BasisPay configuration after methods are available
    this.basisPayConfig = {
      keyId: this.getEnvVar('BASISPAY_KEY_ID', 'YOUR_BASISPAY_KEY_ID'),
      keySecret: this.getEnvVar('BASISPAY_KEY_SECRET', 'YOUR_BASISPAY_KEY_SECRET'),
      baseUrl: this.isProduction() 
        ? 'https://api.basispay.in/v1/' 
        : 'https://sandbox-api.basispay.in/v1/',
      enabled: this.getEnvVar('BASISPAY_ENABLED', 'false') === 'true'
    };

    // Log configuration for debugging (don't log sensitive data in production)
    if (!this.isProduction()) {
      console.log('[PaymentService] Configuration:', {
        enabled: this.basisPayConfig.enabled,
        baseUrl: this.basisPayConfig.baseUrl,
        hasKeyId: !!this.basisPayConfig.keyId && this.basisPayConfig.keyId !== 'YOUR_BASISPAY_KEY_ID',
        isProduction: this.isProduction()
      });
    }
  }

  // Method to update configuration at runtime
  public updateBasisPayConfig(config: Partial<{
    keyId: string;
    keySecret: string;
    enabled: boolean;
    baseUrl: string;
  }>): void {
    this.basisPayConfig = { ...this.basisPayConfig, ...config };
    console.log('[PaymentService] Configuration updated');
  }

  // Method to get current configuration status
  public getConfigurationStatus(): {
    enabled: boolean;
    configured: boolean;
    environment: 'production' | 'development';
  } {
    return {
      enabled: this.basisPayConfig.enabled,
      configured: this.basisPayConfig.keyId !== 'YOUR_BASISPAY_KEY_ID',
      environment: this.isProduction() ? 'production' : 'development'
    };
  }

  public static getInstance(): PaymentService {
    if (!PaymentService.instance) {
      PaymentService.instance = new PaymentService();
    }
    return PaymentService.instance;
  }

  public getPaymentMethods(): PaymentMethod[] {
    return this.paymentMethods.filter(method => method.enabled);
  }

  public async createOrder(request: PaymentRequest): Promise<{ success: boolean; orderId: string; message: string }> {
    if (this.basisPayConfig.enabled) {
      return this.createBasisPayOrder(request);
    } else {
      return this.createMockOrder(request);
    }
  }

  private async createBasisPayOrder(request: PaymentRequest): Promise<{ success: boolean; orderId: string; message: string }> {
    try {
      console.log('Creating BasisPay order...', request);
      
      const orderData = {
        amount: request.amount * 100, // Convert to paise
        currency: request.currency,
        receipt: `receipt_${Date.now()}`,
        notes: {
          seva_name: request.metadata?.sevaName || '',
          devotee_name: request.customerDetails.name,
          booking_date: request.metadata?.bookingDate || '',
          temple: 'Arulmigu Anjaneya Aalayam'
        },
        customer: {
          name: request.customerDetails.name,
          email: request.customerDetails.email,
          contact: request.customerDetails.phone
        },
        callback_url: `${window.location.origin}/payment-callback`,
        callback_method: 'POST'
      };

      const response = await fetch(`${this.basisPayConfig.baseUrl}orders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.basisPayConfig.keyId}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(orderData)
      });

      const data = await response.json();

      if (response.ok) {
        return {
          success: true,
          orderId: data.id,
          message: 'BasisPay order created successfully'
        };
      } else {
        console.error('BasisPay order creation failed:', data);
        return {
          success: false,
          orderId: '',
          message: data.error?.description || 'Failed to create order'
        };
      }
    } catch (error) {
      console.error('BasisPay API error:', error);
      return {
        success: false,
        orderId: '',
        message: 'Network error. Please try again.'
      };
    }
  }

  private async createMockOrder(request: PaymentRequest): Promise<{ success: boolean; orderId: string; message: string }> {
    console.log('Creating mock payment order...', request);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock successful order creation
    const orderId = `ORDER_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      orderId: orderId,
      message: 'Mock order created successfully'
    };
  }

  public async processPayment(
    orderId: string,
    paymentMethodId: string,
    paymentDetails?: any
  ): Promise<PaymentResponse> {
    if (this.basisPayConfig.enabled) {
      return this.processBasisPayPayment(orderId, paymentMethodId, paymentDetails);
    } else {
      return this.processMockPayment(orderId, paymentMethodId, paymentDetails);
    }
  }

  private async processBasisPayPayment(
    orderId: string,
    paymentMethodId: string,
    paymentDetails?: any
  ): Promise<PaymentResponse> {
    try {
      console.log('Processing BasisPay payment...', { orderId, paymentMethodId, paymentDetails });
      
      // BasisPay payment processing happens on frontend with their SDK
      // This method handles the verification after payment
      const verificationData = {
        basispay_order_id: orderId,
        basispay_payment_id: paymentDetails?.paymentId,
        basispay_signature: paymentDetails?.signature
      };

      const response = await fetch(`${this.basisPayConfig.baseUrl}payments/verify`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.basisPayConfig.keySecret}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(verificationData)
      });

      const data = await response.json();

      if (response.ok && data.status === 'success') {
        const payment = data.payment;
        const paymentMethod = this.paymentMethods.find(method => method.id === paymentMethodId);
        
        return {
          success: true,
          transactionId: payment.id,
          orderId: payment.order_id,
          amount: payment.amount / 100, // Convert from paise
          currency: payment.currency,
          status: 'success',
          message: 'Payment successful via BasisPay',
          gatewayResponse: data,
          receipt: {
            receiptId: `RCPT_${Date.now()}`,
            timestamp: new Date(),
            paymentMethod: paymentMethod?.name || payment.method,
            transactionFee: payment.fee / 100 // Convert from paise
          }
        };
      } else {
        return {
          success: false,
          transactionId: paymentDetails?.paymentId || '',
          orderId,
          amount: paymentDetails?.amount || 0,
          currency: 'INR',
          status: 'failed',
          message: 'Payment verification failed'
        };
      }
    } catch (error) {
      console.error('BasisPay payment processing error:', error);
      return {
        success: false,
        transactionId: '',
        orderId,
        amount: paymentDetails?.amount || 0,
        currency: 'INR',
        status: 'failed',
        message: 'Payment processing error. Please contact support.'
      };
    }
  }

  private async processMockPayment(
    orderId: string,
    paymentMethodId: string,
    paymentDetails?: any
  ): Promise<PaymentResponse> {
    console.log('Processing mock payment...', { orderId, paymentMethodId, paymentDetails });
    
    // Simulate payment processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock payment success/failure (90% success rate)
    const isSuccess = Math.random() > 0.1;
    const transactionId = `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    if (isSuccess) {
      const paymentMethod = this.paymentMethods.find(method => method.id === paymentMethodId);
      const transactionFee = Math.round(paymentDetails?.amount * 0.02); // 2% transaction fee
      
      return {
        success: true,
        transactionId,
        orderId,
        amount: paymentDetails?.amount || 0,
        currency: 'INR',
        status: 'success',
        message: 'Mock payment successful',
        receipt: {
          receiptId: `RCPT_${Date.now()}`,
          timestamp: new Date(),
          paymentMethod: paymentMethod?.name || 'Unknown',
          transactionFee
        }
      };
    } else {
      return {
        success: false,
        transactionId,
        orderId,
        amount: paymentDetails?.amount || 0,
        currency: 'INR',
        status: 'failed',
        message: 'Mock payment failed. Please try again or use a different payment method.'
      };
    }
  }

  public async verifyPayment(transactionId: string): Promise<{ success: boolean; verified: boolean; message: string }> {
    // Mock payment verification
    // In real implementation, this would verify the payment with the gateway
    
    console.log('Verifying payment...', transactionId);
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      success: true,
      verified: true,
      message: 'Payment verified successfully'
    };
  }

  public async refundPayment(
    transactionId: string,
    amount?: number,
    reason?: string
  ): Promise<{ success: boolean; refundId?: string; message: string }> {
    console.log('Processing refund...', { transactionId, amount, reason });
    
    // Simulate refund processing
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const refundId = `RFND_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      refundId,
      message: 'Refund processed successfully. Amount will be credited within 5-7 business days.'
    };
  }

  // Utility method to format amount for display
  public formatAmount(amount: number, currency: string = 'INR'): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount);
  }

  // Generate receipt HTML for email/download
  public generateReceiptHTML(payment: PaymentResponse, bookingDetails: any): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Payment Receipt - Arulmigu Anjaneya Aalayam</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
          .receipt { max-width: 600px; margin: 0 auto; border: 1px solid #ddd; padding: 20px; }
          .header { text-align: center; color: #FF9933; margin-bottom: 20px; }
          .details { margin: 20px 0; }
          .row { display: flex; justify-content: space-between; margin: 10px 0; }
          .total { font-weight: bold; font-size: 18px; color: #FF9933; }
        </style>
      </head>
      <body>
        <div class="receipt">
          <div class="header">
            <h1>Arulmigu Anjaneya Aalayam</h1>
            <h2>Payment Receipt</h2>
          </div>
          <div class="details">
            <div class="row"><span>Receipt ID:</span><span>${payment.receipt?.receiptId}</span></div>
            <div class="row"><span>Transaction ID:</span><span>${payment.transactionId}</span></div>
            <div class="row"><span>Date:</span><span>${new Date().toLocaleDateString()}</span></div>
            <div class="row"><span>Seva:</span><span>${bookingDetails.sevaName}</span></div>
            <div class="row"><span>Date of Seva:</span><span>${bookingDetails.date}</span></div>
            <div class="row"><span>Time:</span><span>${bookingDetails.time}</span></div>
            <div class="row"><span>Devotee:</span><span>${bookingDetails.devoteeName}</span></div>
            <div class="row"><span>Payment Method:</span><span>${payment.receipt?.paymentMethod}</span></div>
            <div class="row total"><span>Amount Paid:</span><span>${this.formatAmount(payment.amount)}</span></div>
          </div>
          <p style="text-align: center; color: #666; margin-top: 30px;">
            Thank you for your devotion. May Lord Hanuman bless you!
          </p>
        </div>
      </body>
      </html>
    `;
  }

  // Initialize BasisPay frontend SDK
  public initializeBasisPaySDK(): void {
    if (typeof window !== 'undefined' && !window.BasisPay) {
      const script = document.createElement('script');
      script.src = this.basisPayConfig.baseUrl.includes('sandbox') 
        ? 'https://checkout-sandbox.basispay.in/v1/checkout.js'
        : 'https://checkout.basispay.in/v1/checkout.js';
      script.onload = () => {
        console.log('BasisPay SDK loaded successfully');
      };
      script.onerror = () => {
        console.error('Failed to load BasisPay SDK');
      };
      document.head.appendChild(script);
    }
  }

  // Open BasisPay payment modal
  public openBasisPayCheckout(orderData: any, callbacks: any): void {
    if (typeof window !== 'undefined' && window.BasisPay) {
      const options = {
        key: this.basisPayConfig.keyId,
        amount: orderData.amount * 100, // Convert to paise
        currency: orderData.currency || 'INR',
        name: 'Arulmigu Anjaneya Aalayam',
        description: orderData.description,
        image: `${window.location.origin}/temple-logo.png`,
        order_id: orderData.orderId,
        handler: callbacks.onSuccess,
        prefill: {
          name: orderData.customerName,
          email: orderData.customerEmail,
          contact: orderData.customerPhone
        },
        theme: {
          color: '#FF9933' // Temple saffron color
        },
        modal: {
          ondismiss: callbacks.onCancel
        }
      };

      const rzp = new window.BasisPay(options);
      rzp.open();
    } else {
      console.error('BasisPay SDK not loaded');
      callbacks.onError('Payment gateway not available');
    }
  }

  /*
   * BASISPAY.IN INTEGRATION NOTES:
   * 
   * 1. ENVIRONMENT VARIABLES SETUP:
   *    For Vite (prefix with VITE_):
   *    - VITE_BASISPAY_ENABLED=true
   *    - VITE_BASISPAY_KEY_ID=your_key_id
   *    - VITE_BASISPAY_KEY_SECRET=your_key_secret
   * 
   *    For Next.js (prefix with NEXT_PUBLIC_):
   *    - NEXT_PUBLIC_BASISPAY_ENABLED=true
   *    - NEXT_PUBLIC_BASISPAY_KEY_ID=your_key_id
   *    - NEXT_PUBLIC_BASISPAY_KEY_SECRET=your_key_secret
   * 
   *    For Netlify/Vercel (use build environment variables):
   *    - Set in deployment dashboard or netlify.toml / vercel.json
   * 
   * 2. RUNTIME CONFIGURATION:
   *    If environment variables are not available, use:
   *    PaymentService.getInstance().updateBasisPayConfig({
   *      keyId: 'your_key_id',
   *      keySecret: 'your_key_secret',
   *      enabled: true
   *    });
   * 
   * 3. SETUP REQUIREMENTS:
   *    - Complete merchant onboarding at https://merchant.basispay.in/
   *    - Obtain KEY_ID and KEY_SECRET from dashboard
   *    - Set up webhook endpoints for payment confirmations
   *    - Configure callback URLs in merchant settings
   * 
   * 4. FRONTEND INTEGRATION:
   *    - PaymentService automatically handles SDK loading
   *    - Call openBasisPayCheckout() to open payment modal
   *    - Handle success/failure callbacks
   * 
   * 5. BACKEND INTEGRATION:
   *    - Implement webhook endpoint for payment notifications
   *    - Verify payment signatures for security
   *    - Update booking status based on payment status
   * 
   * 6. SECURITY CONSIDERATIONS:
   *    - KEY_SECRET should only be used for server-side verification
   *    - Use HTTPS for all communications
   *    - Implement proper error handling and logging
   *    - Follow PCI DSS compliance guidelines
   * 
   * 7. TESTING:
   *    - Service automatically detects environment (localhost = development)
   *    - Test all payment methods (UPI, Cards, Net Banking)
   *    - Verify webhook delivery and signature validation
   *    - Test failure scenarios and error handling
   * 
   * 8. PRODUCTION DEPLOYMENT:
   *    - Service automatically switches to production URLs
   *    - Set up monitoring and alerts
   *    - Configure settlement and reconciliation
   *    - Test with small amounts initially
   */
}