import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '../components/Dialog';
import { useTranslation } from './localization_context';
import { BookingService } from './booking_service';
import { smsService, type BookingConfirmationData } from './sms_services';
import { toast } from 'sonner';
// import { Button } from './ui/button';
// import { Input } from './ui/input';
// import { Label } from './ui/label';
// import { Textarea } from './ui/textarea';
// import { BookingService, SevaConfig } from './BookingService';
// import { PaymentDialog } from './PaymentDialog';
// import { smsService, BookingConfirmationData } from './SMSService';
// import { toast } from 'sonner@2.0.3';

interface BookingDialogProps {
  seva: any;
  selectedDate: Date;
  isAvailable: boolean;
  onBookingSuccess: () => void;
  children: React.ReactNode;
}

export function BookingDialog({ seva, selectedDate, isAvailable, onBookingSuccess, children }: BookingDialogProps) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    devoteeName: '',
    phone: '',
    email: '',
    specialRequests: ''
  });
  const [formErrors, setFormErrors] = useState({
    devoteeName: '',
    phone: '',
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

//   const bookingService = BookingService.getInstance();

  // Phone number validation function
  const validatePhoneNumber = (phone: string): string => {
    if (!phone) {
      return t('booking.validation.phone_required');
    }
    
    // Remove any non-digit characters for validation
    const digitsOnly = phone.replace(/\D/g, '');
    
    if (digitsOnly.length !== 10) {
      return t('booking.validation.phone_invalid');
    }
    
    return '';
  };

  // Email validation function
  const validateEmail = (email: string): string => {
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return t('booking.validation.email_invalid');
    }
    return '';
  };

  // Name validation function
  const validateName = (name: string): string => {
    if (!name.trim()) {
      return t('booking.validation.name_required');
    }
    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate all fields
    const nameError = validateName(formData.devoteeName);
    const phoneError = validatePhoneNumber(formData.phone);
    const emailError = validateEmail(formData.email);

    const newErrors = {
      devoteeName: nameError,
      phone: phoneError,
      email: emailError
    };

    setFormErrors(newErrors);

    // // Check if there are any errors
    // if (nameError || phoneError || emailError) {
    //   toast.error('Please correct the errors in the form');
    //   return;
    // }

    // Open payment dialog if validation passes
    setPaymentDialogOpen(true);
  };

  const handlePaymentSuccess = async (transactionDetails: any) => {
    setIsSubmitting(true);
    
    try {
      // Create booking after successful payment
      const result = BookingService.makeBooking({
        sevaId: seva.id,
        sevaName: seva.name,
        date: selectedDate.toISOString().split('T')[0],
        time: seva.time,
        devoteeName: formData.devoteeName,
        phone: formData.phone,
        email: formData.email,
        amount: seva.fees,
        transactionId: transactionDetails.transactionId,
        paymentStatus: 'paid'
      });

      if (result.success) {
        // Show initial success message
        toast.success(`${t('booking.booking_successful')} Transaction ID: ${transactionDetails.transactionId}`);
        
        // Send SMS confirmation
        try {
          const smsData: BookingConfirmationData = {
            devoteeName: formData.devoteeName,
            sevaName: seva.name,
            date: selectedDate.toLocaleDateString(),
            time: seva.time,
            transactionId: transactionDetails.transactionId,
            amount: seva.fees,
            bookingId: result.bookingId || `BK${Date.now()}`
          };

          const smsResult = await smsService.sendBookingConfirmation(
            formData.phone,
            smsData
          );

          if (smsResult.success) {
            toast.success(t('booking.sms_sent'), {
              description: `Message ID: ${smsResult.messageId}`
            });
            console.log(`[Booking] SMS sent successfully to ${formData.phone}`);
          } else {
            toast.warning(t('booking.sms_failed'), {
              description: smsResult.error
            });
            console.warn(`[Booking] SMS sending failed: ${smsResult.error}`);
          }
        } catch (smsError) {
          console.error('[Booking] SMS sending error:', smsError);
          toast.warning(t('booking.sms_failed'));
        }
        
        // Reset form
        setFormData({
          devoteeName: '',
          phone: '',
          email: '',
          specialRequests: ''
        });
        
        setFormErrors({
          devoteeName: '',
          phone: '',
          email: ''
        });
        
        // Close dialogs
        setPaymentDialogOpen(false);
        setOpen(false);
        
        // Refresh availability
        onBookingSuccess();
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error('An error occurred while confirming the booking. Please contact the temple with your transaction ID.');
      console.error('Booking confirmation error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePaymentCancel = () => {
    setPaymentDialogOpen(false);
    toast.info('Payment cancelled. Your booking has not been confirmed.');
  };

  const handleInputChange = (field: string, value: string) => {
    let processedValue = value;
    
    // Special handling for phone number - only allow digits
    if (field === 'phone') {
      // Remove any non-digit characters
      processedValue = value.replace(/\D/g, '');
      // Limit to 10 digits
      if (processedValue.length > 10) {
        processedValue = processedValue.slice(0, 10);
      }
    }

    setFormData(prev => ({
      ...prev,
      [field]: processedValue
    }));

    // Clear error when user starts typing
    if (formErrors[field as keyof typeof formErrors]) {
      setFormErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }

    // Real-time validation for phone
    if (field === 'phone' && processedValue) {
      const phoneError = validatePhoneNumber(processedValue);
      setFormErrors(prev => ({
        ...prev,
        phone: phoneError
      }));
    }

    // Real-time validation for email
    if (field === 'email' && value) {
      const emailError = validateEmail(value);
      setFormErrors(prev => ({
        ...prev,
        email: emailError
      }));
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger>
          {children}
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-[var(--temple-saffron)]">
              {t('booking.title', { sevaName: seva.name })}
            </DialogTitle>
            <DialogDescription>
              Complete this form to proceed with booking. Payment will be required to confirm your seva.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-sm mb-2">{t('booking.seva_details')}</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">{t('common.date')}:</span>
                  <p>{selectedDate.toLocaleDateString()}</p>
                </div>
                <div>
                  <span className="font-medium">{t('common.time')}:</span>
                  <p>{seva.time}</p>
                </div>
                <div>
                  <span className="font-medium">Seva:</span>
                  <p>{seva.name}</p>
                </div>
                <div>
                  <span className="font-medium">Fees:</span>
                  <p>₹{seva.fees}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-sm">{t('booking.personal_info')}</h4>
              
              <div>
                {/* <Label htmlFor="devoteeName">{t('booking.full_name')} *</Label>
                <Input
                  id="devoteeName"
                  value={formData.devoteeName}
                  onChange={(e) => handleInputChange('devoteeName', e.target.value)}
                  required
                  placeholder="Enter devotee name"
                  className={formErrors.devoteeName ? 'border-red-500' : ''}
                /> */}
                {formErrors.devoteeName && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.devoteeName}</p>
                )}
              </div>

              <div>
                {/* <Label htmlFor="phone">{t('booking.phone_number')} *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  required
                  placeholder="Enter 10-digit phone number"
                  className={formErrors.phone ? 'border-red-500' : ''}
                  maxLength={10}
                /> */}
                {formErrors.phone && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.phone}</p>
                )}
                {formData.phone && !formErrors.phone && formData.phone.length === 10 && (
                  <p className="text-green-600 text-xs mt-1">✓ Valid phone number</p>
                )}
              </div>

              <div>
                {/* <Label htmlFor="email">{t('booking.email_address')}</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="Enter email address (optional)"
                  className={formErrors.email ? 'border-red-500' : ''}
                /> */}
                {formErrors.email && (
                  <p className="text-red-500 text-xs mt-1">{formErrors.email}</p>
                )}
              </div>

              <div>
                {/* <Label htmlFor="specialRequests">{t('booking.special_requests')}</Label>
                <Textarea
                  id="specialRequests"
                  value={formData.specialRequests}
                  onChange={(e) => handleInputChange('specialRequests', e.target.value)}
                  placeholder={t('booking.special_requests_placeholder')}
                  className="min-h-[80px]"
                /> */}
              </div>
            </div>

            <div className="bg-blue-50 p-3 rounded-lg text-sm text-blue-700">
              <p className="font-medium mb-1">Payment Information:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Secure payment processing via multiple payment methods</li>
                <li>UPI, Credit/Debit Cards, Net Banking, and Wallets accepted</li>
                <li>You will receive a payment receipt via email</li>
                <li>Booking is confirmed only after successful payment</li>
              </ul>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              {/* <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                disabled={isSubmitting}
              >
                {t('common.cancel')}
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting || !isAvailable}
                className="bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
              >
                {isSubmitting ? 'Processing...' : t('booking.proceed_payment')}
              </Button> */}
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      {/* <PaymentDialog
        open={paymentDialogOpen}
        onOpenChange={setPaymentDialogOpen}
        seva={seva}
        selectedDate={selectedDate}
        bookingDetails={{
          devoteeName: formData.devoteeName,
          phone: formData.phone,
          email: formData.email
        }}
        onPaymentSuccess={handlePaymentSuccess}
        onPaymentCancel={handlePaymentCancel}
      /> */}
    </>
  );
}