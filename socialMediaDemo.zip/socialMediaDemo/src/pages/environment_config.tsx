// Environment Configuration Helper
// Safe access to environment variables across different build environments

export interface EnvironmentConfig {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
  BASISPAY_SECRET: string;
  SMS_API_KEY: string;
  DEV_MODE: string;
  TEMPLE_NAME: string;
  TEMPLE_LOCATION: string;
  ADMIN_EMAIL: string;
}

class EnvironmentManager {
  private static instance: EnvironmentManager;
  private config: Partial<EnvironmentConfig> = {};

  private constructor() {
    this.loadEnvironmentVariables();
  }

  public static getInstance(): EnvironmentManager {
    if (!EnvironmentManager.instance) {
      EnvironmentManager.instance = new EnvironmentManager();
    }
    return EnvironmentManager.instance;
  }

  private loadEnvironmentVariables(): void {
    // Try multiple methods to access environment variables
    
    // Method 1: Direct import.meta.env access (works in most Vite builds)
    try {
      if (import.meta.env) {
        this.config.SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
        this.config.SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
        this.config.BASISPAY_SECRET = import.meta.env.VITE_BASISPAY_SECRET;
        this.config.SMS_API_KEY = import.meta.env.VITE_SMS_API_KEY;
        this.config.DEV_MODE = import.meta.env.VITE_DEV_MODE;
        this.config.TEMPLE_NAME = import.meta.env.VITE_TEMPLE_NAME;
        this.config.TEMPLE_LOCATION = import.meta.env.VITE_TEMPLE_LOCATION;
        this.config.ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL;
      }
    } catch (error) {
      console.debug('Could not access import.meta.env:', error);
    }

    // Method 2: Process environment (Node.js environments)
    try {
      if (typeof process !== 'undefined' && process.env) {
        this.config.SUPABASE_URL = this.config.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
        this.config.SUPABASE_ANON_KEY = this.config.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;
        this.config.BASISPAY_SECRET = this.config.BASISPAY_SECRET || process.env.VITE_BASISPAY_SECRET;
        this.config.SMS_API_KEY = this.config.SMS_API_KEY || process.env.VITE_SMS_API_KEY;
        this.config.DEV_MODE = this.config.DEV_MODE || process.env.VITE_DEV_MODE;
        this.config.TEMPLE_NAME = this.config.TEMPLE_NAME || process.env.VITE_TEMPLE_NAME;
        this.config.TEMPLE_LOCATION = this.config.TEMPLE_LOCATION || process.env.VITE_TEMPLE_LOCATION;
        this.config.ADMIN_EMAIL = this.config.ADMIN_EMAIL || process.env.VITE_ADMIN_EMAIL;
      }
    } catch (error) {
      console.debug('Could not access process.env:', error);
    }

    // Method 3: Window environment object (custom configuration)
    try {
      if (typeof window !== 'undefined' && (window as any).ENV) {
        const windowEnv = (window as any).ENV;
        this.config.SUPABASE_URL = this.config.SUPABASE_URL || windowEnv.VITE_SUPABASE_URL;
        this.config.SUPABASE_ANON_KEY = this.config.SUPABASE_ANON_KEY || windowEnv.VITE_SUPABASE_ANON_KEY;
        this.config.BASISPAY_SECRET = this.config.BASISPAY_SECRET || windowEnv.VITE_BASISPAY_SECRET;
        this.config.SMS_API_KEY = this.config.SMS_API_KEY || windowEnv.VITE_SMS_API_KEY;
        this.config.DEV_MODE = this.config.DEV_MODE || windowEnv.VITE_DEV_MODE;
        this.config.TEMPLE_NAME = this.config.TEMPLE_NAME || windowEnv.VITE_TEMPLE_NAME;
        this.config.TEMPLE_LOCATION = this.config.TEMPLE_LOCATION || windowEnv.VITE_TEMPLE_LOCATION;
        this.config.ADMIN_EMAIL = this.config.ADMIN_EMAIL || windowEnv.VITE_ADMIN_EMAIL;
      }
    } catch (error) {
      console.debug('Could not access window.ENV:', error);
    }
  }

  public get(key: keyof EnvironmentConfig): string | undefined {
    return this.config[key];
  }

  public getWithDefault(key: keyof EnvironmentConfig, defaultValue: string): string {
    return this.config[key] || defaultValue;
  }

  public isConfigured(key: keyof EnvironmentConfig): boolean {
    const value = this.config[key];
    return Boolean(value && value.trim() && value !== 'undefined');
  }

  public getSupabaseConfig(): { url: string; anonKey: string; isValid: boolean } {
    const url = this.getWithDefault('SUPABASE_URL', 'https://your-project.supabase.co');
    const anonKey = this.getWithDefault('SUPABASE_ANON_KEY', 'your-anon-key');
    
    const isValid = this.isConfigured('SUPABASE_URL') && 
                   this.isConfigured('SUPABASE_ANON_KEY') &&
                   url.includes('supabase.co');

    return { url, anonKey, isValid };
  }

  public getBasisPayConfig(): { secret: string; isValid: boolean } {
    const secret = this.getWithDefault('BASISPAY_SECRET', '');
    const isValid = this.isConfigured('BASISPAY_SECRET');
    
    return { secret, isValid };
  }

  public getSMSConfig(): { apiKey: string; isValid: boolean } {
    const apiKey = this.getWithDefault('SMS_API_KEY', '');
    const isValid = this.isConfigured('SMS_API_KEY');
    
    return { apiKey, isValid };
  }

  public getConfigurationStatus(): {
    supabase: boolean;
    basisPay: boolean;
    sms: boolean;
    overall: boolean;
  } {
    const supabase = this.getSupabaseConfig().isValid;
    const basisPay = this.getBasisPayConfig().isValid;
    const sms = this.getSMSConfig().isValid;
    
    return {
      supabase,
      basisPay,
      sms,
      overall: supabase // At minimum, we need Supabase configured
    };
  }

  public isDevMode(): boolean {
    // Check multiple sources for development mode
    const devMode = this.get('DEV_MODE');
    
    // Also check directly for the environment variable
    let directCheck = false;
    try {
      if (import.meta && import.meta.env && import.meta.env.VITE_DEV_MODE) {
        directCheck = import.meta.env.VITE_DEV_MODE === 'true';
      }
    } catch (error) {
      // Ignore error
    }
    
    // Additional check for process.env in case import.meta.env doesn't work
    let processCheck = false;
    try {
      if (typeof process !== 'undefined' && process.env && process.env.VITE_DEV_MODE) {
        processCheck = process.env.VITE_DEV_MODE === 'true';
      }
    } catch (error) {
      // Ignore error
    }
    
    // Also check for common development environment indicators
    let envCheck = false;
    try {
      if (import.meta && import.meta.env) {
        envCheck = import.meta.env.DEV === true || import.meta.env.MODE === 'development';
      }
    } catch (error) {
      // Ignore error
    }
    
    const isDevMode = devMode === 'true' || devMode === '1' || directCheck || processCheck || envCheck;
    
    // Only log once when dev mode is detected
    if (isDevMode && !this.devModeLogged) {
      console.debug('🔧 Development mode enabled - minimal console output');
      this.devModeLogged = true;
    }
    
    return isDevMode;
  }

  private devModeLogged = false;
  private statusLogged = false;

  public logConfigurationStatus(): void {
    const status = this.getConfigurationStatus();
    const isDevMode = this.isDevMode();
    
    if (isDevMode) {
      // Very minimal logging in dev mode - only log once
      if (!this.statusLogged) {
        if (status.overall) {
          console.debug('🔧 Dev mode: PostgreSQL database connected');
        } else {
          console.debug('🔧 Dev mode: Using localStorage for data (not persistent)');
        }
        this.statusLogged = true;
      }
      return;
    }
    
    console.log('🔧 Environment Configuration Status:');
    console.log(`   📦 Supabase: ${status.supabase ? '✅' : '❌'}`);
    console.log(`   💳 BasisPay: ${status.basisPay ? '✅' : '❌'}`);
    console.log(`   📱 SMS: ${status.sms ? '✅' : '❌'}`);
    console.log(`   🎯 Overall: ${status.overall ? '✅ Ready' : '⚠️ Needs Setup'}`);
    
    if (!status.supabase) {
      console.log('');
      console.log('📋 To configure PostgreSQL database:');
      console.log('  1. Create a Supabase account at https://supabase.com');
      console.log('  2. Create a new project');
      console.log('  3. Copy .env.example to .env.local');
      console.log('  4. Set your Supabase URL and anon key in .env.local');
      console.log('  5. Run the database schema from POSTGRESQL_SETUP_GUIDE.md');
      console.log('');
      console.log('🔧 For now, using localStorage fallback (data won\'t persist between sessions)');
    }
  }

  // Development helper method
  public setTestConfiguration(): void {
    if (typeof window !== 'undefined') {
      (window as any).ENV = {
        VITE_SUPABASE_URL: 'https://test-project.supabase.co',
        VITE_SUPABASE_ANON_KEY: 'test-anon-key',
        VITE_BASISPAY_SECRET: 'test-basis-secret',
        VITE_SMS_API_KEY: 'test-sms-key',
        VITE_DEV_MODE: 'true',
        VITE_TEMPLE_NAME: 'Test Temple',
        VITE_TEMPLE_LOCATION: 'Test Location',
        VITE_ADMIN_EMAIL: 'test@temple.org'
      };
      
      // Reload configuration
      this.loadEnvironmentVariables();
      console.log('🧪 Test configuration loaded');
    }
  }

  // Enable development mode
  public enableDevMode(): void {
    if (typeof window !== 'undefined') {
      if (!(window as any).ENV) {
        (window as any).ENV = {};
      }
      (window as any).ENV.VITE_DEV_MODE = 'true';
      this.loadEnvironmentVariables();
      console.log('🔧 Development mode enabled - warnings minimized');
    }
  }
}

// Export singleton instance
export const environmentConfig = EnvironmentManager.getInstance();

// React hook for environment configuration
import { useState, useEffect } from 'react';

export function useEnvironmentConfig() {
  const [config, setConfig] = useState(() => environmentConfig.getConfigurationStatus());
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initial load
    setConfig(environmentConfig.getConfigurationStatus());
    setIsLoading(false);

    // Log status
    environmentConfig.logConfigurationStatus();
  }, []);

  const refresh = () => {
    setConfig(environmentConfig.getConfigurationStatus());
  };

  const setTestConfig = () => {
    environmentConfig.setTestConfiguration();
    refresh();
  };

  return {
    config,
    isLoading,
    refresh,
    setTestConfig,
    environmentConfig
  };
}

// Environment status component for admin/debug use
export function EnvironmentStatus() {
  const { config, isLoading, refresh, setTestConfig } = useEnvironmentConfig();

  if (isLoading) {
    return <div className="p-4 bg-gray-50 rounded-lg">Loading environment configuration...</div>;
  }

  return (
    <div className="p-4 bg-gray-50 rounded-lg space-y-3">
      <h3 className="font-semibold text-gray-800">Environment Configuration</h3>
      
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className={`p-2 rounded ${config.supabase ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
          <div>PostgreSQL/Supabase</div>
          <div className="text-xs">{config.supabase ? 'Configured ✅' : 'Not configured ❌'}</div>
        </div>
        
        <div className={`p-2 rounded ${config.basisPay ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
          <div>BasisPay</div>
          <div className="text-xs">{config.basisPay ? 'Configured ✅' : 'Optional ⚠️'}</div>
        </div>
        
        <div className={`p-2 rounded ${config.sms ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
          <div>SMS Service</div>
          <div className="text-xs">{config.sms ? 'Configured ✅' : 'Optional ⚠️'}</div>
        </div>
        
        <div className={`p-2 rounded ${config.overall ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
          <div>Overall Status</div>
          <div className="text-xs">{config.overall ? 'Ready ✅' : 'Needs setup ❌'}</div>
        </div>
      </div>

      <div className="flex gap-2">
        <button 
          onClick={refresh}
          className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
        >
          Refresh
        </button>
        
        {!config.overall && (
          <>
            <button 
              onClick={setTestConfig}
              className="px-3 py-1 bg-yellow-500 text-white rounded text-sm hover:bg-yellow-600"
            >
              Load Test Config
            </button>
            
            <button 
              onClick={() => {
                environmentConfig.enableDevMode();
                refresh();
              }}
              className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
            >
              Enable Dev Mode
            </button>
          </>
        )}
      </div>

      {!config.overall && (
        <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded text-sm">
          <div className="font-medium text-yellow-800">Setup Required</div>
          <div className="text-yellow-700 mt-1 space-y-1">
            <div>Currently using localStorage fallback. For production, configure PostgreSQL database.</div>
            <div className="text-xs text-yellow-600">
              📖 Quick setup: See <code>QUICK_SETUP.md</code> | 
              📚 Detailed guide: <code>POSTGRESQL_SETUP_GUIDE.md</code>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default EnvironmentManager;