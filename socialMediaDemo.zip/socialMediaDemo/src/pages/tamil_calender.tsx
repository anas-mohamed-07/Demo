import React, { useState, useEffect } from 'react';

import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { useLocalization } from './localization_context';
import { Card, CardContent } from '../components/Card';
import { Button } from '../components/button';

interface HanumanCalendarInfo {
  date: Date;
  naal: string; // Day of week (accurate)
  tithi: string; // Lunar day
  nakshatra: string; // Star
  rashi: string; // Zodiac sign
  karanam: string; // Half of tithi
  yogam: string; // Yoga
  englishDate: string;
  isAuspicious: boolean;
  significance?: string;
}

interface TamilCalendarWidgetProps {
  compact?: boolean;
}

const TamilCalendarWidget: React.FC<TamilCalendarWidgetProps> = ({ compact = false }) => {
  const { language, t } = useLocalization();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarInfo, setCalendarInfo] = useState<HanumanCalendarInfo | null>(null);

  // Tamil calendar with all traditional elements (using simplified calculations)
  const getHanumanCalendarInfo = (date: Date): HanumanCalendarInfo => {
    const dayOfWeek = date.getDay();
    const dayOfMonth = date.getDate();
    const month = date.getMonth();

    // Tamil days of week (this is accurate)
    const tamilDays = ['ஞாயிறு', 'திங்கள்', 'செவ்வாய்', 'புதன்', 'வியாழன்', 'வெள்ளி', 'சனி'];

    // Tithis (15 lunar days for each half of lunar month)
    const tithis = [
      'பிரதமை', 'துவிதீயை', 'திருதீயை', 'சதுர்த்தி', 'பஞ்சமி', 'சஷ்டி',
      'சப்தமி', 'அஷ்டமி', 'நவமி', 'தசமி', 'ஏகாதசி', 'துவாதசி',
      'திரயோதசி', 'சதுர்த்தசி', 'அமாவாசை/பௌர்ணமி'
    ];

    // Nakshatras (27 stars)
    const nakshatras = [
      'அசுவினி', 'பரணி', 'கிருத்திகை', 'ரோகிணி', 'மிருகசீர்ஷம்', 'திருவாதிரை',
      'புனர்பூசம்', 'பூசம்', 'ஆயில்யம்', 'மகம்', 'பூரம்', 'உத்தரம்',
      'அஸ்தம்', 'சித்திரை', 'சுவாதி', 'விசாகம்', 'அனுஷம்', 'கேட்டை',
      'மூலம்', 'பூராடம்', 'உத்தராடம்', 'திருவோணம்', 'அவிட்டம்', 'சதயம்',
      'பூரட்டாதி', 'உத்தரட்டாதி', 'ரேவதி'
    ];

    // Rashis (12 zodiac signs)
    const rashis = [
      'மேஷம்', 'ரிஷபம்', 'மிதுனம்', 'கடகம்', 'சிம்மம்', 'கன்னி',
      'துலாம்', 'விருச்சிகம்', 'தனுசு', 'மகரம்', 'கும்பம்', 'மீனம்'
    ];

    // Karanas (11 karanas)
    const karanas = [
      'கிம்ஸ்துக்ன', 'பவ', 'பாலவ', 'கௌலவ', 'தைதுல', 'கரஜ', 'வணிஜ்',
      'விஷ்டி', 'சக்ர', 'சதுஷ்பாத', 'நாக'
    ];

    // Yogas (27 yogas)
    const yogas = [
      'விஷ்கம்ப', 'பிரீதி', 'ஆயுஷ்மான்', 'சௌபாக்ய', 'சோபன', 'அதிகண்ட',
      'சுகர்ம', 'தித்தி', 'சூல', 'கண்ட', 'விருத்தி', 'துரவ',
      'சித்த', 'வ்யாதிபாத', 'வரியான்', 'பரிக', 'சிவ', 'சாத்ய',
      'சுபா', 'சுக்ல', 'ப்ராமண', 'ஐந்திர', 'வைதருதி', 'விஷ்கம்ப',
      'ப்ராஜாபத்ய', 'வைராஜ்', 'சித்தம்'
    ];

    // Calculate indices using simplified algorithms (Note: These need proper astronomical calculations)
    const tithiIndex = (dayOfMonth - 1) % 15;
    const nakshatraIndex = (dayOfMonth + month * 2) % 27;
    const rashiIndex = month % 12;
    const karanaIndex = (dayOfMonth + dayOfWeek) % 11;
    const yogaIndex = (dayOfMonth + month + dayOfWeek) % 27;

    // Determine auspiciousness based on Hanuman worship traditions
    const isAuspicious = dayOfWeek === 6 || dayOfWeek === 2;

    let significance = '';
    if (dayOfWeek === 6) { // Saturday - Most auspicious day for Hanuman
      significance = language === 'ta' ? 'சிறப்பு நாள்' : 'Special Day';
    } else if (dayOfWeek === 2) { // Tuesday - Also auspicious for Hanuman
      significance = language === 'ta' ? 'சுப நாள்' : 'Auspicious';
    }

    return {
      date,
      naal: tamilDays[dayOfWeek],
      tithi: tithis[tithiIndex],
      nakshatra: nakshatras[nakshatraIndex],
      rashi: rashis[rashiIndex],
      karanam: karanas[karanaIndex],
      yogam: yogas[yogaIndex],
      englishDate: date.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      }),
      isAuspicious,
      significance
    };
  };

  useEffect(() => {
    const dateInfo = getHanumanCalendarInfo(currentDate);
    setCalendarInfo(dateInfo);
  }, [currentDate, language]);

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setDate(newDate.getDate() - 1);
    } else {
      newDate.setDate(newDate.getDate() + 1);
    }
    setCurrentDate(newDate);
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  if (!calendarInfo) {
    return (
      <Card className={compact ? "w-64 shadow-lg" : "w-full max-w-md mx-auto shadow-lg"}>
        <CardContent className="p-3">
          <div className="animate-pulse space-y-2">
            <div className="h-3 bg-gray-200 rounded w-3/4"></div>
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const labels = language === 'ta' ? {
    title: 'நாட்காட்டி',
    day: 'நாள்:',
    tithi: 'திதி:',
    nakshatra: 'நட்சத்திரம்:',
    rashi: 'ராசி:',
    karanam: 'கர்ணம்:',
    yogam: 'யோகம்:',
    today: 'இன்று',
    previous: 'முந்தைய',
    next: 'அடுத்த',
    auspicious: 'சுப நாள்',
    regular: 'சாதாரண நாள்'
  } : {
    title: 'Calendar',
    day: 'Day:',
    tithi: 'Tithi:',
    nakshatra: 'Nakshatra:',
    rashi: 'Rashi:',
    karanam: 'Karanam:',
    yogam: 'Yogam:',
    today: 'Today',
    previous: 'Prev',
    next: 'Next',
    auspicious: 'Auspicious',
    regular: 'Regular'
  };

  if (compact) {
    return (
      <Card className="w-64 bg-white/95 backdrop-blur-sm shadow-lg border border-orange-200/50">
        <CardContent className="p-3">
          <div className="space-y-2">
            <div className="text-xs text-gray-600 text-center mb-2">
              {calendarInfo.englishDate}
            </div>
            
            <div className="grid grid-cols-1 gap-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-700">{labels.day}</span>
                <span className="font-semibold text-orange-700">{calendarInfo.naal}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-700">{labels.tithi}</span>
                <span className="font-semibold text-orange-700">{calendarInfo.tithi}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-700">{labels.nakshatra}</span>
                <span className="font-semibold text-orange-700">{calendarInfo.nakshatra}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-700">{labels.rashi}</span>
                <span className="font-semibold text-orange-700">{calendarInfo.rashi}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-700">{labels.karanam}</span>
                <span className="font-semibold text-orange-700">{calendarInfo.karanam}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-700">{labels.yogam}</span>
                <span className="font-semibold text-orange-700">{calendarInfo.yogam}</span>
              </div>
            </div>

            {calendarInfo.isAuspicious && (
              <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full text-center mt-2">
                {calendarInfo.significance}
              </div>
            )}

            <div className="flex justify-between pt-2 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateDate('prev')}
                className="flex-1 text-xs bg-green-100 hover:bg-green-200 text-green-800 border-green-300"
              >
                {labels.previous}
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateDate('next')}
                className="flex-1 text-xs bg-green-100 hover:bg-green-200 text-green-800 border-green-300"
              >
                {labels.next}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Full size widget for standalone use
  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-2 border-orange-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-orange-600" />
            <span className="text-lg font-semibold text-orange-800">{labels.title}</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={goToToday}
            className="text-xs"
          >
            {labels.today}
          </Button>
        </div>
        
        <div className="space-y-4">
          <div className="text-sm text-gray-600 text-center">
            {calendarInfo.englishDate}
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="font-medium text-gray-700">{labels.day}</span>
              <span className="font-semibold text-orange-700">{calendarInfo.naal}</span>
            </div>
            
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="font-medium text-gray-700">{labels.tithi}</span>
              <span className="font-semibold text-orange-700">{calendarInfo.tithi}</span>
            </div>
            
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="font-medium text-gray-700">{labels.nakshatra}</span>
              <span className="font-semibold text-orange-700">{calendarInfo.nakshatra}</span>
            </div>
            
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="font-medium text-gray-700">{labels.rashi}</span>
              <span className="font-semibold text-orange-700">{calendarInfo.rashi}</span>
            </div>
            
            <div className="flex justify-between text-sm border-b pb-2">
              <span className="font-medium text-gray-700">{labels.karanam}</span>
              <span className="font-semibold text-orange-700">{calendarInfo.karanam}</span>
            </div>
            
            <div className="flex justify-between text-sm">
              <span className="font-medium text-gray-700">{labels.yogam}</span>
              <span className="font-semibold text-orange-700">{calendarInfo.yogam}</span>
            </div>
          </div>

          {calendarInfo.isAuspicious && (
            <div className="bg-green-100 text-green-800 text-sm px-3 py-2 rounded-lg text-center">
              {calendarInfo.significance}
            </div>
          )}

          <div className="flex justify-between pt-4 gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigateDate('prev')}
              className="flex-1 bg-green-100 hover:bg-green-200 text-green-800 border-green-300"
            >
              {labels.previous}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigateDate('next')}
              className="flex-1 bg-green-100 hover:bg-green-200 text-green-800 border-green-300"
            >
              {labels.next}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TamilCalendarWidget;