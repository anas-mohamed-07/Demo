

import { useTranslation } from './localization_context';
import { Calendar, Clock } from 'lucide-react';
import { Gift, Heart } from '../components/icons';
import { Button } from '../components/button';
import TamilCalendarWidget from './tamil_calender';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';

export function HomePage() {
  const { t } = useTranslation();
  const navigate = useNavigate();

  useEffect(()=>{
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },[])

  const quickLinks = [
    {
      title: t('home.services.sevas'),
      description: t('home.services.sevas.desc'),
      icon: <Calendar className="h-8 w-8 text-[var(--temple-saffron)]" />,
      action: () => navigate('bookings')
    },
    {
      title: t('nav.grants'),
      description: 'Educational & Medical assistance',
      icon: <Gift className="h-8 w-8 text-[var(--temple-saffron)]" />,
      action: () => navigate('grants')
    },
    {
      title: t('home.services.donations'),
      description: t('home.services.donations.desc'),
      icon: <Heart className="h-8 w-8 text-[var(--temple-saffron)]" />,
      action: () => navigate('donation')
    }
  ];

  const dailySevas = [
    { name: t('seva.thirumanjanam.name'), time: '5:00 PM' },
    { name: t('seva.vadamalai.name'), time: '6:00 PM' },
    { name: t('seva.santhana_kaapu.name'), time: '6:30 PM' },
    { name: t('seva.vennai_kaapu.name'), time: '7:00 PM' },
    { name: t('seva.senthoora_kaapu.name'), time: '7:30 PM' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Banner */}
      <div className="relative h-screen bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)]">
        {/* Background Image */}
        <div className="absolute inset-0">
          {/* <img
            src={exampleImage}
            alt="Lord Hanuman"
            className="w-full h-full object-cover"
          /> */}
        </div>
        
        {/* Multi-layer overlay for better readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[var(--temple-saffron)]/30 to-[var(--temple-gold)]/20"></div>
        
        {/* Content */}
        <div className="relative z-10 flex items-center justify-center h-full text-white px-4">
          <div className="max-w-6xl w-full">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 items-center">
              {/* Left side - Main content */}
              <div className="text-center lg:text-left order-1 lg:order-1 max-w-md lg:max-w-lg">
                {/* Enhanced text backdrop */}
                <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 md:p-8">
                  <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 drop-shadow-2xl text-[32px]">
                    {t('home.title')}
                  </h1>
                  <p className="text-lg md:text-xl mb-6 opacity-95 drop-shadow-lg">
                    {t('home.welcome')}
                  </p>
                  <div className="flex flex-row gap-3 justify-center lg:justify-start">
                    <Button
                      size="lg"
                      onClick={() => navigate('bookings')}
                      className="bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800 text-white font-semibold px-6 py-3 text-base divine-glow border-0"
                    >
                      {t('home.book')}
                    </Button>
                    <Button
                      size="lg"
                      variant="outline"
                      onClick={() => navigate('donation')}
                      className="border-2 border-white bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-[var(--temple-saffron)] font-semibold px-6 py-3 text-base transition-all duration-300"
                    >
                      {t('home.donate')}
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Right side - Tamil Calendar Widget */}
              <div className="flex justify-center lg:justify-end order-2 lg:order-2">
                <TamilCalendarWidget compact={true} />
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
          <div className="flex flex-col items-center">
            <span className="text-sm mb-2 opacity-80">{t('home.explore')}</span>
            <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
              <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Temple Introduction */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-[var(--temple-saffron)] mb-4">
            {t('home.welcome')}
          </h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-6">
            {t('home.description')}
          </p>
          <Button
            variant="outline"
            onClick={() => navigate('about')}
            className="border-[var(--temple-saffron)] text-[var(--temple-saffron)] hover:bg-[var(--temple-saffron)] hover:text-white"
          >
            {t('common.view')}
          </Button>
        </div>

        {/* Quick Links Section */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-center mb-8 text-gray-800">
            {t('home.services.title')}
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {quickLinks.map((link, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer divine-glow" onClick={link.action}>
                <CardHeader className="text-center">
                  <div className="flex justify-center mb-4">
                    {link.icon}
                  </div>
                  <CardTitle className="text-xl">{link.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 mb-4">{link.description}</p>
                  <Button className="w-full bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800">
                    {t('common.view')}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Daily Sevas Highlight Strip */}
        <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] rounded-lg p-6 text-[var(--temple-dark-brown)]">
          <h3 className="text-xl font-bold mb-4 text-center text-[var(--temple-dark-brown)]">Daily Seva Timings</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {dailySevas.map((seva, index) => (
              <div key={index} className="text-center bg-[var(--temple-dark-brown)]/20 rounded-lg p-3 backdrop-blur-sm">
                <div className="flex justify-center mb-2">
                  <Clock className="h-5 w-5 text-[var(--temple-dark-brown)]" />
                </div>
                <p className="font-semibold text-[var(--temple-dark-brown)]">{seva.name}</p>
                <p className="text-sm text-[var(--temple-dark-brown)]/80">{seva.time}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-4">
            <Button
              variant="secondary"
              onClick={() => navigate('bookings')}
              className="bg-white text-[var(--temple-saffron)] hover:bg-gray-100"
            >
              {t('bookings.available_sevas')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}