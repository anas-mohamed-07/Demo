// Database Service for Booking Management
// Now supports both PostgreSQL (via Supabase) and localStorage fallback

import { PostgreSQLBookingService } from './postgresql_booking_service';

export interface Booking {
  id: string;
  sevaId: string;
  sevaName: string;
  date: string;
  time: string;
  devoteeName: string;
  phone: string;
  email: string;
  amount: number;
  transactionId?: string;
  paymentStatus?: 'pending' | 'paid' | 'failed' | 'refunded';
  createdAt: Date;
}

export interface SevaConfig {
  id: string;
  name: string;
  time: string;
  fees: number;
  dailyLimit: number;
  description: string;
  detailedDescription: string;
  benefits: string[];
  significance: string;
  duration: string;
  materials: string[];
  bestTimeFor: string[];
  spiritualBenefits: string[];
  image: string;
}

export class BookingService {
  private static instance: BookingService;
  private bookings: Booking[] = [];
  private postgresService: PostgreSQLBookingService;
  private usePostgreSQL: boolean = false;
  private sevaConfigs: SevaConfig[] = [
    {
      id: 'thirumanjanam',
      name: 'Thirumanjanam',
      time: '5:00 PM - 6:00 PM',
      fees: 1000,
      dailyLimit: 10,
      description: 'Sacred ablution ceremony with milk, honey, and fragrant oils',
      detailedDescription: 'Thirumanjanam is one of the most sacred rituals performed to Lord Hanuman. This elaborate abhisheka involves bathing the deity with pure milk, honey, ghee, curd, and fragrant oils while chanting powerful mantras. The ceremony purifies the devotee and the environment, creating an atmosphere of divine presence.',
      benefits: [
        'Purification of mind, body, and soul',
        'Removal of negative energies and obstacles',
        'Enhanced spiritual awareness and devotion',
        'Blessings for good health and vitality',
        'Protection from evil influences'
      ],
      significance: 'Lord Hanuman is known as the remover of obstacles and protector of devotees. The Thirumanjanam ceremony invokes his divine energy to cleanse and protect the devotee from all forms of negativity.',
      duration: '60 minutes',
      materials: ['Pure cow milk', 'Organic honey', 'Clarified butter (ghee)', 'Fresh curd', 'Sacred oils', 'Holy water', 'Fresh flowers'],
      bestTimeFor: ['New beginnings', 'Overcoming challenges', 'Spiritual purification', 'Health issues', 'Mental peace'],
      spiritualBenefits: [
        'Increases devotion and faith',
        'Removes karmic obstacles',
        'Enhances meditation and prayer effectiveness',
        'Brings divine grace and blessings'
      ],
      image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop'
    },
    {
      id: 'vadamalai',
      name: 'Vadamalai',
      time: '6:00 PM - 6:30 PM',
      fees: 500,
      dailyLimit: 50,
      description: 'Garland offering with fresh flowers and sacred chants',
      detailedDescription: 'Vadamalai is the ceremonial offering of beautiful flower garlands to Lord Hanuman. Fresh marigolds, jasmine, and lotus flowers are specially arranged and offered with devotional songs and mantras. This seva represents the offering of beauty, fragrance, and devotion to the divine.',
      benefits: [
        'Brings joy and happiness in life',
        'Enhances beauty and attractiveness',
        'Improves relationships and social harmony',
        'Attracts prosperity and abundance',
        'Removes depression and sadness'
      ],
      significance: 'Flowers represent the blossoming of the soul and the offering of one\'s best to the divine. Lord Hanuman accepts these offerings and blesses devotees with happiness and fulfillment.',
      duration: '30 minutes',
      materials: ['Fresh marigold garlands', 'Jasmine flowers', 'Lotus petals', 'Rose garlands', 'Tulsi leaves', 'Sacred basil'],
      bestTimeFor: ['Celebrations', 'New relationships', 'Business ventures', 'Artistic pursuits', 'Social gatherings'],
      spiritualBenefits: [
        'Cultivates love and compassion',
        'Develops aesthetic sense and appreciation',
        'Enhances emotional well-being',
        'Promotes harmony in relationships'
      ],
      image: 'https://images.unsplash.com/photo-1604623842888-8ab8cf339ead?w=400&h=300&fit=crop'
    },
    {
      id: 'santhana-kaapu',
      name: 'Santhana Kaapu',
      time: '6:30 PM - 7:00 PM',
      fees: 1000,
      dailyLimit: 10,
      description: 'Special prayers for progeny and family welfare',
      detailedDescription: 'Santhana Kaapu is a powerful seva specifically performed for family welfare, fertility, and the blessing of children. This ceremony involves special mantras and offerings that invoke Lord Hanuman\'s blessings for expanding the family lineage and protecting existing family members.',
      benefits: [
        'Blessings for conception and childbirth',
        'Protection for pregnant mothers',
        'Healthy development of children',
        'Family harmony and unity',
        'Generational blessings and prosperity'
      ],
      significance: 'Lord Hanuman is revered as a protector of families and children. This seva is particularly powerful for couples seeking children and families wanting divine protection for their loved ones.',
      duration: '30 minutes',
      materials: ['Vermillion paste', 'Turmeric powder', 'Sacred rice', 'Coconut', 'Bananas', 'Betel leaves', 'Sacred thread'],
      bestTimeFor: ['Couples planning family', 'Pregnant mothers', 'Child protection', 'Family difficulties', 'Ancestral blessings'],
      spiritualBenefits: [
        'Strengthens family bonds',
        'Removes obstacles to parenthood',
        'Ensures healthy progeny',
        'Invokes ancestral blessings'
      ],
      image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=400&h=300&fit=crop'
    },
    {
      id: 'vennai-kaapu',
      name: 'Vennai Kaapu',
      time: '7:00 PM - 7:30 PM',
      fees: 1000,
      dailyLimit: 10,
      description: 'Butter offering ceremony for prosperity and health',
      detailedDescription: 'Vennai Kaapu involves offering fresh butter to Lord Hanuman, symbolizing purity, nourishment, and abundance. This ceremony is particularly beneficial for health, prosperity, and removing financial difficulties. The butter represents the sweetness of life and divine grace.',
      benefits: [
        'Improved physical health and strength',
        'Financial prosperity and wealth',
        'Nourishment for body and soul',
        'Sweet relationships and harmony',
        'Abundance in all life aspects'
      ],
      significance: 'Butter is considered one of the purest foods and is beloved by Lord Hanuman. Offering butter symbolizes offering the best and purest intentions to receive divine blessings for health and prosperity.',
      duration: '30 minutes',
      materials: ['Fresh white butter', 'Pure ghee', 'Honey', 'Jaggery', 'Dry fruits', 'Milk sweets'],
      bestTimeFor: ['Health issues', 'Financial difficulties', 'Business growth', 'Physical weakness', 'Seeking abundance'],
      spiritualBenefits: [
        'Purifies thoughts and intentions',
        'Enhances physical and spiritual strength',
        'Attracts divine grace and abundance',
        'Promotes contentment and satisfaction'
      ],
      image: 'https://images.unsplash.com/photo-1566996533071-82ad21517ea7?w=400&h=300&fit=crop'
    },
    {
      id: 'senthoora-kaapu',
      name: 'Senthoora Kaapu',
      time: '7:30 PM - 8:00 PM',
      fees: 1000,
      dailyLimit: 10,
      description: 'Vermillion offering for protection and blessings',
      detailedDescription: 'Senthoora Kaapu is the ceremonial application of sacred vermillion (kumkum) to Lord Hanuman. This powerful seva is known for providing protection against negative forces, evil eye, and granting courage and strength. The red vermillion represents power, energy, and divine protection.',
      benefits: [
        'Protection from negative energies',
        'Increased courage and confidence',
        'Victory over enemies and obstacles',
        'Enhanced willpower and determination',
        'Divine shield against evil influences'
      ],
      significance: 'Vermillion is sacred to Lord Hanuman and represents his fierce protective nature. This seva is especially powerful for those facing challenges, legal issues, or needing divine intervention in difficult situations.',
      duration: '30 minutes',
      materials: ['Sacred vermillion (kumkum)', 'Red sandalwood paste', 'Sacred ash (vibhuti)', 'Red flowers', 'Sacred threads', 'Protective amulets'],
      bestTimeFor: ['Legal matters', 'Protection needs', 'Overcoming fears', 'Competitive situations', 'Spiritual protection'],
      spiritualBenefits: [
        'Awakens inner strength and courage',
        'Provides divine protection',
        'Removes fear and anxiety',
        'Enhances spiritual warrior qualities'
      ],
      image: 'https://images.unsplash.com/photo-1599501900915-c5f6b9a5e0b6?w=400&h=300&fit=crop'
    },
    {
      id: 'sahasranamam',
      name: 'Sahasranamam',
      time: '8:00 PM - 9:00 PM',
      fees: 1200,
      dailyLimit: 5,
      description: 'Sacred recitation of Hanuman Sahasranamam with 1000 divine names',
      detailedDescription: 'Hanuman Sahasranamam is the divine recitation of Lord Hanuman\'s 1000 sacred names. This powerful prayer is considered one of the most potent spiritual practices for receiving Lord Hanuman\'s complete blessings. Each name carries specific divine energy that transforms the devotee\'s consciousness and removes all obstacles.',
      benefits: [
        'Complete spiritual transformation',
        'Removal of all types of obstacles and negativity',
        'Immense strength and courage in life',
        'Protection from all forms of evil and harm',
        'Fulfillment of deepest desires and wishes',
        'Peace of mind and emotional stability',
        'Enhanced devotion and spiritual growth'
      ],
      significance: 'The Sahasranamam contains the essence of Lord Hanuman\'s infinite power and compassion. Regular recitation or participation in this seva is believed to grant the devotee with unshakeable faith, divine protection, and the ability to overcome any challenge in life.',
      duration: '60 minutes',
      materials: ['Sacred texts and mantras', 'Camphor for aarti', 'Fresh flowers', 'Incense sticks', 'Sacred oil lamps', 'Offering plates', 'Holy water'],
      bestTimeFor: ['Major life challenges', 'Spiritual awakening', 'Complete transformation', 'Divine intervention needed', 'Seeking ultimate protection'],
      spiritualBenefits: [
        'Complete purification of consciousness',
        'Direct connection with Lord Hanuman\'s divine energy',
        'Awakening of inner spiritual powers',
        'Liberation from fear and anxiety',
        'Enhanced meditation and prayer effectiveness',
        'Karmic cleansing and spiritual elevation'
      ],
      image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop'
    }
  ];

  private constructor() {
    this.postgresService = PostgreSQLBookingService.getInstance();
    this.initializeService();
  }

  private async initializeService(): Promise<void> {
    try {
      // Check if PostgreSQL is available
      const status = await this.postgresService.getConnectionStatus();
      this.usePostgreSQL = status.connected;
      
      if (this.usePostgreSQL) {
        console.log('✅ Using PostgreSQL database');
      } else {
        console.log('⚠️  Using localStorage fallback');
        this.loadBookings();
      }
    } catch (error) {
      console.error('Database initialization error:', error);
      this.usePostgreSQL = false;
      this.loadBookings();
    }
  }

  public static getInstance(): BookingService {
    if (!BookingService.instance) {
      BookingService.instance = new BookingService();
    }
    return BookingService.instance;
  }

  private loadBookings(): void {
    const stored = localStorage.getItem('temple_bookings');
    if (stored) {
      this.bookings = JSON.parse(stored).map((booking: any) => ({
        ...booking,
        createdAt: new Date(booking.createdAt)
      }));
    }
  }

  private saveBookings(): void {
    localStorage.setItem('temple_bookings', JSON.stringify(this.bookings));
  }

  public async getSevaConfigs(): Promise<SevaConfig[]> {
    try {
      if (this.usePostgreSQL) {
        const configs = await this.postgresService.getSevaConfigs();
        return Array.isArray(configs) ? configs : this.sevaConfigs;
      }
      return this.sevaConfigs;
    } catch (error) {
      console.error('Error getting seva configs:', error);
      return this.sevaConfigs;
    }
  }

  public async getSevaById(sevaId: string): Promise<SevaConfig | null> {
    if (this.usePostgreSQL) {
      return await this.postgresService.getSevaById(sevaId);
    }
    return this.sevaConfigs.find(seva => seva.id === sevaId) || null;
  }

  public async getAvailableSlots(sevaId: string, date: Date): Promise<{ available: number; total: number; isAvailable: boolean }> {
    if (this.usePostgreSQL) {
      return await this.postgresService.getAvailableSlots(sevaId, date);
    }

    const sevaConfig = this.sevaConfigs.find(config => config.id === sevaId);
    if (!sevaConfig) return { available: 0, total: 0, isAvailable: false };

    const dateString = date.toISOString().split('T')[0];
    const dayBookings = this.bookings.filter(
      booking => booking.sevaId === sevaId && 
                 booking.date === dateString && 
                 booking.paymentStatus !== 'failed'
    );

    const available = sevaConfig.dailyLimit - dayBookings.length;
    return {
      available: Math.max(0, available),
      total: sevaConfig.dailyLimit,
      isAvailable: available > 0
    };
  }

  public async getAllAvailabilityForDate(date: Date): Promise<Record<string, { available: number; total: number; isAvailable: boolean }>> {
    if (this.usePostgreSQL) {
      return await this.postgresService.getAllAvailabilityForDate(date);
    }

    const result: Record<string, { available: number; total: number; isAvailable: boolean }> = {};
    
    for (const config of this.sevaConfigs) {
      result[config.id] = await this.getAvailableSlots(config.id, date);
    }

    return result;
  }

  public async makeBooking(booking: Omit<Booking, 'id' | 'createdAt'>): Promise<{ success: boolean; message: string; bookingId?: string }> {
    if (this.usePostgreSQL) {
      // Transform booking data for PostgreSQL service
      const postgresBooking = {
        seva_id: booking.sevaId,
        devotee_name: booking.devoteeName,
        devotee_phone: booking.phone,
        devotee_email: booking.email,
        booking_date: booking.date,
        time_slot: booking.time,
        amount: booking.amount,
        payment_status: booking.paymentStatus || 'pending',
        transaction_id: booking.transactionId
      };
      
      return await this.postgresService.makeBooking(postgresBooking);
    }

    // LocalStorage fallback
    const date = new Date(booking.date);
    const availability = await this.getAvailableSlots(booking.sevaId, date);
    
    if (!availability.isAvailable && booking.paymentStatus === 'paid') {
      return { success: false, message: 'No slots available for this seva on the selected date' };
    }

    // Create booking
    const newBooking: Booking = {
      ...booking,
      id: `BK${Date.now()}${Math.random().toString(36).substr(2, 9)}`,
      paymentStatus: booking.paymentStatus || 'pending',
      createdAt: new Date()
    };

    this.bookings.push(newBooking);
    this.saveBookings();

    return { 
      success: true, 
      message: booking.paymentStatus === 'paid' ? 'Booking confirmed successfully!' : 'Booking created successfully!', 
      bookingId: newBooking.id 
    };
  }

  public async updateBookingPaymentStatus(bookingId: string, status: 'pending' | 'paid' | 'failed' | 'refunded', transactionId?: string): Promise<{ success: boolean; message: string }> {
    if (this.usePostgreSQL) {
      return await this.postgresService.updateBookingPaymentStatus(bookingId, status, transactionId);
    }

    const bookingIndex = this.bookings.findIndex(booking => booking.id === bookingId);
    
    if (bookingIndex === -1) {
      return { success: false, message: 'Booking not found' };
    }

    this.bookings[bookingIndex].paymentStatus = status;
    if (transactionId) {
      this.bookings[bookingIndex].transactionId = transactionId;
    }

    this.saveBookings();

    return { success: true, message: 'Payment status updated successfully' };
  }

  public async getBookingByTransactionId(transactionId: string): Promise<Booking | null> {
    if (this.usePostgreSQL) {
      const booking = await this.postgresService.getBookingByTransactionId(transactionId);
      return booking ? this.transformPostgreSQLBooking(booking) : null;
    }
    
    return this.bookings.find(booking => booking.transactionId === transactionId) || null;
  }

  public async getBookings(filters?: { sevaId?: string; date?: string; devoteeName?: string; paymentStatus?: string }): Promise<Booking[]> {
    if (this.usePostgreSQL) {
      const bookings = await this.postgresService.getBookings(filters);
      return bookings.map(booking => this.transformPostgreSQLBooking(booking));
    }

    let filteredBookings = this.bookings;

    if (filters?.sevaId) {
      filteredBookings = filteredBookings.filter(booking => booking.sevaId === filters.sevaId);
    }

    if (filters?.date) {
      filteredBookings = filteredBookings.filter(booking => booking.date === filters.date);
    }

    if (filters?.devoteeName) {
      filteredBookings = filteredBookings.filter(booking => 
        booking.devoteeName.toLowerCase().includes(filters.devoteeName!.toLowerCase())
      );
    }

    if (filters?.paymentStatus) {
      filteredBookings = filteredBookings.filter(booking => booking.paymentStatus === filters.paymentStatus);
    }

    return filteredBookings.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  public async cancelBooking(bookingId: string): Promise<{ success: boolean; message: string }> {
    if (this.usePostgreSQL) {
      return await this.postgresService.cancelBooking(bookingId);
    }

    const index = this.bookings.findIndex(booking => booking.id === bookingId);
    
    if (index === -1) {
      return { success: false, message: 'Booking not found' };
    }

    const booking = this.bookings[index];
    
    // If booking was paid, mark for refund instead of deleting
    if (booking.paymentStatus === 'paid') {
      this.bookings[index].paymentStatus = 'refunded';
      this.saveBookings();
      return { success: true, message: 'Booking cancelled and refund initiated' };
    } else {
      this.bookings.splice(index, 1);
      this.saveBookings();
      return { success: true, message: 'Booking cancelled successfully' };
    }
  }

  // Admin functions to manage seva limits
  public async updateSevaLimit(sevaId: string, newLimit: number): Promise<{ success: boolean; message: string }> {
    if (this.usePostgreSQL) {
      return await this.postgresService.updateSevaLimit(sevaId, newLimit);
    }

    const sevaIndex = this.sevaConfigs.findIndex(config => config.id === sevaId);
    
    if (sevaIndex === -1) {
      return { success: false, message: 'Seva not found' };
    }

    this.sevaConfigs[sevaIndex].dailyLimit = newLimit;
    
    // In a real app, this would save to the database
    localStorage.setItem('temple_seva_configs', JSON.stringify(this.sevaConfigs));

    return { success: true, message: 'Seva limit updated successfully' };
  }

  // Get booking statistics
  public async getBookingStats(dateRange?: { start: Date; end: Date }): Promise<{
    totalBookings: number;
    paidBookings: number;
    totalRevenue: number;
    pendingPayments: number;
    sevaBreakdown: Record<string, { count: number; revenue: number; pending: number }>;
  }> {
    if (this.usePostgreSQL) {
      return await this.postgresService.getBookingStats(dateRange);
    }

    let bookings = this.bookings;

    if (dateRange) {
      const startDate = dateRange.start.toISOString().split('T')[0];
      const endDate = dateRange.end.toISOString().split('T')[0];
      bookings = bookings.filter(booking => booking.date >= startDate && booking.date <= endDate);
    }

    const paidBookings = bookings.filter(booking => booking.paymentStatus === 'paid');
    const pendingBookings = bookings.filter(booking => booking.paymentStatus === 'pending');

    const stats = {
      totalBookings: bookings.length,
      paidBookings: paidBookings.length,
      totalRevenue: paidBookings.reduce((sum, booking) => sum + booking.amount, 0),
      pendingPayments: pendingBookings.length,
      sevaBreakdown: {} as Record<string, { count: number; revenue: number; pending: number }>
    };

    bookings.forEach(booking => {
      if (!stats.sevaBreakdown[booking.sevaId]) {
        stats.sevaBreakdown[booking.sevaId] = { count: 0, revenue: 0, pending: 0 };
      }
      stats.sevaBreakdown[booking.sevaId].count++;
      
      if (booking.paymentStatus === 'paid') {
        stats.sevaBreakdown[booking.sevaId].revenue += booking.amount;
      } else if (booking.paymentStatus === 'pending') {
        stats.sevaBreakdown[booking.sevaId].pending++;
      }
    });

    return stats;
  }

  // Transform PostgreSQL booking to legacy format
  private transformPostgreSQLBooking(pgBooking: any): Booking {
    return {
      id: pgBooking.readable_id || pgBooking.id,
      sevaId: pgBooking.seva_id,
      sevaName: pgBooking.sevaName || (pgBooking.seva?.name) || '',
      date: pgBooking.booking_date || pgBooking.date,
      time: pgBooking.time_slot || pgBooking.time,
      devoteeName: pgBooking.devotee_name,
      phone: pgBooking.devotee_phone,
      email: pgBooking.devotee_email,
      amount: pgBooking.amount,
      transactionId: pgBooking.transaction_id,
      paymentStatus: pgBooking.payment_status,
      createdAt: new Date(pgBooking.created_at || pgBooking.createdAt)
    };
  }

  // Get database status
  public async getDatabaseStatus(): Promise<{ connected: boolean; type: 'postgresql' | 'localStorage'; message: string }> {
    if (this.usePostgreSQL) {
      const status = await this.postgresService.getConnectionStatus();
      return {
        connected: status.connected,
        type: 'postgresql',
        message: status.message
      };
    } else {
      return {
        connected: true,
        type: 'localStorage',
        message: 'Using localStorage fallback'
      };
    }
  }
}