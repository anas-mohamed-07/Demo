
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Button } from '../components/button';
import { Label } from '../components/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { Input } from '../components/Input';
import { Textarea } from '../components/Textarea';
import { useTranslation } from './localization_context';

export function ContactPage() {
  const { t } = useTranslation();
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [formErrors, setFormErrors] = useState({
    name: '',
    email: '',
    phone: ''
  });

  // Phone number validation function
  const validatePhoneNumber = (phone: string): string => {
    if (!phone) {
      return 'Phone number is required';
    }

    const digitsOnly = phone.replace(/\D/g, '');

    if (digitsOnly.length !== 10) {
      return 'Phone number must be exactly 10 digits';
    }

    return '';
  };

  // Email validation function
  const validateEmail = (email: string): string => {
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return 'Please enter a valid email address';
    }
    return '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate all fields
    const nameError = !contactForm.name.trim() ? 'Name is required' : '';
    const phoneError = validatePhoneNumber(contactForm.phone);
    const emailError = validateEmail(contactForm.email);

    const newErrors = {
      name: nameError,
      phone: phoneError,
      email: emailError
    };

    setFormErrors(newErrors);

    // Check if there are any errors
    if (nameError || phoneError || emailError) {
      return;
    }

    alert(t('contact.form_success'));
    setContactForm({ name: '', email: '', phone: '', subject: '', message: '' });
    setFormErrors({ name: '', email: '', phone: '' });
  };

  const handleInputChange = (field: string, value: string) => {
    let processedValue = value;

    // Special handling for phone number - only allow digits
    if (field === 'phone') {
      processedValue = value.replace(/\D/g, '');
      if (processedValue.length > 10) {
        processedValue = processedValue.slice(0, 10);
      }
    }

    setContactForm(prev => ({
      ...prev,
      [field]: processedValue
    }));

    // Clear error when user starts typing
    if (formErrors[field as keyof typeof formErrors]) {
      setFormErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };
  
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-[var(--temple-dark-brown)]">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[var(--temple-dark-brown)]">{t('contact.title')}</h1>
          <p className="text-xl text-[var(--temple-dark-brown)]/80">{t('contact.subtitle')}</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <h2 className="text-2xl font-bold text-[var(--temple-saffron)] mb-6">
              {t('contact.visit_us')}
            </h2>

            <div className="space-y-6">
              {/* Address */}
              <Card className="divine-glow">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <MapPin className="h-6 w-6 text-[var(--temple-saffron)] mr-4 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">{t('contact.address')}</h3>
                      <p className="text-gray-600">
                        {t('contact.full_address')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Phone */}
              <Card className="divine-glow">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <Phone className="h-6 w-6 text-[var(--temple-saffron)] mr-4 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">{t('contact.phone')}</h3>
                      <p className="text-gray-600">+91 80561 28486</p>
                      <p className="text-sm text-gray-500 mt-1">Available during temple hours</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Email */}
              <Card className="divine-glow">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <Mail className="h-6 w-6 text-[var(--temple-saffron)] mr-4 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">{t('contact.email')}</h3>
                      <p className="text-gray-600">anjaneyaraalayatrust2008@gmail.com</p>
                      <p className="text-sm text-gray-500 mt-1">We typically respond within 24 hours</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Temple Hours */}
              <Card className="divine-glow">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <Clock className="h-6 w-6 text-[var(--temple-saffron)] mr-4 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-800 mb-2">{t('contact.temple_timings')}</h3>
                      <div className="space-y-1 text-gray-600">
                        <p><strong>Daily Sevas:</strong> 5:00 PM - 8:00 PM</p>
                        <p><strong>{t('contact.morning_hours')}</strong></p>
                        <p><strong>{t('contact.evening_hours')}</strong></p>
                        <p><strong>Special Days:</strong> Extended hours on festivals</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            <Card className="divine-glow">
              <CardHeader>
                <CardTitle className="text-2xl text-[var(--temple-saffron)]">
                  {t('contact.send_message')}
                </CardTitle>
                <p className="text-gray-600">
                  Have questions about sevas, donations, or temple activities? We're here to help.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="contactName">{t('common.name')}</Label>
                      <Input
                        id="contactName"
                        value={contactForm.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        required
                        className={formErrors.name ? 'border-red-500' : ''}
                      />
                      {formErrors.name && (
                        <p className="text-red-500 text-xs mt-1">{formErrors.name}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="contactPhone">{t('common.phone')}</Label>
                      <Input
                        id="contactPhone"
                        type="tel"
                        value={contactForm.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        required
                        placeholder="Enter 10-digit phone number"
                        className={formErrors.phone ? 'border-red-500' : ''}
                        maxLength={10}
                      />
                      {formErrors.phone && (
                        <p className="text-red-500 text-xs mt-1">{formErrors.phone}</p>
                      )}
                      {contactForm.phone && !formErrors.phone && contactForm.phone.length === 10 && (
                        <p className="text-green-600 text-xs mt-1">✓ Valid phone number</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="contactEmail">{t('common.email')}</Label>
                    <Input
                      id="contactEmail"
                      type="email"
                      value={contactForm.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                      className={formErrors.email ? 'border-red-500' : ''}
                    />
                    {formErrors.email && (
                      <p className="text-red-500 text-xs mt-1">{formErrors.email}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="contactSubject">Subject</Label>
                    <Input
                      id="contactSubject"
                      value={contactForm.subject}
                      onChange={(e) => handleInputChange('subject', e.target.value)}
                      placeholder="e.g., Seva booking inquiry, Donation question, etc."
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="contactMessage">{t('common.message')}</Label>
                    <Textarea
                      id="contactMessage"
                      rows={5}
                      value={contactForm.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      placeholder={t('contact.message_placeholder')}
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
                    size="lg"
                  >
                    {t('contact.send')}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Map Section */}
        <Card className="mt-12">
          <CardHeader>
            <CardTitle className="text-2xl text-[var(--temple-saffron)] text-center">
              Find Us on Map
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full h-96 bg-gray-200 rounded-lg flex items-center justify-center">
              <div className="text-center text-gray-500">
                <MapPin className="h-12 w-12 mx-auto mb-4" />
                <p className="text-lg">Google Maps Embed</p>
                <p className="text-sm">181, Luz Church Road, Mylapore, Chennai</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Directions & Transportation */}
        <div className="grid md:grid-cols-2 gap-6 mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-[var(--temple-saffron)]">
                {t('contact.directions')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-gray-600">
                <p><strong>{t('contact.public_transport')}</strong></p>
                <p>{t('contact.bus_routes')}</p>
                <p>{t('contact.metro_station')}</p>
                <p>{t('contact.parking')}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-[var(--temple-saffron)]">
                Nearby Landmarks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-gray-600">
                <p><strong>Kapaleeshwarar Temple:</strong> 1.5 km</p>
                <p><strong>San Thome Cathedral:</strong> 2 km</p>
                <p><strong>Marina Beach:</strong> 3 km</p>
                <p><strong>Mylapore Tank:</strong> 0.5 km</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}