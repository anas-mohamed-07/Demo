import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Separator } from './ui/separator';
import { PaymentService, PaymentMethod, PaymentRequest } from './PaymentService';
import { SevaConfig } from './BookingService';
import { toast } from 'sonner@2.0.3';
import { Check, AlertCircle } from './ui/icons';

interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  seva: SevaConfig;
  selectedDate: Date;
  bookingDetails: {
    devoteeName: string;
    phone: string;
    email: string;
  };
  onPaymentSuccess: (transactionDetails: any) => void;
  onPaymentCancel: () => void;
}

export function PaymentDialog({
  open,
  onOpenChange,
  seva,
  selectedDate,
  bookingDetails,
  onPaymentSuccess,
  onPaymentCancel
}: PaymentDialogProps) {
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStage, setPaymentStage] = useState<'select' | 'processing' | 'success' | 'failed'>('select');
  const [paymentResult, setPaymentResult] = useState<any>(null);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);

  const paymentService = PaymentService.getInstance();

  // Define resetDialog function before useEffect
  const resetDialog = React.useCallback(() => {
    setPaymentStage('select');
    setPaymentResult(null);
    setSelectedPaymentMethod('');
    setIsProcessing(false);
  }, []);

  // Load payment methods when dialog opens and reset when closed
  useEffect(() => {
    if (open) {
      const methods = paymentService.getPaymentMethods();
      setPaymentMethods(methods);
      setSelectedPaymentMethod(methods[0]?.id || '');
    } else {
      // Reset state when dialog closes
      resetDialog();
    }
  }, [open, resetDialog]);

  const getPaymentMethodIcon = (type: string) => {
    switch (type) {
      case 'card': return <Check className="h-5 w-5" />;
      case 'upi': return <Check className="h-5 w-5" />;
      case 'netbanking': return <Check className="h-5 w-5" />;
      case 'wallet': return <Check className="h-5 w-5" />;
      default: return <Check className="h-5 w-5" />;
    }
  };

  const calculateTotal = () => {
    const baseAmount = seva.fees;
    const convenienceFee = Math.round(baseAmount * 0.02); // 2% convenience fee
    return {
      baseAmount,
      convenienceFee,
      total: baseAmount + convenienceFee
    };
  };

  const handlePayment = async () => {
    if (!selectedPaymentMethod) {
      toast.error('Please select a payment method');
      return;
    }

    setIsProcessing(true);
    setPaymentStage('processing');

    try {
      const { total } = calculateTotal();
      
      // Create payment request
      const paymentRequest: PaymentRequest = {
        amount: total,
        currency: 'INR',
        orderId: `SEVA_${Date.now()}`,
        description: `${seva.name} - ${selectedDate.toLocaleDateString()}`,
        customerDetails: {
          name: bookingDetails.devoteeName,
          email: bookingDetails.email,
          phone: bookingDetails.phone
        },
        metadata: {
          sevaId: seva.id,
          sevaName: seva.name,
          sevaDate: selectedDate.toISOString(),
          sevaTime: seva.time
        }
      };

      // Create order
      const orderResult = await paymentService.createOrder(paymentRequest);
      
      if (!orderResult.success) {
        throw new Error(orderResult.message);
      }

      // Process payment
      const paymentResult = await paymentService.processPayment(
        orderResult.orderId,
        selectedPaymentMethod,
        { amount: total }
      );

      if (paymentResult.success) {
        setPaymentStage('success');
        setPaymentResult(paymentResult);
        
        // Verify payment
        await paymentService.verifyPayment(paymentResult.transactionId);
        
        toast.success('Payment successful! Your seva has been booked.');
        
        // Pass transaction details to parent
        onPaymentSuccess({
          ...paymentResult,
          bookingDetails: {
            sevaId: seva.id,
            sevaName: seva.name,
            date: selectedDate.toISOString().split('T')[0],
            time: seva.time,
            devoteeName: bookingDetails.devoteeName,
            phone: bookingDetails.phone,
            email: bookingDetails.email
          }
        });
      } else {
        setPaymentStage('failed');
        setPaymentResult(paymentResult);
        toast.error(paymentResult.message);
      }
    } catch (error) {
      setPaymentStage('failed');
      toast.error('Payment processing failed. Please try again.');
      console.error('Payment error:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadReceipt = () => {
    if (paymentResult && paymentResult.success) {
      const receiptHTML = paymentService.generateReceiptHTML(paymentResult, {
        sevaName: seva.name,
        date: selectedDate.toLocaleDateString(),
        time: seva.time,
        devoteeName: bookingDetails.devoteeName
      });
      
      const blob = new Blob([receiptHTML], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `receipt-${paymentResult.receipt?.receiptId}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const { baseAmount, convenienceFee, total } = calculateTotal();

  return (
    <Dialog 
      open={open || false} 
      onOpenChange={(newOpen) => {
        onOpenChange(newOpen);
        if (!newOpen) {
          resetDialog();
        }
      }}
    >
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[var(--temple-saffron)]">
            {paymentStage === 'select' && 'Complete Payment'}
            {paymentStage === 'processing' && 'Processing Payment...'}
            {paymentStage === 'success' && 'Payment Successful!'}
            {paymentStage === 'failed' && 'Payment Failed'}
          </DialogTitle>
          <DialogDescription>
            {paymentStage === 'select' && 'Choose your preferred payment method to complete the seva booking.'}
            {paymentStage === 'processing' && 'Please wait while we process your payment. Do not close this window.'}
            {paymentStage === 'success' && 'Your payment has been processed successfully and your seva has been booked.'}
            {paymentStage === 'failed' && 'Your payment could not be processed. Please try again with a different payment method.'}
          </DialogDescription>
        </DialogHeader>

        {paymentStage === 'select' && (
          <div className="space-y-6">
            {/* Booking Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Seva:</span>
                  <span className="font-medium">{seva.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{selectedDate.toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Time:</span>
                  <span>{seva.time}</span>
                </div>
                <div className="flex justify-between">
                  <span>Devotee:</span>
                  <span>{bookingDetails.devoteeName}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span>Seva Fees:</span>
                  <span>₹{baseAmount}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Convenience Fee:</span>
                  <span>₹{convenienceFee}</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-semibold text-[var(--temple-saffron)]">
                  <span>Total Amount:</span>
                  <span>₹{total}</span>
                </div>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Select Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                  <div className="space-y-3">
                    {paymentMethods.map((method) => (
                      <div key={method.id} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value={method.id} id={method.id} />
                        <div className="flex items-center space-x-3 flex-1">
                          {getPaymentMethodIcon(method.type)}
                          <Label htmlFor={method.id} className="flex-1 cursor-pointer">
                            {method.name}
                          </Label>
                          <span className="text-2xl">{method.icon}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Payment Actions */}
            <div className="flex justify-end space-x-3">
              <Button variant="outline" onClick={onPaymentCancel}>
                Cancel
              </Button>
              <Button
                onClick={handlePayment}
                disabled={!selectedPaymentMethod || isProcessing}
                className="bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
              >
                Pay ₹{total}
              </Button>
            </div>
          </div>
        )}

        {paymentStage === 'processing' && (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-[var(--temple-saffron)] mx-auto mb-4"></div>
            <p className="text-lg mb-2">Processing your payment...</p>
            <p className="text-sm text-gray-500">Please do not close this window or press the back button.</p>
          </div>
        )}

        {paymentStage === 'success' && paymentResult && (
          <div className="text-center py-8 space-y-4">
            <Check className="h-16 w-16 text-green-500 mx-auto" />
            <div className="space-y-2">
              <h3 className="text-xl font-semibold text-green-700">Payment Successful!</h3>
              <p className="text-gray-600">Your seva has been booked successfully.</p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg text-left space-y-2">
              <div className="flex justify-between">
                <span>Transaction ID:</span>
                <span className="font-mono text-sm">{paymentResult.transactionId}</span>
              </div>
              <div className="flex justify-between">
                <span>Amount Paid:</span>
                <span className="font-semibold">₹{paymentResult.amount}</span>
              </div>
              <div className="flex justify-between">
                <span>Payment Method:</span>
                <span>{paymentResult.receipt?.paymentMethod}</span>
              </div>
            </div>

            <div className="flex justify-center space-x-3">
              <Button variant="outline" onClick={handleDownloadReceipt}>
                Download Receipt
              </Button>
              <Button onClick={() => onOpenChange(false)} className="bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800">
                Close
              </Button>
            </div>
          </div>
        )}

        {paymentStage === 'failed' && (
          <div className="text-center py-8 space-y-4">
            <AlertCircle className="h-16 w-16 text-red-500 mx-auto" />
            <div className="space-y-2">
              <h3 className="text-xl font-semibold text-red-700">Payment Failed</h3>
              <p className="text-gray-600">{paymentResult?.message || 'Something went wrong during payment processing.'}</p>
            </div>
            
            <div className="flex justify-center space-x-3">
              <Button variant="outline" onClick={() => setPaymentStage('select')}>
                Try Again
              </Button>
              <Button onClick={onPaymentCancel}>
                Cancel Booking
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}