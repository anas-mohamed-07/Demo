import { useState } from 'react';
import { Menu, X } from 'lucide-react';

import { useTranslation } from './localization_context';
import { LanguageSwitcher } from './language_switcher';
import { Button } from '../components/button';
import { useNavigate } from 'react-router-dom';

export function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [path, setPath] = useState('');
  const { t } = useTranslation();
  const navigate = useNavigate();

  const menuItems = [
    { id: '', label: t('nav.home') },
    { id: 'about', label: t('nav.about') },
    { id: 'bookings', label: t('nav.sevas') },
    { id: 'grants', label: t('nav.grants') },
    { id: 'gallery', label: t('nav.gallery') },
    { id: 'donation', label: t('nav.donations') },
    { id: 'contact', label: t('nav.contact') }
  ];

  const navigateToModule = (route: string) =>{
    navigate(`/${route}`);
    setPath(route);
  }

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center space-x-3">
              {/* <img 
                src={hanumanLogo} 
                alt="Hanuman Logo" 
                className="h-8 w-8 sm:h-10 sm:w-10 object-contain"
              /> */}
              <h1 className="text-xl sm:text-2xl font-bold text-[var(--temple-saffron)]">
                {t('home.title')}
              </h1>
            </div>
          </div>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center space-x-4">
            {menuItems.map((item,idx) => (
              <button
                key={item.id}
                onClick={() => navigateToModule(item.id)}
                className={`px-3 py-2 rounded-md transition-colors text-sm ${item.id === path
                    ? 'bg-[var(--temple-saffron)] text-white'
                    : 'text-gray-700 hover:bg-[var(--temple-gold)] hover:bg-opacity-20'
                  }`}
              >
                {item.label}
              </button>
            ))}
            <LanguageSwitcher />
          </div>

          {/* Tablet Menu */}
          <div className="hidden md:flex lg:hidden items-center space-x-2">
            <LanguageSwitcher />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-2">
            <LanguageSwitcher />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile/Tablet Menu */}
        {isMobileMenuOpen && (
          <div className="md:block lg:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              {menuItems.map((item,idx) => (
                <button
                  key={item.id}
                  onClick={() => {
                    navigateToModule(item.id)
                    setIsMobileMenuOpen(false);
                  }}
                  className={`block w-full text-left px-3 py-2 rounded-md transition-colors ${item.id === path
                      ? 'bg-[var(--temple-saffron)] text-white'
                      : 'text-gray-700 hover:bg-[var(--temple-gold)] hover:bg-opacity-20'
                    }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}