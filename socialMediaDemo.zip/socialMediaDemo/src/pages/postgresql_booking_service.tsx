// PostgreSQL BookingService using Supabase
// This replaces the current localStorage-based BookingService

import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { environmentConfig } from "./environment_config";



// Get Supabase configuration from environment manager
const supabaseConfig = environmentConfig.getSupabaseConfig();

// Create Supabase client only if we have valid configuration
let supabase: SupabaseClient | null = null;

if (supabaseConfig.isValid) {
  try {
    supabase = createClient(supabaseConfig.url, supabaseConfig.anonKey);
    console.log('✅ Supabase client initialized successfully');
  } catch (error) {
    console.error('❌ Failed to initialize Supabase client:', error);
    supabase = null;
  }
} else {
  // Check for development mode to suppress warnings
  try {
    const isDevMode = environmentConfig.isDevMode();
    
    if (isDevMode) {
      // Silent mode for development - minimal logging
      console.debug('🔧 Development mode - using localStorage fallback for bookings');
    } else {
      // Production mode - show helpful setup information
      console.info('📄 Database not configured - using localStorage for bookings (data won\'t persist between sessions)');
      console.group('🔧 Optional: Set up PostgreSQL database for persistent data storage');
      console.log('1. Copy .env.example to .env.local');
      console.log('2. Get your Supabase credentials from https://supabase.com');
      console.log('3. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env.local');
      console.log('4. See POSTGRESQL_SETUP_GUIDE.md for full setup instructions');
      console.log('💡 Set VITE_DEV_MODE=true in .env.local to minimize these messages');
      console.groupEnd();
    }
  } catch (error) {
    // If environment config fails, show minimal message
    console.debug('🔄 Booking service initialized with localStorage fallback');
  }
}

// Database interfaces matching PostgreSQL schema
export interface Booking {
  id?: string;
  readable_id?: string;
  seva_id: string;
  devotee_name: string;
  devotee_phone: string;
  devotee_email: string;
  booking_date: string;
  time_slot: string;
  amount: number;
  payment_status?: 'pending' | 'paid' | 'failed' | 'refunded';
  transaction_id?: string;
  payment_method?: string;
  confirmation_sent?: boolean;
  reminder_sent?: boolean;
  seva_completed?: boolean;
  notes?: string;
  created_at?: string;
  updated_at?: string;
  
  // Legacy fields for backward compatibility
  sevaName?: string;
  date?: string;
  time?: string;
  devoteeName?: string;
  phone?: string;
  email?: string;
  paymentStatus?: 'pending' | 'paid' | 'failed' | 'refunded';
  createdAt?: Date;
}

export interface SevaConfig {
  id: string;
  name: string;
  name_ta?: string;
  time_slot: string;
  fees: number;
  daily_limit: number;
  description: string;
  description_ta?: string;
  detailed_description?: string;
  benefits: string[];
  significance?: string;
  duration: number;
  materials: string[];
  best_time_for?: string[];
  spiritual_benefits?: string[];
  image?: string;
  active: boolean;
  
  // Legacy fields for backward compatibility
  time?: string;
  dailyLimit?: number;
  detailedDescription?: string;
  bestTimeFor?: string[];
  spiritualBenefits?: string[];
}

export interface DatabaseBooking {
  id: string;
  readable_id: string;
  seva_id: string;
  devotee_name: string;
  devotee_phone: string;
  devotee_email: string;
  booking_date: string;
  time_slot: string;
  amount: number;
  payment_status: string;
  transaction_id?: string;
  payment_method?: string;
  confirmation_sent: boolean;
  reminder_sent: boolean;
  seva_completed: boolean;
  notes?: string;
  created_at: string;
  updated_at: string;
  seva?: {
    name: string;
    time_slot: string;
  };
}

export class PostgreSQLBookingService {
  private static instance: PostgreSQLBookingService;
  private supabase: SupabaseClient | null;

  private constructor() {
    this.supabase = supabase;
    if (supabase) {
      this.initializeConnection();
    } else {
      console.log('🔄 PostgreSQL service initialized in fallback mode');
    }
  }

  public static getInstance(): PostgreSQLBookingService {
    if (!PostgreSQLBookingService.instance) {
      PostgreSQLBookingService.instance = new PostgreSQLBookingService();
    }
    return PostgreSQLBookingService.instance;
  }

  private async initializeConnection(): Promise<void> {
    if (!this.supabase) {
      console.warn('⚠️  Supabase client not available');
      return;
    }

    try {
      // Test connection with a simple query
      const { data, error } = await this.supabase.from('sevas').select('count').limit(1);
      if (error) {
        console.error('Database connection error:', error);
        console.log('This is expected if database tables haven\'t been created yet.');
        console.log('Please run the database schema from POSTGRESQL_INTEGRATION.md');
      } else {
        console.log('✅ Connected to PostgreSQL database via Supabase');
      }
    } catch (error) {
      console.error('Failed to connect to database:', error);
      console.log('This might be due to network issues or missing configuration.');
    }
  }

  // Get connection status
  public async getConnectionStatus(): Promise<{ connected: boolean; message: string }> {
    if (!this.supabase) {
      return {
        connected: false,
        message: 'Supabase client not initialized. Using localStorage fallback.'
      };
    }

    try {
      const { data, error } = await this.supabase.from('sevas').select('count').limit(1);
      
      if (error) {
        return {
          connected: false,
          message: `Database connection error: ${error.message}`
        };
      }

      return {
        connected: true,
        message: 'Successfully connected to PostgreSQL database'
      };
    } catch (error) {
      return {
        connected: false,
        message: `Connection test failed: ${error}`
      };
    }
  }

  // Get all seva configurations
  public async getSevaConfigs(): Promise<SevaConfig[]> {
    if (!this.supabase) {
      console.log('📄 Using default seva configurations (no database connection)');
      return this.getDefaultSevaConfigs();
    }

    try {
      const { data, error } = await this.supabase
        .from('sevas')
        .select('*')
        .eq('active', true)
        .order('id');

      if (error) {
        console.error('Error fetching sevas from database:', error);
        console.log('📄 Falling back to default seva configurations');
        return this.getDefaultSevaConfigs();
      }

      if (!data || data.length === 0) {
        console.log('📄 No sevas found in database, using defaults');
        return this.getDefaultSevaConfigs();
      }

      return data.map((seva: any)=> ({
        ...seva,
        // Map new fields to legacy fields for backward compatibility
        time: seva.time_slot,
        dailyLimit: seva.daily_limit,
        detailedDescription: seva.detailed_description,
        bestTimeFor: seva.best_time_for || [],
        spiritualBenefits: seva.spiritual_benefits || [],
        image: seva.image || this.getDefaultSevaImage(seva.id)
      }));
    } catch (error) {
      console.error('Error fetching sevas:', error);
      console.log('📄 Falling back to default seva configurations');
      return this.getDefaultSevaConfigs();
    }
  }

  // Get seva by ID
  public async getSevaById(sevaId: string): Promise<SevaConfig | null> {
    if (!this.supabase) {
      const defaultSevas = this.getDefaultSevaConfigs();
      return defaultSevas.find(seva => seva.id === sevaId) || null;
    }

    try {
      const { data, error } = await this.supabase
        .from('sevas')
        .select('*')
        .eq('id', sevaId)
        .single();

      if (error || !data) {
        console.error('Error fetching seva from database:', error);
        // Fallback to default configurations
        const defaultSevas = this.getDefaultSevaConfigs();
        return defaultSevas.find(seva => seva.id === sevaId) || null;
      }

      return {
        ...data,
        time: data.time_slot,
        dailyLimit: data.daily_limit,
        detailedDescription: data.detailed_description,
        bestTimeFor: data.best_time_for || [],
        spiritualBenefits: data.spiritual_benefits || [],
        image: data.image || this.getDefaultSevaImage(data.id)
      };
    } catch (error) {
      console.error('Error fetching seva by ID:', error);
      // Fallback to default configurations
      const defaultSevas = this.getDefaultSevaConfigs();
      return defaultSevas.find(seva => seva.id === sevaId) || null;
    }
  }

  // Check available slots for a seva on a specific date
  public async getAvailableSlots(sevaId: string, date: Date): Promise<{ 
    available: number; 
    total: number; 
    isAvailable: boolean; 
  }> {
    if (!this.supabase) {
      // Fallback to local availability check
      const sevaConfig = this.getSevaConfigById(sevaId);
      if (!sevaConfig) {
        return { available: 0, total: 0, isAvailable: false };
      }
      
      // In fallback mode, assume all slots are available
      return {
        available: sevaConfig.dailyLimit || sevaConfig.daily_limit || 10,
        total: sevaConfig.dailyLimit || sevaConfig.daily_limit || 10,
        isAvailable: true
      };
    }

    try {
      const dateString = date.toISOString().split('T')[0];

      // Get seva configuration
      const { data: sevaData, error: sevaError } = await this.supabase
        .from('sevas')
        .select('daily_limit')
        .eq('id', sevaId)
        .single();

      if (sevaError || !sevaData) {
        console.error('Error fetching seva config from database:', sevaError);
        // Fallback to default configuration
        const sevaConfig = this.getSevaConfigById(sevaId);
        if (!sevaConfig) {
          return { available: 0, total: 0, isAvailable: false };
        }
        return {
          available: sevaConfig.dailyLimit || sevaConfig.daily_limit || 10,
          total: sevaConfig.dailyLimit || sevaConfig.daily_limit || 10,
          isAvailable: true
        };
      }

      // Get booking count for this date
      const { count, error: countError } = await this.supabase
        .from('bookings')
        .select('*', { count: 'exact', head: true })
        .eq('seva_id', sevaId)
        .eq('booking_date', dateString)
        .neq('payment_status', 'failed');

      if (countError) {
        console.error('Error counting bookings:', countError);
        return { available: 0, total: sevaData.daily_limit, isAvailable: false };
      }

      const bookedCount = count || 0;
      const available = Math.max(0, sevaData.daily_limit - bookedCount);

      return {
        available,
        total: sevaData.daily_limit,
        isAvailable: available > 0
      };
    } catch (error) {
      console.error('Error checking availability:', error);
      // Fallback behavior
      const sevaConfig = this.getSevaConfigById(sevaId);
      if (!sevaConfig) {
        return { available: 0, total: 0, isAvailable: false };
      }
      return {
        available: sevaConfig.dailyLimit || sevaConfig.daily_limit || 10,
        total: sevaConfig.dailyLimit || sevaConfig.daily_limit || 10,
        isAvailable: true
      };
    }
  }

  // Get availability for all sevas on a specific date
  public async getAllAvailabilityForDate(date: Date): Promise<Record<string, { 
    available: number; 
    total: number; 
    isAvailable: boolean; 
  }>> {
    try {
      const sevas = await this.getSevaConfigs();
      const result: Record<string, { available: number; total: number; isAvailable: boolean }> = {};

      for (const seva of sevas) {
        result[seva.id] = await this.getAvailableSlots(seva.id, date);
      }

      return result;
    } catch (error) {
      console.error('Error getting availability for date:', error);
      return {};
    }
  }

  // Helper method to get seva config by ID from default configs
  private getSevaConfigById(sevaId: string): SevaConfig | null {
    const defaultConfigs = this.getDefaultSevaConfigs();
    return defaultConfigs.find(seva => seva.id === sevaId) || null;
  }

  // Helper method to get default seva image
  private getDefaultSevaImage(sevaId: string): string {
    const imageMap: Record<string, string> = {
      'thirumanjanam': 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop',
      'vadamalai': 'https://images.unsplash.com/photo-1604623842888-8ab8cf339ead?w=400&h=300&fit=crop',
      'santhana-kaapu': 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=400&h=300&fit=crop',
      'vennai-kaapu': 'https://images.unsplash.com/photo-1566996533071-82ad21517ea7?w=400&h=300&fit=crop',
      'senthoora-kaapu': 'https://images.unsplash.com/photo-1599501900915-c5f6b9a5e0b6?w=400&h=300&fit=crop',
      'sahasranamam': 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop'
    };
    return imageMap[sevaId] || 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop';
  }

  // Default seva configurations (fallback)
  private getDefaultSevaConfigs(): SevaConfig[] {
    return [
      {
        id: 'thirumanjanam',
        name: 'Thirumanjanam',
        time_slot: '5:00 PM - 6:00 PM',
        fees: 1000,
        daily_limit: 10,
        description: 'Sacred ablution ceremony with milk, honey, and fragrant oils',
        detailed_description: 'Thirumanjanam is one of the most sacred rituals performed to Lord Hanuman. This elaborate abhisheka involves bathing the deity with pure milk, honey, ghee, curd, and fragrant oils while chanting powerful mantras.',
        benefits: [
          'Purification of mind, body, and soul',
          'Removal of negative energies and obstacles',
          'Enhanced spiritual awareness and devotion',
          'Blessings for good health and vitality',
          'Protection from evil influences'
        ],
        significance: 'Lord Hanuman is known as the remover of obstacles and protector of devotees. The Thirumanjanam ceremony invokes his divine energy to cleanse and protect the devotee from all forms of negativity.',
        duration: 60,
        materials: ['Pure cow milk', 'Organic honey', 'Clarified butter (ghee)', 'Fresh curd', 'Sacred oils', 'Holy water', 'Fresh flowers'],
        best_time_for: ['New beginnings', 'Overcoming challenges', 'Spiritual purification', 'Health issues', 'Mental peace'],
        spiritual_benefits: [
          'Increases devotion and faith',
          'Removes karmic obstacles',
          'Enhances meditation and prayer effectiveness',
          'Brings divine grace and blessings'
        ],
        active: true,
        time: '5:00 PM - 6:00 PM',
        dailyLimit: 10,
        detailedDescription: 'Thirumanjanam is one of the most sacred rituals performed to Lord Hanuman. This elaborate abhisheka involves bathing the deity with pure milk, honey, ghee, curd, and fragrant oils while chanting powerful mantras.',
        bestTimeFor: ['New beginnings', 'Overcoming challenges', 'Spiritual purification', 'Health issues', 'Mental peace'],
        spiritualBenefits: [
          'Increases devotion and faith',
          'Removes karmic obstacles',
          'Enhances meditation and prayer effectiveness',
          'Brings divine grace and blessings'
        ],
        image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop'
      },
      {
        id: 'vadamalai',
        name: 'Vadamalai',
        time_slot: '6:00 PM - 6:30 PM',
        fees: 500,
        daily_limit: 50,
        description: 'Garland offering with fresh flowers and sacred chants',
        detailed_description: 'Vadamalai is the ceremonial offering of beautiful flower garlands to Lord Hanuman. Fresh marigolds, jasmine, and lotus flowers are specially arranged and offered with devotional songs and mantras.',
        benefits: [
          'Brings joy and happiness in life',
          'Enhances beauty and attractiveness',
          'Improves relationships and social harmony', 
          'Attracts prosperity and abundance',
          'Removes depression and sadness'
        ],
        significance: 'Flowers represent the blossoming of the soul and the offering of one\'s best to the divine. Lord Hanuman accepts these offerings and blesses devotees with happiness and fulfillment.',
        duration: 30,
        materials: ['Fresh marigold garlands', 'Jasmine flowers', 'Lotus petals', 'Rose garlands', 'Tulsi leaves', 'Sacred basil'],
        best_time_for: ['Celebrations', 'New relationships', 'Business ventures', 'Artistic pursuits', 'Social gatherings'],
        spiritual_benefits: [
          'Cultivates love and compassion',
          'Develops aesthetic sense and appreciation',
          'Enhances emotional well-being',
          'Promotes harmony in relationships'
        ],
        active: true,
        time: '6:00 PM - 6:30 PM',
        dailyLimit: 50,
        detailedDescription: 'Vadamalai is the ceremonial offering of beautiful flower garlands to Lord Hanuman. Fresh marigolds, jasmine, and lotus flowers are specially arranged and offered with devotional songs and mantras.',
        bestTimeFor: ['Celebrations', 'New relationships', 'Business ventures', 'Artistic pursuits', 'Social gatherings'],
        spiritualBenefits: [
          'Cultivates love and compassion',
          'Develops aesthetic sense and appreciation',
          'Enhances emotional well-being',
          'Promotes harmony in relationships'
        ],
        image: 'https://images.unsplash.com/photo-1604623842888-8ab8cf339ead?w=400&h=300&fit=crop'
      },
      {
        id: 'santhana-kaapu',
        name: 'Santhana Kaapu',
        time_slot: '6:30 PM - 7:00 PM',
        fees: 1000,
        daily_limit: 10,
        description: 'Special prayers for progeny and family welfare',
        detailed_description: 'Santhana Kaapu is a powerful seva specifically performed for family welfare, fertility, and the blessing of children. This ceremony involves special mantras and offerings that invoke Lord Hanuman\'s blessings for expanding the family lineage.',
        benefits: [
          'Blessings for conception and childbirth',
          'Protection for pregnant mothers',
          'Healthy development of children',
          'Family harmony and unity',
          'Generational blessings and prosperity'
        ],
        significance: 'Lord Hanuman is revered as a protector of families and children. This seva is particularly powerful for couples seeking children and families wanting divine protection for their loved ones.',
        duration: 30,
        materials: ['Vermillion paste', 'Turmeric powder', 'Sacred rice', 'Coconut', 'Bananas', 'Betel leaves', 'Sacred thread'],
        best_time_for: ['Couples planning family', 'Pregnant mothers', 'Child protection', 'Family difficulties', 'Ancestral blessings'],
        spiritual_benefits: [
          'Strengthens family bonds',
          'Removes obstacles to parenthood',
          'Ensures healthy progeny',
          'Invokes ancestral blessings'
        ],
        active: true,
        time: '6:30 PM - 7:00 PM',
        dailyLimit: 10,
        detailedDescription: 'Santhana Kaapu is a powerful seva specifically performed for family welfare, fertility, and the blessing of children. This ceremony involves special mantras and offerings that invoke Lord Hanuman\'s blessings for expanding the family lineage.',
        bestTimeFor: ['Couples planning family', 'Pregnant mothers', 'Child protection', 'Family difficulties', 'Ancestral blessings'],
        spiritualBenefits: [
          'Strengthens family bonds',
          'Removes obstacles to parenthood',
          'Ensures healthy progeny',
          'Invokes ancestral blessings'
        ],
        image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=400&h=300&fit=crop'
      },
      {
        id: 'vennai-kaapu',
        name: 'Vennai Kaapu',
        time_slot: '7:00 PM - 7:30 PM',
        fees: 1000,
        daily_limit: 10,
        description: 'Butter offering ceremony for prosperity and health',
        detailed_description: 'Vennai Kaapu involves offering fresh butter to Lord Hanuman, symbolizing purity, nourishment, and abundance. This ceremony is particularly beneficial for health, prosperity, and removing financial difficulties.',
        benefits: [
          'Improved physical health and strength',
          'Financial prosperity and wealth',
          'Nourishment for body and soul',
          'Sweet relationships and harmony',
          'Abundance in all life aspects'
        ],
        significance: 'Butter is considered one of the purest foods and is beloved by Lord Hanuman. Offering butter symbolizes offering the best and purest intentions to receive divine blessings for health and prosperity.',
        duration: 30,
        materials: ['Fresh white butter', 'Pure ghee', 'Honey', 'Jaggery', 'Dry fruits', 'Milk sweets'],
        best_time_for: ['Health issues', 'Financial difficulties', 'Business growth', 'Physical weakness', 'Seeking abundance'],
        spiritual_benefits: [
          'Purifies thoughts and intentions',
          'Enhances physical and spiritual strength',
          'Attracts divine grace and abundance',
          'Promotes contentment and satisfaction'
        ],
        active: true,
        time: '7:00 PM - 7:30 PM',
        dailyLimit: 10,
        detailedDescription: 'Vennai Kaapu involves offering fresh butter to Lord Hanuman, symbolizing purity, nourishment, and abundance. This ceremony is particularly beneficial for health, prosperity, and removing financial difficulties.',
        bestTimeFor: ['Health issues', 'Financial difficulties', 'Business growth', 'Physical weakness', 'Seeking abundance'],
        spiritualBenefits: [
          'Purifies thoughts and intentions',
          'Enhances physical and spiritual strength',
          'Attracts divine grace and abundance',
          'Promotes contentment and satisfaction'
        ],
        image: 'https://images.unsplash.com/photo-1566996533071-82ad21517ea7?w=400&h=300&fit=crop'
      },
      {
        id: 'senthoora-kaapu',
        name: 'Senthoora Kaapu',
        time_slot: '7:30 PM - 8:00 PM',
        fees: 1000,
        daily_limit: 10,
        description: 'Vermillion offering for protection and blessings',
        detailed_description: 'Senthoora Kaapu is the ceremonial application of sacred vermillion (kumkum) to Lord Hanuman. This powerful seva is known for providing protection against negative forces, evil eye, and granting courage and strength.',
        benefits: [
          'Protection from negative energies',
          'Increased courage and confidence',
          'Victory over enemies and obstacles',
          'Enhanced willpower and determination',
          'Divine shield against evil influences'
        ],
        significance: 'Vermillion is sacred to Lord Hanuman and represents his fierce protective nature. This seva is especially powerful for those facing challenges, legal issues, or needing divine intervention in difficult situations.',
        duration: 30,
        materials: ['Sacred vermillion (kumkum)', 'Red sandalwood paste', 'Sacred ash (vibhuti)', 'Red flowers', 'Sacred threads', 'Protective amulets'],
        best_time_for: ['Legal matters', 'Protection needs', 'Overcoming fears', 'Competitive situations', 'Spiritual protection'],
        spiritual_benefits: [
          'Awakens inner strength and courage',
          'Provides divine protection',
          'Removes fear and anxiety',
          'Enhances spiritual warrior qualities'
        ],
        active: true,
        time: '7:30 PM - 8:00 PM',
        dailyLimit: 10,
        detailedDescription: 'Senthoora Kaapu is the ceremonial application of sacred vermillion (kumkum) to Lord Hanuman. This powerful seva is known for providing protection against negative forces, evil eye, and granting courage and strength.',
        bestTimeFor: ['Legal matters', 'Protection needs', 'Overcoming fears', 'Competitive situations', 'Spiritual protection'],
        spiritualBenefits: [
          'Awakens inner strength and courage',
          'Provides divine protection',
          'Removes fear and anxiety',
          'Enhances spiritual warrior qualities'
        ],
        image: 'https://images.unsplash.com/photo-1599501900915-c5f6b9a5e0b6?w=400&h=300&fit=crop'
      },
      {
        id: 'sahasranamam',
        name: 'Sahasranamam',
        time_slot: '8:00 PM - 9:00 PM',
        fees: 1200,
        daily_limit: 5,
        description: 'Sacred recitation of Hanuman Sahasranamam with 1000 divine names',
        detailed_description: 'Hanuman Sahasranamam is the divine recitation of Lord Hanuman\'s 1000 sacred names. This powerful prayer is considered one of the most potent spiritual practices for receiving Lord Hanuman\'s complete blessings. Each name carries specific divine energy that transforms the devotee\'s consciousness and removes all obstacles.',
        benefits: [
          'Complete spiritual transformation',
          'Removal of all types of obstacles and negativity',
          'Immense strength and courage in life',
          'Protection from all forms of evil and harm',
          'Fulfillment of deepest desires and wishes',
          'Peace of mind and emotional stability',
          'Enhanced devotion and spiritual growth'
        ],
        significance: 'The Sahasranamam contains the essence of Lord Hanuman\'s infinite power and compassion. Regular recitation or participation in this seva is believed to grant the devotee with unshakeable faith, divine protection, and the ability to overcome any challenge in life.',
        duration: 60,
        materials: ['Sacred texts and mantras', 'Camphor for aarti', 'Fresh flowers', 'Incense sticks', 'Sacred oil lamps', 'Offering plates', 'Holy water'],
        best_time_for: ['Major life challenges', 'Spiritual awakening', 'Complete transformation', 'Divine intervention needed', 'Seeking ultimate protection'],
        spiritual_benefits: [
          'Complete purification of consciousness',
          'Direct connection with Lord Hanuman\'s divine energy',
          'Awakening of inner spiritual powers',
          'Liberation from fear and anxiety',
          'Enhanced meditation and prayer effectiveness',
          'Karmic cleansing and spiritual elevation'
        ],
        active: true,
        time: '8:00 PM - 9:00 PM',
        dailyLimit: 5,
        detailedDescription: 'Hanuman Sahasranamam is the divine recitation of Lord Hanuman\'s 1000 sacred names. This powerful prayer is considered one of the most potent spiritual practices for receiving Lord Hanuman\'s complete blessings. Each name carries specific divine energy that transforms the devotee\'s consciousness and removes all obstacles.',
        bestTimeFor: ['Major life challenges', 'Spiritual awakening', 'Complete transformation', 'Divine intervention needed', 'Seeking ultimate protection'],
        spiritualBenefits: [
          'Complete purification of consciousness',
          'Direct connection with Lord Hanuman\'s divine energy',
          'Awakening of inner spiritual powers',
          'Liberation from fear and anxiety',
          'Enhanced meditation and prayer effectiveness',
          'Karmic cleansing and spiritual elevation'
        ],
        image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop'
      }
    ];
  }
}