import { MapPin, Phone, Mail } from 'lucide-react';
import { useTranslation } from './localization_context';
import { useState } from 'react';

export function Footer() {
  const { t } = useTranslation();
    const [index, setIndex] = useState(0);

  const quickLinks = [
    { id: 'home', label: t('nav.home') },
    { id: 'about', label: t('nav.about') },
    { id: 'bookings', label: t('nav.sevas') },
    { id: 'grants', label: t('nav.grants') },
    { id: 'gallery', label: t('nav.gallery') },
    { id: 'donation', label: t('nav.donations') },
    { id: 'contact', label: t('nav.contact') }
  ];

  return (
    <footer className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] text-white temple-bg-pattern">
      <div className="bg-[#2C1503] bg-opacity-60">
        <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Temple Info */}
            <div>
              <h3 className="text-xl font-bold mb-4">🕉️ {t('home.title')}</h3>
              <p className="mb-4 opacity-90">
                {t('home.temple_desc')}
              </p>
              <p className="text-sm opacity-80">
                "{t('home.temple_heritage')}"
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-xl font-bold mb-4">{t('footer.quick_links')}</h3>
              <div className="grid grid-cols-2 gap-2">
                {quickLinks.map((link,idx) => (
                  <button
                    key={link.id}
                    onClick={() => setIndex(idx)}
                    className="text-left text-sm opacity-90 hover:opacity-100 hover:underline transition-opacity text-gray-950"
                  >
                    {link.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="text-xl font-bold mb-4">{t('footer.temple_info')}</h3>
              <div className="space-y-3">
                <div className="flex items-start">
                  <MapPin className="h-4 w-4 mr-2 mt-1 opacity-90" />
                  <p className="text-sm opacity-90">
                    181, Luz Church Road<br />
                    {t('footer.address')}
                  </p>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2 opacity-90" />
                  <p className="text-sm opacity-90">+91 80561 28486</p>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 opacity-90" />
                  <p className="text-sm opacity-90">anjaneyaraalayatrust2008@gmail.com</p>
                </div>
              </div>

              {/* Temple Timings */}
              <div className="mt-6">
                <h4 className="font-semibold mb-2">{t('footer.timings')}</h4>
                <div className="text-sm opacity-90 space-y-1">
                  <p>{t('footer.morning')}</p>
                  <p>{t('footer.evening')}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="border-t border-white border-opacity-20 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm opacity-80 mb-4 md:mb-0">
              © 2024 {t('home.title')}. {t('footer.rights')}
            </p>
            <p className="text-sm opacity-80">
              {t('footer.developed')}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}