import { useEffect, useState } from 'react';

import { GraduationCap, Heart, Upload, IndianRupee } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { Label } from '../components/label';
import { Input } from '../components/Input';
import { Textarea } from '../components/Textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/Select';
import { Button } from '../components/button';

export function GrantsPage() {
  const [educationForm, setEducationForm] = useState({
    studentName: '',
    parentName: '',
    dob: '',
    phone: '',
    email: '',
    address: '',
    course: '',
    institution: '',
    year: '',
    fees: '',
    bankAccount: '',
    ifsc: '',
    bankName: ''
  });

  const [medicalForm, setMedicalForm] = useState({
    applicantName: '',
    dob: '',
    phone: '',
    email: '',
    address: '',
    disease: '',
    hospital: '',
    doctor: '',
    treatmentCost: '',
    bankAccount: '',
    ifsc: '',
    bankName: ''
  });

  const handleEducationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Educational assistance application submitted successfully!');
  };

  const handleMedicalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Medical assistance application submitted successfully!');
  };

    useEffect(()=>{
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },[])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-[var(--temple-dark-brown)]">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[var(--temple-dark-brown)]">Assistance Grants</h1>
          <p className="text-xl text-[var(--temple-dark-brown)]/80">Supporting Education &amp; Healthcare in Our Community</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs value="education" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="education" className="flex items-center">
              <GraduationCap className="h-4 w-4 mr-2" />
              Educational Assistance
            </TabsTrigger>
            <TabsTrigger value="medical" className="flex items-center">
              <Heart className="h-4 w-4 mr-2" />
              Medical Assistance
            </TabsTrigger>
          </TabsList>

          {/* Educational Assistance Tab */}
          <TabsContent value="education">
            <Card className="divine-glow">
              <CardHeader>
                <CardTitle className="text-2xl text-[var(--temple-saffron)] flex items-center">
                  <GraduationCap className="h-6 w-6 mr-2" />
                  Educational Assistance Application
                </CardTitle>
                <p className="text-gray-600">
                  Apply for financial assistance for educational expenses. This program supports deserving students in their academic journey.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleEducationSubmit} className="space-y-6">
                  {/* Student Information */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Student Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="studentName">Student Name</Label>
                        <Input
                          id="studentName"
                          value={educationForm.studentName}
                          onChange={(e) => setEducationForm({...educationForm, studentName: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="parentName">Parent/Guardian Name</Label>
                        <Input
                          id="parentName"
                          value={educationForm.parentName}
                          onChange={(e) => setEducationForm({...educationForm, parentName: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="dob">Date of Birth</Label>
                        <Input
                          id="dob"
                          type="date"
                          value={educationForm.dob}
                          onChange={(e) => setEducationForm({...educationForm, dob: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Mobile Number</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={educationForm.phone}
                          onChange={(e) => setEducationForm({...educationForm, phone: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email Address</Label>
                        <Input
                          id="email"
                          type="email"
                          value={educationForm.email}
                          onChange={(e) => setEducationForm({...educationForm, email: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label htmlFor="address">Address</Label>
                      <Textarea
                        id="address"
                        value={educationForm.address}
                        onChange={(e) => setEducationForm({...educationForm, address: e.target.value})}
                        required
                      />
                    </div>
                  </div>

                  {/* Educational Details */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Educational Details</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="course">Course/Degree</Label>
                        <Input
                          id="course"
                          value={educationForm.course}
                          onChange={(e) => setEducationForm({...educationForm, course: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="institution">Institution Name</Label>
                        <Input
                          id="institution"
                          value={educationForm.institution}
                          onChange={(e) => setEducationForm({...educationForm, institution: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="year">Academic Year</Label>
                        <Select onValueChange={(value) => setEducationForm({...educationForm, year: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select year" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="2024-25">2024-25</SelectItem>
                            <SelectItem value="2025-26">2025-26</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="fees">Annual Fees Amount</Label>
                        <Input
                          id="fees"
                          type="number"
                          value={educationForm.fees}
                          onChange={(e) => setEducationForm({...educationForm, fees: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Bank Details */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Bank Details</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="bankAccount">Account Number</Label>
                        <Input
                          id="bankAccount"
                          value={educationForm.bankAccount}
                          onChange={(e) => setEducationForm({...educationForm, bankAccount: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="ifsc">IFSC Code</Label>
                        <Input
                          id="ifsc"
                          value={educationForm.ifsc}
                          onChange={(e) => setEducationForm({...educationForm, ifsc: e.target.value})}
                          required
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="bankName">Bank Name &amp; Branch</Label>
                        <Input
                          id="bankName"
                          value={educationForm.bankName}
                          onChange={(e) => setEducationForm({...educationForm, bankName: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Documents */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Required Documents</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label>Fees Receipt</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload fees receipt</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>Bonafide Certificate</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload certificate</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>EWS Certificate</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload EWS certificate</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>Student Photo</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload photo</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
                  >
                    Submit Application
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Medical Assistance Tab */}
          <TabsContent value="medical">
            <Card className="divine-glow">
              <CardHeader>
                <CardTitle className="text-2xl text-[var(--temple-saffron)] flex items-center">
                  <Heart className="h-6 w-6 mr-2" />
                  Medical Assistance Application
                </CardTitle>
                <p className="text-gray-600">
                  Apply for financial assistance for medical treatment expenses. This program provides support during health emergencies.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleMedicalSubmit} className="space-y-6">
                  {/* Applicant Information */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Applicant Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="applicantName">Applicant Name</Label>
                        <Input
                          id="applicantName"
                          value={medicalForm.applicantName}
                          onChange={(e) => setMedicalForm({...medicalForm, applicantName: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="medicalDob">Date of Birth</Label>
                        <Input
                          id="medicalDob"
                          type="date"
                          value={medicalForm.dob}
                          onChange={(e) => setMedicalForm({...medicalForm, dob: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="medicalPhone">Mobile Number</Label>
                        <Input
                          id="medicalPhone"
                          type="tel"
                          value={medicalForm.phone}
                          onChange={(e) => setMedicalForm({...medicalForm, phone: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="medicalEmail">Email Address</Label>
                        <Input
                          id="medicalEmail"
                          type="email"
                          value={medicalForm.email}
                          onChange={(e) => setMedicalForm({...medicalForm, email: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label htmlFor="medicalAddress">Address</Label>
                      <Textarea
                        id="medicalAddress"
                        value={medicalForm.address}
                        onChange={(e) => setMedicalForm({...medicalForm, address: e.target.value})}
                        required
                      />
                    </div>
                  </div>

                  {/* Medical Details */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Medical Details</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="disease">Disease/Condition</Label>
                        <Input
                          id="disease"
                          value={medicalForm.disease}
                          onChange={(e) => setMedicalForm({...medicalForm, disease: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="hospital">Hospital Name</Label>
                        <Input
                          id="hospital"
                          value={medicalForm.hospital}
                          onChange={(e) => setMedicalForm({...medicalForm, hospital: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="doctor">Doctor Name</Label>
                        <Input
                          id="doctor"
                          value={medicalForm.doctor}
                          onChange={(e) => setMedicalForm({...medicalForm, doctor: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="treatmentCost">Treatment Cost</Label>
                        <Input
                          id="treatmentCost"
                          type="number"
                          value={medicalForm.treatmentCost}
                          onChange={(e) => setMedicalForm({...medicalForm, treatmentCost: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Bank Details */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Bank Details</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="medicalBankAccount">Account Number</Label>
                        <Input
                          id="medicalBankAccount"
                          value={medicalForm.bankAccount}
                          onChange={(e) => setMedicalForm({...medicalForm, bankAccount: e.target.value})}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="medicalIfsc">IFSC Code</Label>
                        <Input
                          id="medicalIfsc"
                          value={medicalForm.ifsc}
                          onChange={(e) => setMedicalForm({...medicalForm, ifsc: e.target.value})}
                          required
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label htmlFor="medicalBankName">Bank Name &amp; Branch</Label>
                        <Input
                          id="medicalBankName"
                          value={medicalForm.bankName}
                          onChange={(e) => setMedicalForm({...medicalForm, bankName: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>

                  {/* Documents */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Required Documents</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label>Admission Report</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload admission report</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>Fee Receipt</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload fee receipt</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>EWS Certificate</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload EWS certificate</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <Label>Applicant Photo</Label>
                        <div className="mt-1 flex items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer hover:bg-gray-50">
                          <div className="text-center">
                            <Upload className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">Upload photo</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
                  >
                    Submit Application
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}