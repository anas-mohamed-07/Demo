// Database Status Component
// Shows current database configuration and connection status

import React, { useState, useEffect } from 'react';
import { BookingService } from './BookingService';
import { useEnvironmentConfig, EnvironmentStatus } from './EnvironmentConfig';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { RefreshCw, Database, AlertCircle, CheckCircle } from 'lucide-react';

interface DatabaseStatusProps {
  showDetails?: boolean;
  className?: string;
}

export function DatabaseStatus({ showDetails = false, className = '' }: DatabaseStatusProps) {
  const [dbStatus, setDbStatus] = useState<{
    connected: boolean;
    type: 'postgresql' | 'localStorage';
    message: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { config } = useEnvironmentConfig();

  const checkDatabaseStatus = async () => {
    setIsLoading(true);
    try {
      const bookingService = BookingService.getInstance();
      const status = await bookingService.getDatabaseStatus();
      setDbStatus(status);
    } catch (error) {
      console.error('Error checking database status:', error);
      setDbStatus({
        connected: false,
        type: 'localStorage',
        message: 'Error checking database status'
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkDatabaseStatus();
  }, []);

  const getStatusColor = () => {
    if (!dbStatus) return 'gray';
    if (dbStatus.type === 'postgresql' && dbStatus.connected) return 'green';
    if (dbStatus.type === 'localStorage') return 'yellow';
    return 'red';
  };

  const getStatusIcon = () => {
    if (isLoading) return <RefreshCw className="h-4 w-4 animate-spin" />;
    if (!dbStatus || !dbStatus.connected) return <AlertCircle className="h-4 w-4" />;
    return <CheckCircle className="h-4 w-4" />;
  };

  const getStatusText = () => {
    if (isLoading) return 'Checking...';
    if (!dbStatus) return 'Unknown';
    if (dbStatus.type === 'postgresql') return 'PostgreSQL';
    return 'Local Storage';
  };

  if (!showDetails) {
    // Compact status badge
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <Badge variant={getStatusColor() === 'green' ? 'default' : 'secondary'} className="flex items-center gap-1">
          {getStatusIcon()}
          {getStatusText()}
        </Badge>
      </div>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Database Status
        </CardTitle>
        <CardDescription>
          Current database configuration and connection status
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getStatusIcon()}
            <span className="font-medium">{getStatusText()}</span>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={checkDatabaseStatus}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {dbStatus && (
          <Alert>
            <AlertDescription>{dbStatus.message}</AlertDescription>
          </Alert>
        )}

        {dbStatus?.type === 'localStorage' && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Currently using local storage fallback. For production use, configure PostgreSQL database.
            </AlertDescription>
          </Alert>
        )}

        {/* Environment Configuration Status */}
        <div className="pt-4 border-t">
          <EnvironmentStatus />
        </div>
      </CardContent>
    </Card>
  );
}

// Compact database status indicator for header/footer
export function DatabaseStatusIndicator() {
  return <DatabaseStatus showDetails={false} className="text-sm" />;
}

// Hook for database status
export function useDatabaseStatus() {
  const [status, setStatus] = useState<{
    connected: boolean;
    type: 'postgresql' | 'localStorage';
    message: string;
    isLoading: boolean;
  }>({
    connected: false,
    type: 'localStorage',
    message: '',
    isLoading: true
  });

  const refresh = async () => {
    setStatus(prev => ({ ...prev, isLoading: true }));
    
    try {
      const bookingService = BookingService.getInstance();
      const dbStatus = await bookingService.getDatabaseStatus();
      
      setStatus({
        ...dbStatus,
        isLoading: false
      });
    } catch (error) {
      setStatus({
        connected: false,
        type: 'localStorage',
        message: 'Error checking database status',
        isLoading: false
      });
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  return {
    ...status,
    refresh
  };
}

export default DatabaseStatus;