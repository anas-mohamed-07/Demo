import { useEffect, useState } from 'react';

import { Heart, IndianRupee, Gift, Users, Home } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { Label } from '../components/label';
import { Input } from '../components/Input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/Select';
import { Textarea } from '../components/Textarea';
import { Button } from '../components/button';

export function DonationPage() {
  const [donationForm, setDonationForm] = useState({
    donorName: '',
    dob: '',
    mobile: '',
    email: '',
    address: '',
    amount: '',
    gender: '',
    purpose: 'general'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!/^\d{10}$/.test(donationForm.mobile)) {
      alert('Please enter a valid number.');
      return; 
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(donationForm.email)) {
      alert('Please enter a valid email address.');
      return;
    }

    if (!donationForm.gender) {
      alert('Please select your gender.');
      return;
    }
    console.log('Donation Form Submitted:', donationForm);
  //   try {
  //   const response = await fetch(`http://localhost/task/donate.php`, {
  //     method: "POST",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify(donationForm)
  //   });

  //   const result = await response.json();

  //   if (result.status === "success") {
  //     console.log('Donation Form Submitted:', donationForm);
  //     alert(`Thank you ${donationForm.donorName} for your generous donation of ₹${donationForm.amount}!`);
  //   } else {
  //     alert(result.message || "Something went wrong. Please try again.");
  //   }
  // } 
  //   catch (error) {
  //   console.error("Error submitting donation:", error);
  //   alert("Server error. Please try again later.");
  // }
  };

  const predefinedAmounts = [101, 201, 501, 1001, 2001, 5001];

  const donationPurposes = [
    { id: 'general', label: 'General Temple Fund', icon: <Home className="h-4 w-4" /> },
    { id: 'sevas', label: 'Daily Sevas & Poojas', icon: <Heart className="h-4 w-4" /> },
    { id: 'annadhanam', label: 'Annadhanam (Free Meals)', icon: <Users className="h-4 w-4" /> },
    { id: 'maintenance', label: 'Temple Maintenance', icon: <Home className="h-4 w-4" /> },
    { id: 'festivals', label: 'Festival Celebrations', icon: <Gift className="h-4 w-4" /> }
  ];

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-[var(--temple-dark-brown)]">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[var(--temple-dark-brown)]">e-Hundi Donation</h1>
          <p className="text-xl text-[var(--temple-dark-brown)]/80">Support Divine Service &amp; Community Welfare</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Donation Form */}
          <div className="lg:col-span-2">
            <Card className="divine-glow">
              <CardHeader>
                <CardTitle className="text-2xl text-[var(--temple-saffron)] flex items-center">
                  <Heart className="h-6 w-6 mr-2" />
                  Make a Donation
                </CardTitle>
                <p className="text-gray-600">
                  Your contribution supports temple activities, community service, and spiritual programs.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Donor Information */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Donor Information</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="donorName">Full Name</Label>
                        <Input
                          id="donorName"
                          value={donationForm.donorName}
                          onChange={(e) => setDonationForm({ ...donationForm, donorName: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="donorDob">Date of Birth</Label>
                        <Input
                          id="donorDob"
                          type="date"
                          value={donationForm.dob}
                          onChange={(e) => setDonationForm({ ...donationForm, dob: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="donorMobile">Mobile Number</Label>
                        <Input
                          id="donorMobile"
                          type="tel"
                          value={donationForm.mobile}
                          onChange={(e) => {
                            const value = e.target.value;
                            if (/^\d{0,10}$/.test(value)) {
                              setDonationForm({ ...donationForm, mobile: value });
                            }
                          }}
                          required
                          maxLength={10}
                        />
                      </div>
                      <div>
                        <Label htmlFor="donorEmail">Email Address</Label>
                        <Input
                          id="donorEmail"
                          type="email"
                          value={donationForm.email}
                          onChange={(e) => setDonationForm({ ...donationForm, email: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="gender">Gender</Label>
                        <Select value={donationForm.gender} onValueChange={(value) => setDonationForm({ ...donationForm, gender: value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select gender" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label htmlFor="donorAddress">Address</Label>
                      <Textarea
                        id="donorAddress"
                        value={donationForm.address}
                        onChange={(e) => setDonationForm({ ...donationForm, address: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  {/* Donation Purpose */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Donation Purpose</h3>
                    <div className="grid md:grid-cols-2 gap-3">
                      {donationPurposes.map((purpose) => (
                        <label
                          key={purpose.id}
                          className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${donationForm.purpose === purpose.id
                              ? 'border-[var(--temple-saffron)] bg-orange-50'
                              : 'border-gray-200 hover:border-[var(--temple-saffron)]'
                            }`}
                        >
                          <input
                            type="radio"
                            name="purpose"
                            value={purpose.id}
                            checked={donationForm.purpose === purpose.id}
                            onChange={(e) => setDonationForm({ ...donationForm, purpose: e.target.value })}
                            className="sr-only"
                          />
                          <div className="flex items-center">
                            {purpose.icon}
                            <span className="ml-2">{purpose.label}</span>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Donation Amount */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-gray-800">Donation Amount</h3>
                    <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mb-4">
                      {predefinedAmounts.map((amount) => (
                        <Button
                          key={amount}
                          type="button"
                          variant={donationForm.amount === amount.toString() ? "default" : "outline"}
                          onClick={() => setDonationForm({ ...donationForm, amount: amount.toString() })}
                          className={donationForm.amount === amount.toString()
                            ? "bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
                            : "border-[var(--temple-saffron)] text-[var(--temple-saffron)] hover:bg-[var(--temple-saffron)] hover:text-white"
                          }
                        >
                          <IndianRupee className="h-4 w-4 mr-1" />
                          {amount}
                        </Button>
                      ))}
                    </div>
                    <div>
                      <Label htmlFor="customAmount">Custom Amount</Label>
                      <Input
                        id="customAmount"
                        type="number"
                        placeholder="Enter custom amount"
                        value={donationForm.amount}
                        onChange={(e) => setDonationForm({ ...donationForm, amount: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800"
                    size="lg"
                  >
                    <Heart className="h-5 w-5 mr-2" />
                    Donate ₹{donationForm.amount || '0'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Information */}
          <div className="space-y-6">
            {/* Donation Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[var(--temple-saffron)]">
                  Your Donation Supports
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm text-gray-600">
                  <li className="flex items-start">
                    <Heart className="h-4 w-4 mr-2 mt-0.5 text-[var(--temple-saffron)]" />
                    Daily temple poojas and rituals
                  </li>
                  <li className="flex items-start">
                    <Users className="h-4 w-4 mr-2 mt-0.5 text-[var(--temple-saffron)]" />
                    Annadhanam (free meals) for devotees
                  </li>
                  <li className="flex items-start">
                    <Gift className="h-4 w-4 mr-2 mt-0.5 text-[var(--temple-saffron)]" />
                    Educational and medical assistance
                  </li>
                  <li className="flex items-start">
                    <Home className="h-4 w-4 mr-2 mt-0.5 text-[var(--temple-saffron)]" />
                    Temple maintenance and facilities
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* QR Code Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[var(--temple-saffron)]">
                  Quick Donation
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="w-32 h-32 bg-gray-200 rounded-lg mx-auto mb-4 flex items-center justify-center">
                  <span className="text-gray-500">QR Code</span>
                </div>
                <p className="text-sm text-gray-600">
                  Scan QR code for instant UPI donation
                </p>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-[var(--temple-saffron)]">
                  Need Help?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-2">
                  For donation receipts or queries, contact:
                </p>
                <p className="text-sm">
                  <strong>Phone:</strong> +91 80561 28486
                </p>
                <p className="text-sm">
                  <strong>Email:</strong> anjaneyaraalayatrust2008@gmail.com
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Tax Information */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-xl text-blue-800">Tax Exemption Information</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-blue-700">
              Donations to Arulmigu Anjaneya Aalayam are eligible for tax exemption under Section 80G of the Income Tax Act.
              Official receipts will be provided for all donations. Please retain the receipt for tax filing purposes.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}