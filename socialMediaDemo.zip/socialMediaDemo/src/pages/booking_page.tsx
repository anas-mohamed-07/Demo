import { useState, useEffect } from 'react';

import {
  Clock,
  IndianRupee,
  CalendarIcon,
  Users,
  AlertCircle,
  Info,
  ChevronDown,
  ChevronUp,
  Heart,
  Star,
  Gift,
  Shield,
  Timer,
  Flower2,
  Filter
} from '../components/icons';
import { useTranslation } from './localization_context';
import { BookingService } from './booking_service';
import { Badge, Calendar, Sheet } from 'lucide-react';
import { Toaster } from '../components/Sonner';
import { SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '../components/Sheet';
import { Button } from '../components/button';
import TamilCalendarWidget from './tamil_calender';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/Select';
import { Card, CardContent, CardHeader, CardTitle } from '../components/Card';
import { ImageWithFallback } from '../components/ImageWithFallback';
// import { BookingDialog } from './booking_dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/tabs';


export function BookingsPage() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedSeva, setSelectedSeva] = useState<string>('all');
  const [availabilityData, setAvailabilityData] = useState<Record<string, any>>({});
  const [expandedSeva, setExpandedSeva] = useState<string | null>(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [sevaConfigs, setSevaConfigs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { t } = useTranslation();

  const bookingService = BookingService.getInstance();

  // Restrict calendar to current and next month only
  const today = new Date();
  const currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
  const maxBookingDate = new Date(today.getFullYear(), today.getMonth() + 2, 0); // Last day of next month

  useEffect(() => {
    loadSevaConfigs();
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [])

  useEffect(() => {
    if (sevaConfigs.length > 0) {
      updateAvailability();
    }
  }, [selectedDate, sevaConfigs]);

  const loadSevaConfigs = async () => {
    try {
      setIsLoading(true);
      const configs = await bookingService.getSevaConfigs();
      setSevaConfigs(configs || []);
    } catch (error) {
      console.error('Error loading seva configs:', error);
      setSevaConfigs([]);
    } finally {
      setIsLoading(false);
    }
  };

  const updateAvailability = async () => {
    try {
      const availability = await bookingService.getAllAvailabilityForDate(selectedDate);
      setAvailabilityData(availability || {});
    } catch (error) {
      console.error('Error updating availability:', error);
      setAvailabilityData({});
    }
  };

  const handleBookingSuccess = () => {
    updateAvailability();
  };

  const filteredSevas = selectedSeva === 'all'
    ? sevaConfigs
    : sevaConfigs.filter(seva => seva.id === selectedSeva);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{t('bookings.title')}</h1>
            <p className="text-xl opacity-90">{t('bookings.subtitle')}</p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[var(--temple-saffron)] mx-auto mb-4"></div>
              <p className="text-gray-600">Loading seva configurations...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show error state if no sevas loaded
  if (!isLoading && sevaConfigs.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{t('bookings.title')}</h1>
            <p className="text-xl opacity-90">{t('bookings.subtitle')}</p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-center">
            <div className="text-center">
              <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
              <p className="text-gray-600">Unable to load seva configurations. Please try again.</p>
              <button
                onClick={loadSevaConfigs}
                className="mt-4 px-4 py-2 bg-[var(--temple-saffron)] text-white rounded hover:bg-[var(--temple-gold)] hover:text-gray-800"
              >
                Retry
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const toggleSevaDetails = (sevaId: string) => {
    setExpandedSeva(expandedSeva === sevaId ? null : sevaId);
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      setIsCalendarOpen(false); // Close the sheet on mobile after selection
    }
  };

  // Calendar and Info Component (reusable for both desktop and mobile)
  const CalendarSection = ({ isMobile = false }) => (
    <div className={isMobile ? "space-y-4" : ""}>
      <div className={isMobile ? "" : "mb-4"}>
        {isMobile && (
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-[var(--temple-saffron)] flex items-center">
              <CalendarIcon className="h-5 w-5 mr-2" />
              {t('bookings.select_date')}
            </h3>
          </div>
        )}
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={handleDateSelect}
          fromMonth={currentMonth}
          toMonth={nextMonth}
          disabled={(date: any) =>
            date < today ||
            date > maxBookingDate ||
            date.getDay() === 0 // Disable Sundays if temple is closed
          }
          className="rounded-md border"
        />
      </div>

      {/* Date Info - Only show on desktop */}
      {!isMobile && (
        <div className="p-4 bg-blue-50 rounded-lg">
          <h4 className="font-semibold text-blue-800 mb-2">Selected Date</h4>
          <p className="text-blue-700">
            {selectedDate.toLocaleDateString('en-IN', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>
        </div>
      )}

      {/* Quick Info */}
      <div className={`p-4 bg-[var(--temple-saffron)] bg-opacity-10 rounded-lg ${isMobile ? 'mt-4' : 'mt-4'}`}>
        <h4 className="font-semibold text-[#2C1503] mb-2 flex items-center">
          <Info className="h-4 w-4 mr-1" />
          {t('bookings.booking_info')}
        </h4>
        <ul className="text-sm space-y-1 text-[#2C1503]">
          <li>• {t('bookings.info.prasadam')}</li>
          <li>• {t('bookings.info.booking')}</li>
          <li>• {t('bookings.info.payment')}</li>
          <li>• {t('bookings.info.timings')}</li>
        </ul>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster />

      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{t('bookings.title')}</h1>
          <p className="text-xl opacity-90">{t('bookings.subtitle')}</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Mobile/Tablet Date Selection Bar */}
        <div className="lg:hidden mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Date Selector for Mobile/Tablet */}
            <Sheet open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
              <SheetTrigger>
                <Button
                  variant="outline"
                  className="flex-1 sm:flex-none justify-start text-left border-[var(--temple-saffron)] text-[var(--temple-saffron)] hover:bg-[var(--temple-saffron)] hover:text-white"
                >
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  <span className="truncate">
                    {selectedDate.toLocaleDateString('en-IN', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric'
                    })}
                  </span>
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="h-[80vh] overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>Select Date & View Information</SheetTitle>
                  <SheetDescription>
                    Choose your preferred date for seva booking
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  {/* Tamil Calendar Widget for mobile */}
                  <TamilCalendarWidget />

                  {/* Regular Calendar */}
                  <CalendarSection isMobile={true} />
                </div>
              </SheetContent>
            </Sheet>

            {/* Filter for Mobile/Tablet */}
            <div className="flex-1 sm:max-w-xs">
              <Select value={selectedSeva} onValueChange={setSelectedSeva}>
                <SelectTrigger className="border-[var(--temple-saffron)]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter by Seva" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sevas</SelectItem>
                  {sevaConfigs.map(seva => (
                    <SelectItem key={seva.id} value={seva.id}>
                      {seva.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Quick Date Info for Mobile */}
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-blue-800">
                  {selectedDate.toLocaleDateString('en-IN', {
                    weekday: 'long',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
                <p className="text-sm text-blue-600">Tap date to change</p>
              </div>
              <CalendarIcon className="h-6 w-6 text-blue-500" />
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Desktop Calendar Section */}
          <div className="hidden lg:block lg:col-span-1 space-y-6">
            {/* Tamil Calendar Widget */}
            <div className="sticky top-4">
              <TamilCalendarWidget />
            </div>

            {/* Regular Calendar */}
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-[var(--temple-saffron)] flex items-center">
                  <CalendarIcon className="h-5 w-5 mr-2" />
                  Select Date
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CalendarSection />
              </CardContent>
            </Card>
          </div>

          {/* Sevas Section */}
          <div className="lg:col-span-2">
            {/* Desktop Filter */}
            <div className="hidden lg:block mb-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-2xl font-bold text-gray-800">{t('bookings.available_sevas')}</h2>
                <div className="w-full sm:w-64">
                  <Select value={selectedSeva} onValueChange={setSelectedSeva}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('bookings.filter_by_seva')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('bookings.all_sevas')}</SelectItem>
                      {sevaConfigs.map(seva => (
                        <SelectItem key={seva.id} value={seva.id}>
                          {seva.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Mobile/Tablet Header */}
            <div className="lg:hidden mb-4">
              <h2 className="text-xl font-bold text-gray-800">{t('bookings.available_sevas')}</h2>
              <p className="text-sm text-gray-600 mt-1">
                {filteredSevas.length} {t('bookings.sevas_available')}
              </p>
            </div>

            {/* Sevas List */}
            <div className="space-y-6">
              {filteredSevas.map((seva) => {
                const sevaAvailability = availabilityData[seva.id] || { available: 0, total: 0, isAvailable: false };
                const isExpanded = expandedSeva === seva.id;

                return (
                  <Card key={seva.id} className="hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-0">
                      {/* Main Seva Info */}
                      <div className="p-4 border-b">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold text-[var(--temple-saffron)] mb-2">{seva.name}</h3>
                            <p className="text-gray-600 mb-3">{seva.description}</p>
                          </div>

                          <div className="ml-4 hidden sm:block">
                            <ImageWithFallback
                              src={seva.image}
                              alt={seva.name}
                              className="w-20 sm:w-24 h-20 sm:h-24 object-cover rounded-lg"
                            />
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
                          <div className="flex items-center text-gray-500">
                            <CalendarIcon className="h-4 w-4 mr-1 flex-shrink-0" />
                            <span className="truncate">
                              {selectedDate.toLocaleDateString('en-IN', {
                                weekday: 'short',
                                month: 'short',
                                day: 'numeric'
                              })}
                            </span>
                          </div>
                          <div className="flex items-center text-gray-500">
                            <Clock className="h-4 w-4 mr-1 flex-shrink-0" />
                            <span className="truncate">{seva.time}</span>
                          </div>
                          <div className="flex items-center text-[var(--temple-saffron)]">
                            <IndianRupee className="h-4 w-4 mr-1 flex-shrink-0" />
                            <span>{seva.fees}</span>
                          </div>
                        </div>
                      </div>

                      {/* Availability and Booking Section */}
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-gray-50 gap-4">
                        <div className="flex items-center space-x-4 w-full sm:w-auto">
                          <div className="text-center">
                            <Badge
                              variant={sevaAvailability.isAvailable ? 'default' : 'destructive'}
                              className={sevaAvailability.isAvailable
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                              }
                            >
                              {sevaAvailability.available} / {sevaAvailability.total}
                            </Badge>
                            <p className="text-xs text-gray-500 mt-1">
                              {sevaAvailability.isAvailable ? t('bookings.available') : t('bookings.fully_booked')}
                            </p>
                          </div>

                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleSevaDetails(seva.id)}
                            className="text-[var(--temple-saffron)] border-[var(--temple-saffron)] flex-1 sm:flex-none"
                          >
                            {isExpanded ? (
                              <>
                                <ChevronUp className="h-4 w-4 mr-1" />
                                {t('bookings.hide_details')}
                              </>
                            ) : (
                              <>
                                <ChevronDown className="h-4 w-4 mr-1" />
                                {t('bookings.view_details')}
                              </>
                            )}
                          </Button>
                        </div>

                        {/* <BookingDialog
                          seva={seva}
                          selectedDate={selectedDate}
                          isAvailable={sevaAvailability.isAvailable}
                          onBookingSuccess={handleBookingSuccess}
                        > */}
                        <Button
                          disabled={!sevaAvailability.isAvailable}
                          className={`w-full sm:w-auto ${sevaAvailability.isAvailable
                            ? 'bg-[var(--temple-saffron)] hover:bg-[var(--temple-gold)] hover:text-gray-800'
                            : ''
                            }`}
                        >
                          {sevaAvailability.isAvailable ? t('bookings.book_now') : t('bookings.fully_booked')}
                        </Button>
                        {/* </BookingDialog> */}
                      </div>

                      {/* Detailed Information (Expandable) */}
                      {isExpanded && (
                        <div className="border-t">
                          <Tabs value="details" className="p-4">
                            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
                              <TabsTrigger value="details" className="text-xs sm:text-sm">{t('bookings.tabs.details')}</TabsTrigger>
                              <TabsTrigger value="benefits" className="text-xs sm:text-sm">{t('bookings.tabs.benefits')}</TabsTrigger>
                              <TabsTrigger value="significance" className="text-xs sm:text-sm">{t('bookings.tabs.significance')}</TabsTrigger>
                              <TabsTrigger value="materials" className="text-xs sm:text-sm">{t('bookings.tabs.materials')}</TabsTrigger>
                            </TabsList>

                            <TabsContent value="details" className="mt-4">
                              <div className="space-y-4">
                                <p className="text-gray-700 leading-relaxed">{seva.detailedDescription}</p>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="flex items-center space-x-2">
                                    <Timer className="h-5 w-5 text-[var(--temple-saffron)]" />
                                    <span className="font-medium">{t('bookings.duration')}</span>
                                    <span>{seva.duration}</span>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Users className="h-5 w-5 text-[var(--temple-saffron)]" />
                                    <span className="font-medium">{t('bookings.daily_limit')}</span>
                                    <span>{seva.dailyLimit} {t('bookings.devotees')}</span>
                                  </div>
                                </div>

                                <div>
                                  <h4 className="font-semibold text-[var(--temple-saffron)] mb-2 flex items-center">
                                    <Star className="h-4 w-4 mr-2" />
                                    {t('bookings.best_time')}
                                  </h4>
                                  <div className="flex flex-wrap gap-2">
                                    {seva.bestTimeFor.map((purpose: any, index: any) => (
                                      <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700">
                                        {purpose}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </TabsContent>

                            <TabsContent value="benefits" className="mt-4">
                              <div className="space-y-4">
                                <h4 className="font-semibold text-[var(--temple-saffron)] mb-3 flex items-center">
                                  <Gift className="h-4 w-4 mr-2" />
                                  {t('bookings.worldly_benefits')}
                                </h4>
                                <ul className="space-y-2">
                                  {seva.benefits.map((benefit, index) => (
                                    <li key={index} className="flex items-start space-x-2">
                                      <div className="w-2 h-2 bg-[var(--temple-saffron)] rounded-full mt-2 flex-shrink-0"></div>
                                      <span className="text-gray-700">{benefit}</span>
                                    </li>
                                  ))}
                                </ul>

                                <h4 className="font-semibold text-[var(--temple-saffron)] mb-3 flex items-center mt-6">
                                  <Heart className="h-4 w-4 mr-2" />
                                  {t('bookings.spiritual_benefits')}
                                </h4>
                                <ul className="space-y-2">
                                  {seva.spiritualBenefits.map((benefit: any, index: any) => (
                                    <li key={index} className="flex items-start space-x-2">
                                      <div className="w-2 h-2 bg-[var(--temple-gold)] rounded-full mt-2 flex-shrink-0"></div>
                                      <span className="text-gray-700">{benefit}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </TabsContent>

                            <TabsContent value="significance" className="mt-4">
                              <div className="space-y-4">
                                <h4 className="font-semibold text-[var(--temple-saffron)] mb-3 flex items-center">
                                  <Shield className="h-4 w-4 mr-2" />
                                  {t('bookings.religious_significance')}
                                </h4>
                                <p className="text-gray-700 leading-relaxed bg-orange-50 p-4 rounded-lg border-l-4 border-[var(--temple-saffron)]">
                                  {seva.significance}
                                </p>
                              </div>
                            </TabsContent>

                            <TabsContent value="materials" className="mt-4">
                              <div className="space-y-4">
                                <h4 className="font-semibold text-[var(--temple-saffron)] mb-3 flex items-center">
                                  <Flower2 className="h-4 w-4 mr-2" />
                                  {t('bookings.sacred_materials')}
                                </h4>
                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                                  {seva.materials.map((material: any, index: any) => (
                                    <div key={index} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                                      <div className="w-2 h-2 bg-[var(--temple-gold)] rounded-full flex-shrink-0"></div>
                                      <span className="text-sm text-gray-700">{material}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </TabsContent>
                          </Tabs>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* General Information */}
            <Card className="mt-8 bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] text-[var(--temple-dark-brown)]">
              <CardHeader>
                <CardTitle className="text-2xl text-[var(--temple-dark-brown)]">Seva Guidelines & Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 text-[var(--temple-dark-brown)]">General Guidelines:</h4>
                    <ul className="space-y-2 text-[var(--temple-dark-brown)]/80">
                      <li>• Arrive 15 minutes before seva time</li>
                      <li>• Wear traditional/modest clothing</li>
                      <li>• Mobile phones to be switched off</li>
                      <li>• Follow temple priest's instructions</li>
                      <li>• Photography requires permission</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 text-[var(--temple-dark-brown)]">What's Included:</h4>
                    <ul className="space-y-2 text-[var(--temple-dark-brown)]/80">
                      <li>• Complete ritual with mantras</li>
                      <li>• Sacred prasadam distribution</li>
                      <li>• Blessed offerings to take home</li>
                      <li>• Spiritual guidance from priests</li>
                      <li>• Certificate of participation</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}