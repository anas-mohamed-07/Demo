// SMS Service with provider abstraction for easy vendor integration
interface SMSProvider {
  name: string;
  sendSMS(to: string, message: string): Promise<SMSResponse>;
}

interface SMSResponse {
  success: boolean;
  messageId?: string;
  error?: string;
  provider: string;
}

interface BookingConfirmationData {
  devoteeName: string;
  sevaName: string;
  date: string;
  time: string;
  transactionId: string;
  amount: number;
  bookingId: string;
}

// Sample SMS Provider Implementation (replace with real vendor later)
class MockSMSProvider implements SMSProvider {
  name = 'Mock SMS Provider';

  async sendSMS(to: string, message: string): Promise<SMSResponse> {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock success response (replace with real API call)
    console.log(`[SMS Mock] Sending to: ${to}`);
    console.log(`[SMS Mock] Message: ${message}`);
    
    // Simulate 95% success rate
    const isSuccess = Math.random() > 0.05;
    
    if (isSuccess) {
      return {
        success: true,
        messageId: `mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        provider: this.name
      };
    } else {
      return {
        success: false,
        error: 'Mock SMS sending failed',
        provider: this.name
      };
    }
  }
}

// Twilio Provider Template (uncomment and configure when ready)
/*
class TwilioSMSProvider implements SMSProvider {
  name = 'Twilio';
  private accountSid: string;
  private authToken: string;
  private fromNumber: string;

  constructor(accountSid: string, authToken: string, fromNumber: string) {
    this.accountSid = accountSid;
    this.authToken = authToken;
    this.fromNumber = fromNumber;
  }

  async sendSMS(to: string, message: string): Promise<SMSResponse> {
    try {
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.accountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(this.accountSid + ':' + this.authToken)}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: this.fromNumber,
          To: to,
          Body: message,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        return {
          success: true,
          messageId: data.sid,
          provider: this.name
        };
      } else {
        return {
          success: false,
          error: data.message || 'Twilio SMS sending failed',
          provider: this.name
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        provider: this.name
      };
    }
  }
}
*/

// TextLocal Provider Template (popular in India)
/*
class TextLocalProvider implements SMSProvider {
  name = 'TextLocal';
  private apiKey: string;
  private sender: string;

  constructor(apiKey: string, sender: string) {
    this.apiKey = apiKey;
    this.sender = sender;
  }

  async sendSMS(to: string, message: string): Promise<SMSResponse> {
    try {
      const response = await fetch('https://api.textlocal.in/send/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          apikey: this.apiKey,
          numbers: to,
          message: message,
          sender: this.sender,
        }),
      });

      const data = await response.json();

      if (data.status === 'success') {
        return {
          success: true,
          messageId: data.messages[0]?.id || 'unknown',
          provider: this.name
        };
      } else {
        return {
          success: false,
          error: data.errors?.[0]?.message || 'TextLocal SMS sending failed',
          provider: this.name
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        provider: this.name
      };
    }
  }
}
*/

// Main SMS Service Class
export class SMSService {
  private static instance: SMSService;
  private provider: SMSProvider;
  private isEnabled: boolean = true;

  private constructor() {
    // Initialize with mock provider (replace with real provider when ready)
    this.provider = new MockSMSProvider();
    
    // To use Twilio:
    // this.provider = new TwilioSMSProvider('YOUR_ACCOUNT_SID', 'YOUR_AUTH_TOKEN', 'YOUR_PHONE_NUMBER');
    
    // To use TextLocal:
    // this.provider = new TextLocalProvider('YOUR_API_KEY', 'YOUR_SENDER_ID');
  }

  static getInstance(): SMSService {
    if (!SMSService.instance) {
      SMSService.instance = new SMSService();
    }
    return SMSService.instance;
  }

  // Method to switch SMS provider
  setProvider(provider: SMSProvider): void {
    this.provider = provider;
  }

  // Enable/disable SMS sending
  setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
  }

  // Format phone number for SMS (ensure it's in correct format)
  private formatPhoneNumber(phone: string): string {
    // Remove any non-digit characters
    const digits = phone.replace(/\D/g, '');
    
    // Add country code if not present (assuming India +91)
    if (digits.length === 10) {
      return `+91${digits}`;
    } else if (digits.length === 12 && digits.startsWith('91')) {
      return `+${digits}`;
    } else if (digits.length === 13 && digits.startsWith('+91')) {
      return digits;
    }
    
    return `+91${digits.slice(-10)}`; // Take last 10 digits and add +91
  }

  // Generate booking confirmation message
  private generateBookingConfirmationMessage(data: BookingConfirmationData, language: 'en' | 'ta' = 'en'): string {
    if (language === 'ta') {
      return `🕉️ ஆஞ்சநேய ஆலயம்
பூஜை பதிவு உறுதிப்படுத்தல்

அன்புள்ள ${data.devoteeName},

உங்கள் ${data.sevaName} பூஜை வெற்றிகரமாக பதிவு செய்யப்பட்டது.

📅 தேதி: ${data.date}
🕐 நேரம்: ${data.time}
💰 தொகை: ₹${data.amount}
🆔 பதிவு எண்: ${data.bookingId}
💳 பரிவர்த்தனை எண்: ${data.transactionId}

கோயிலுக்கு 15 நிமிடங்கள் முன்பே வரவும். 
தொலைபேசி: +91 80561 28486

ஓம் ஹனுமதே நமஃ 🙏`;
    } else {
      return `🕉️ Arulmigu Anjaneya Aalayam
Seva Booking Confirmation

Dear ${data.devoteeName},

Your ${data.sevaName} seva has been successfully booked.

📅 Date: ${data.date}
🕐 Time: ${data.time}
💰 Amount: ₹${data.amount}
🆔 Booking ID: ${data.bookingId}
💳 Transaction ID: ${data.transactionId}

Please arrive 15 minutes before seva time.
Contact: +91 80561 28486

Om Hanumate Namah 🙏`;
    }
  }

  // Send booking confirmation SMS
  async sendBookingConfirmation(
    phoneNumber: string, 
    bookingData: BookingConfirmationData, 
    language: 'en' | 'ta' = 'en'
  ): Promise<SMSResponse> {
    if (!this.isEnabled) {
      console.log('[SMS Service] SMS sending is disabled');
      return {
        success: false,
        error: 'SMS service is disabled',
        provider: this.provider.name
      };
    }

    try {
      const formattedPhone = this.formatPhoneNumber(phoneNumber);
      const message = this.generateBookingConfirmationMessage(bookingData, language);
      
      console.log(`[SMS Service] Sending booking confirmation to ${formattedPhone}`);
      
      const result = await this.provider.sendSMS(formattedPhone, message);
      
      if (result.success) {
        console.log(`[SMS Service] SMS sent successfully. Message ID: ${result.messageId}`);
      } else {
        console.error(`[SMS Service] SMS sending failed: ${result.error}`);
      }
      
      return result;
    } catch (error) {
      console.error('[SMS Service] Error sending SMS:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        provider: this.provider.name
      };
    }
  }

  // Send custom SMS (for other use cases)
  async sendCustomSMS(phoneNumber: string, message: string): Promise<SMSResponse> {
    if (!this.isEnabled) {
      return {
        success: false,
        error: 'SMS service is disabled',
        provider: this.provider.name
      };
    }

    try {
      const formattedPhone = this.formatPhoneNumber(phoneNumber);
      return await this.provider.sendSMS(formattedPhone, message);
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        provider: this.provider.name
      };
    }
  }

  // Get current provider info
  getProviderInfo(): { name: string; enabled: boolean } {
    return {
      name: this.provider.name,
      enabled: this.isEnabled
    };
  }
}

// Export singleton instance
export const smsService = SMSService.getInstance();

// Export types for use in other components
export type { SMSResponse, BookingConfirmationData };