import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/Card";
import { ImageWithFallback } from "../components/ImageWithFallback";
import { useTranslation } from "./localization_context";


export function AboutPage() {
  const { t } = useTranslation();

    useEffect(()=>{
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },[])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="relative h-80 bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)]">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=1200&h=400&fit=crop"
            alt="Temple Entrance"
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="relative z-10 flex items-center justify-center h-full">
          <div className="text-center text-[var(--temple-dark-brown)]">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-[var(--temple-dark-brown)]">{t('about.title')}</h1>
            <p className="text-xl text-[var(--temple-dark-brown)]">{t('about.subtitle')}</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 mb-12">
          <div>
            <h2 className="text-3xl font-bold text-[var(--temple-saffron)] mb-6">
              {t('about.history.title')}
            </h2>
            <div className="space-y-4 text-gray-700">
              <p>{t('about.history.content')}</p>
              <p>{t('about.significance.content')}</p>
            </div>
          </div>
          
          <div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&h=400&fit=crop"
              alt="Temple Interior"
              className="w-full h-80 object-cover rounded-lg shadow-lg"
            />
          </div>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card className="divine-glow">
            <CardHeader>
              <CardTitle className="text-2xl text-[var(--temple-saffron)]">
                {t('about.mission.title')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">{t('about.mission.content')}</p>
            </CardContent>
          </Card>

          <Card className="divine-glow">
            <CardHeader>
              <CardTitle className="text-2xl text-[var(--temple-saffron)]">
                {t('about.vision.title')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">{t('about.vision.content')}</p>
            </CardContent>
          </Card>
        </div>

        {/* Values */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-center mb-8 text-gray-800">
            {t('about.values.title')}
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.values.devotion')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 text-sm">
                  {t('about.values.devotion.desc')}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.values.service')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 text-sm">
                  {t('about.values.service.desc')}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.values.tradition')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 text-sm">
                  {t('about.values.tradition.desc')}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.values.inclusivity')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 text-sm">
                  {t('about.values.inclusivity.desc')}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* About Lord Hanuman */}
        <Card className="mb-12 divine-glow">
          <CardHeader>
            <CardTitle className="text-2xl text-[var(--temple-saffron)]">
              {t('about.deity.title')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{t('about.deity.content')}</p>
          </CardContent>
        </Card>

        {/* Quote Section */}
        <div className="text-center bg-gradient-to-r from-[var(--temple-saffron)] to-[var(--temple-gold)] rounded-lg p-8 text-[var(--temple-dark-brown)] mb-12">
          <h3 className="text-2xl font-bold mb-4 text-[var(--temple-dark-brown)]">
            "{t('home.temple_heritage')}"
          </h3>
          <p className="text-lg text-[var(--temple-dark-brown)]/80 max-w-3xl mx-auto">
            {t('home.temple_desc')}
          </p>
        </div>

        {/* Temple Facilities */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold text-center mb-8 text-gray-800">
            {t('about.facilities.title')}
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.facilities.prayer_hall')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">
                  Large prayer hall accommodating hundreds of devotees for daily worship and special occasions.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.facilities.accessibility')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">
                  Fully accessible facilities ensuring all devotees can participate in temple activities.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-center text-[var(--temple-saffron)]">
                  {t('about.facilities.donations')}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600">
                  Modern digital donation system for convenient and secure temple contributions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}