// Migration utility to transition from localStorage to PostgreSQL
// This helps preserve existing booking data during the switch

import { PostgreSQLBookingService } from './PostgreSQLBookingService';
import { Booking } from './BookingService';

export class BookingServiceMigration {
  private postgresService: PostgreSQLBookingService;

  constructor() {
    this.postgresService = PostgreSQLBookingService.getInstance();
  }

  // Migrate existing localStorage data to PostgreSQL
  public async migrateFromLocalStorage(): Promise<{ success: boolean; message: string; migratedCount: number }> {
    try {
      console.log('🔄 Starting migration from localStorage to PostgreSQL...');

      // Get existing data from localStorage
      const existingData = localStorage.getItem('temple_bookings');
      if (!existingData) {
        return { success: true, message: 'No existing data to migrate', migratedCount: 0 };
      }

      const bookings: Booking[] = JSON.parse(existingData);
      if (bookings.length === 0) {
        return { success: true, message: 'No bookings to migrate', migratedCount: 0 };
      }

      console.log(`📊 Found ${bookings.length} bookings to migrate`);

      let migratedCount = 0;
      let errors: string[] = [];

      // Migrate each booking
      for (const booking of bookings) {
        try {
          // Transform booking data to match PostgreSQL schema
          const transformedBooking = {
            seva_id: booking.sevaId,
            devotee_name: booking.devoteeName,
            devotee_phone: booking.phone,
            devotee_email: booking.email,
            booking_date: booking.date,
            time_slot: booking.time,
            amount: booking.amount,
            payment_status: booking.paymentStatus || 'pending',
            transaction_id: booking.transactionId,
            notes: `Migrated from localStorage on ${new Date().toISOString()}`
          };

          const result = await this.postgresService.makeBooking(transformedBooking);
          
          if (result.success) {
            migratedCount++;
            console.log(`✅ Migrated booking: ${booking.devoteeName} - ${booking.sevaName}`);
          } else {
            errors.push(`Failed to migrate booking ${booking.id}: ${result.message}`);
            console.error(`❌ Failed to migrate booking ${booking.id}:`, result.message);
          }
        } catch (error) {
          errors.push(`Error migrating booking ${booking.id}: ${error}`);
          console.error(`❌ Error migrating booking ${booking.id}:`, error);
        }
      }

      // Create backup of localStorage data
      const backupData = {
        originalData: bookings,
        migrationDate: new Date().toISOString(),
        migratedCount,
        errors
      };
      localStorage.setItem('temple_bookings_backup', JSON.stringify(backupData));

      if (migratedCount === bookings.length) {
        // Clear localStorage after successful migration
        localStorage.removeItem('temple_bookings');
        console.log('🎉 Migration completed successfully!');
        return { 
          success: true, 
          message: `Successfully migrated ${migratedCount} bookings to PostgreSQL`, 
          migratedCount 
        };
      } else {
        return { 
          success: false, 
          message: `Partially migrated ${migratedCount}/${bookings.length} bookings. Check console for errors.`, 
          migratedCount 
        };
      }
    } catch (error) {
      console.error('Migration error:', error);
      return { 
        success: false, 
        message: `Migration failed: ${error}`, 
        migratedCount: 0 
      };
    }
  }

  // Backup current PostgreSQL data
  public async backupPostgreSQLData(): Promise<{ success: boolean; message: string; backupData?: any }> {
    try {
      console.log('💾 Creating PostgreSQL backup...');

      const bookings = await this.postgresService.getBookings();
      const sevas = await this.postgresService.getSevaConfigs();
      const stats = await this.postgresService.getBookingStats();

      const backupData = {
        timestamp: new Date().toISOString(),
        bookings,
        sevas,
        stats,
        totalBookings: bookings.length
      };

      // Store backup in localStorage
      localStorage.setItem('temple_postgresql_backup', JSON.stringify(backupData));

      return {
        success: true,
        message: `Successfully backed up ${bookings.length} bookings`,
        backupData
      };
    } catch (error) {
      console.error('Backup error:', error);
      return {
        success: false,
        message: `Backup failed: ${error}`
      };
    }
  }

  // Restore from backup
  public async restoreFromBackup(): Promise<{ success: boolean; message: string }> {
    try {
      console.log('🔄 Restoring from backup...');

      const backupData = localStorage.getItem('temple_bookings_backup');
      if (!backupData) {
        return { success: false, message: 'No backup data found' };
      }

      const backup = JSON.parse(backupData);
      const bookings = backup.originalData;

      if (!bookings || bookings.length === 0) {
        return { success: false, message: 'No bookings in backup data' };
      }

      // Restore localStorage data
      localStorage.setItem('temple_bookings', JSON.stringify(bookings));

      return {
        success: true,
        message: `Successfully restored ${bookings.length} bookings from backup`
      };
    } catch (error) {
      console.error('Restore error:', error);
      return {
        success: false,
        message: `Restore failed: ${error}`
      };
    }
  }

  // Verify migration integrity
  public async verifyMigration(): Promise<{ success: boolean; message: string; details: any }> {
    try {
      console.log('🔍 Verifying migration integrity...');

      // Get backup data
      const backupData = localStorage.getItem('temple_bookings_backup');
      if (!backupData) {
        return { success: false, message: 'No backup data to verify against', details: {} };
      }

      const backup = JSON.parse(backupData);
      const originalBookings = backup.originalData;

      // Get PostgreSQL data
      const postgresBookings = await this.postgresService.getBookings();

      // Compare counts
      const details = {
        originalCount: originalBookings.length,
        postgresCount: postgresBookings.length,
        migratedCount: backup.migratedCount,
        migrationErrors: backup.errors || []
      };

      if (details.migratedCount === details.originalCount) {
        return {
          success: true,
          message: 'Migration integrity verified successfully',
          details
        };
      } else {
        return {
          success: false,
          message: `Migration incomplete: ${details.migratedCount}/${details.originalCount} bookings migrated`,
          details
        };
      }
    } catch (error) {
      console.error('Verification error:', error);
      return {
        success: false,
        message: `Verification failed: ${error}`,
        details: {}
      };
    }
  }

  // Check if migration is needed
  public async checkMigrationStatus(): Promise<{ needsMigration: boolean; details: any }> {
    try {
      const hasLocalStorageData = localStorage.getItem('temple_bookings') !== null;
      const hasPostgreSQLConnection = await this.postgresService.getConnectionStatus();
      const hasBackupData = localStorage.getItem('temple_bookings_backup') !== null;

      const details = {
        hasLocalStorageData,
        hasPostgreSQLConnection: hasPostgreSQLConnection.connected,
        hasBackupData,
        postgresMessage: hasPostgreSQLConnection.message
      };

      const needsMigration = hasLocalStorageData && hasPostgreSQLConnection.connected && !hasBackupData;

      return { needsMigration, details };
    } catch (error) {
      console.error('Migration status check error:', error);
      return { 
        needsMigration: false, 
        details: { error: error.toString() } 
      };
    }
  }
}

// Export singleton instance
export const bookingMigration = new BookingServiceMigration();

// React hook for migration
import { useState, useEffect } from 'react';

export function useMigrationStatus() {
  const [status, setStatus] = useState<{
    needsMigration: boolean;
    isConnected: boolean;
    isLoading: boolean;
    error?: string;
  }>({
    needsMigration: false,
    isConnected: false,
    isLoading: true
  });

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const migrationStatus = await bookingMigration.checkMigrationStatus();
        setStatus({
          needsMigration: migrationStatus.needsMigration,
          isConnected: migrationStatus.details.hasPostgreSQLConnection,
          isLoading: false
        });
      } catch (error) {
        setStatus({
          needsMigration: false,
          isConnected: false,
          isLoading: false,
          error: error.toString()
        });
      }
    };

    checkStatus();
  }, []);

  const runMigration = async () => {
    setStatus(prev => ({ ...prev, isLoading: true }));
    
    try {
      const result = await bookingMigration.migrateFromLocalStorage();
      
      if (result.success) {
        setStatus({
          needsMigration: false,
          isConnected: true,
          isLoading: false
        });
        return result;
      } else {
        setStatus(prev => ({ ...prev, isLoading: false, error: result.message }));
        return result;
      }
    } catch (error) {
      setStatus(prev => ({ ...prev, isLoading: false, error: error.toString() }));
      return { success: false, message: error.toString(), migratedCount: 0 };
    }
  };

  return {
    ...status,
    runMigration
  };
}

// Migration component for admin interface
export function MigrationPanel() {
  const { needsMigration, isConnected, isLoading, error, runMigration } = useMigrationStatus();
  const [migrationResult, setMigrationResult] = useState<string>('');

  const handleMigration = async () => {
    const result = await runMigration();
    setMigrationResult(result.message);
  };

  if (isLoading) {
    return <div className="p-4 bg-blue-50 rounded-lg">Checking migration status...</div>;
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 rounded-lg">
        <h3 className="font-semibold text-red-800">Migration Error</h3>
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  if (!isConnected) {
    return (
      <div className="p-4 bg-yellow-50 rounded-lg">
        <h3 className="font-semibold text-yellow-800">Database Connection Required</h3>
        <p className="text-yellow-600">
          Please configure your PostgreSQL connection in the environment variables before migrating.
        </p>
      </div>
    );
  }

  if (!needsMigration) {
    return (
      <div className="p-4 bg-green-50 rounded-lg">
        <h3 className="font-semibold text-green-800">✅ Migration Complete</h3>
        <p className="text-green-600">Your booking data is now stored in PostgreSQL.</p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-blue-50 rounded-lg">
      <h3 className="font-semibold text-blue-800">Migration Available</h3>
      <p className="text-blue-600 mb-4">
        Your booking data is currently stored in localStorage. Migrate to PostgreSQL for better reliability and features.
      </p>
      
      <button
        onClick={handleMigration}
        disabled={isLoading}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
      >
        {isLoading ? 'Migrating...' : 'Migrate to PostgreSQL'}
      </button>
      
      {migrationResult && (
        <div className="mt-4 p-3 bg-white rounded border">
          <p className="text-sm">{migrationResult}</p>
        </div>
      )}
    </div>
  );
}