import * as React from "react";
import { ChevronLeft, ChevronRight } from "./icons";

interface CalendarProps {
  mode?: 'single' | 'multiple' | 'range';
  selected?: Date | Date[];
  onSelect?: (date: Date | Date[] | undefined) => void;
  disabled?: (date: Date) => boolean;
  className?: string;
  showOutsideDays?: boolean;
}

const Calendar: React.FC<CalendarProps> = ({ 
  mode = 'single',
  selected,
  onSelect,
  disabled,
  className = '',
  showOutsideDays = true
}) => {
  const [currentMonth, setCurrentMonth] = React.useState(new Date());

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const isSelected = (date: Date) => {
    if (!selected) return false;
    
    if (mode === 'single') {
      const selectedDate = selected as Date;
      return selectedDate && 
        date.getDate() === selectedDate.getDate() &&
        date.getMonth() === selectedDate.getMonth() &&
        date.getFullYear() === selectedDate.getFullYear();
    }
    
    if (mode === 'multiple') {
      const selectedDates = selected as Date[];
      return selectedDates.some(selectedDate =>
        date.getDate() === selectedDate.getDate() &&
        date.getMonth() === selectedDate.getMonth() &&
        date.getFullYear() === selectedDate.getFullYear()
      );
    }
    
    return false;
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear();
  };

  const handleDateClick = (date: Date) => {
    if (disabled && disabled(date)) return;
    
    if (mode === 'single') {
      onSelect?.(date);
    } else if (mode === 'multiple') {
      const selectedDates = (selected as Date[]) || [];
      const isDateSelected = selectedDates.some(selectedDate =>
        date.getDate() === selectedDate.getDate() &&
        date.getMonth() === selectedDate.getMonth() &&
        date.getFullYear() === selectedDate.getFullYear()
      );
      
      if (isDateSelected) {
        onSelect?.(selectedDates.filter(selectedDate =>
          !(date.getDate() === selectedDate.getDate() &&
            date.getMonth() === selectedDate.getMonth() &&
            date.getFullYear() === selectedDate.getFullYear())
        ));
      } else {
        onSelect?.([...selectedDates, date]);
      }
    }
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newMonth = new Date(prev);
      if (direction === 'prev') {
        newMonth.setMonth(prev.getMonth() - 1);
      } else {
        newMonth.setMonth(prev.getMonth() + 1);
      }
      return newMonth;
    });
  };

  const renderCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentMonth);
    const firstDay = getFirstDayOfMonth(currentMonth);
    const days = [];

    // Previous month's days
    if (showOutsideDays) {
      const prevMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 0);
      for (let i = firstDay - 1; i >= 0; i--) {
        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, prevMonth.getDate() - i);
        days.push(
          <button
            key={`prev-${date.getDate()}`}
            className="h-8 w-8 text-sm text-gray-400 hover:bg-gray-100 rounded"
            onClick={() => handleDateClick(date)}
          >
            {date.getDate()}
          </button>
        );
      }
    } else {
      for (let i = 0; i < firstDay; i++) {
        days.push(<div key={`empty-${i}`} className="h-8 w-8" />);
      }
    }

    // Current month's days
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const isDisabled = disabled && disabled(date);
      const selected = isSelected(date);
      const today = isToday(date);

      days.push(
        <button
          key={day}
          className={`h-8 w-8 text-sm rounded transition-colors ${
            isDisabled 
              ? 'text-gray-400 cursor-not-allowed' 
              : selected
                ? 'bg-[var(--temple-saffron)] text-white'
                : today
                  ? 'bg-gray-100 text-gray-900'
                  : 'hover:bg-gray-100'
          }`}
          onClick={() => handleDateClick(date)}
          disabled={isDisabled}
        >
          {day}
        </button>
      );
    }

    // Next month's days
    if (showOutsideDays) {
      const remainingCells = 42 - days.length; // 6 rows × 7 days
      for (let day = 1; day <= remainingCells; day++) {
        const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, day);
        days.push(
          <button
            key={`next-${day}`}
            className="h-8 w-8 text-sm text-gray-400 hover:bg-gray-100 rounded"
            onClick={() => handleDateClick(date)}
          >
            {day}
          </button>
        );
      }
    }

    return days;
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  return (
    <div className={`p-3 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <button
          className="p-1 hover:bg-gray-100 rounded"
          onClick={() => navigateMonth('prev')}
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        
        <h2 className="text-sm font-medium">
          {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
        </h2>
        
        <button
          className="p-1 hover:bg-gray-100 rounded"
          onClick={() => navigateMonth('next')}
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-2">
        {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
          <div key={day} className="h-8 w-8 text-center text-sm font-normal text-gray-500 flex items-center justify-center">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {renderCalendarDays()}
      </div>
    </div>
  );
};

export { Calendar };