import * as React from "react";

interface RadioGroupProps {
  value?: string;
  onValueChange?: (value: string) => void;
  children: React.ReactNode;
  className?: string;
}

interface RadioGroupItemProps {
  value: string;
  id?: string;
  children?: React.ReactNode;
  className?: string;
}

const RadioGroupContext = React.createContext<{
  value?: string;
  onValueChange?: (value: string) => void;
}>({});

const RadioGroup: React.FC<RadioGroupProps> = ({ value, onValueChange, children, className = '' }) => {
  return (
    <RadioGroupContext.Provider value={{ value, onValueChange }}>
      <div className={`grid gap-3 ${className}`}>
        {children}
      </div>
    </RadioGroupContext.Provider>
  );
};

const RadioGroupItem: React.FC<RadioGroupItemProps> = ({ value, id, className = '' }) => {
  const { value: selectedValue, onValueChange } = React.useContext(RadioGroupContext);
  const isSelected = selectedValue === value;

  return (
    <button
      type="button"
      id={id}
      className={`aspect-square w-4 h-4 shrink-0 rounded-full border border-gray-300 transition-colors focus:outline-none focus:ring-2 focus:ring-[var(--temple-saffron)] focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${
        isSelected ? 'border-[var(--temple-saffron)] bg-[var(--temple-saffron)]' : 'bg-white'
      } ${className}`}
      onClick={() => onValueChange?.(value)}
      role="radio"
      aria-checked={isSelected}
    >
      {isSelected && (
        <div className="flex items-center justify-center w-full h-full">
          <div className="w-2 h-2 bg-white rounded-full" />
        </div>
      )}
    </button>
  );
};

export { RadioGroup, RadioGroupItem };