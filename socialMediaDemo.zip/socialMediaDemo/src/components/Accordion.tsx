import * as React from "react";
import { ChevronDown } from "./icons";

interface AccordionProps {
  type?: 'single' | 'multiple';
  collapsible?: boolean;
  value?: string | string[];
  onValueChange?: (value: string | string[]) => void;
  children: React.ReactNode;
  className?: string;
}

interface AccordionItemProps {
  value: string;
  children: React.ReactNode;
  className?: string;
}

interface AccordionTriggerProps {
  children: React.ReactNode;
  className?: string;
}

interface AccordionContentProps {
  children: React.ReactNode;
  className?: string;
}

const AccordionContext = React.createContext<{
  openItems: string[];
  toggleItem: (value: string) => void;
  type: 'single' | 'multiple';
}>({
  openItems: [],
  toggleItem: () => {},
  type: 'single',
});

const AccordionItemContext = React.createContext<{
  value: string;
  isOpen: boolean;
}>({
  value: '',
  isOpen: false,
});

const Accordion: React.FC<AccordionProps> = ({
  type = 'single',
  collapsible = false,
  value,
  onValueChange,
  children,
  className = ''
}) => {
  const [openItems, setOpenItems] = React.useState<string[]>(() => {
    if (type === 'single') {
      return value ? [value as string] : [];
    }
    return (value as string[]) || [];
  });

  const toggleItem = React.useCallback((itemValue: string) => {
    setOpenItems(prev => {
      let newItems: string[];
      
      if (type === 'single') {
        if (prev.includes(itemValue)) {
          newItems = collapsible ? [] : prev;
        } else {
          newItems = [itemValue];
        }
      } else {
        if (prev.includes(itemValue)) {
          newItems = prev.filter(item => item !== itemValue);
        } else {
          newItems = [...prev, itemValue];
        }
      }
      
      onValueChange?.(type === 'single' ? (newItems[0] || '') : newItems);
      return newItems;
    });
  }, [type, collapsible, onValueChange]);

  return (
    <AccordionContext.Provider value={{ openItems, toggleItem, type }}>
      <div className={className}>
        {children}
      </div>
    </AccordionContext.Provider>
  );
};

const AccordionItem: React.FC<AccordionItemProps> = ({ value, children, className = '' }) => {
  const { openItems } = React.useContext(AccordionContext);
  const isOpen = openItems.includes(value);

  return (
    <AccordionItemContext.Provider value={{ value, isOpen }}>
      <div className={`border-b ${className}`}>
        {children}
      </div>
    </AccordionItemContext.Provider>
  );
};

const AccordionTrigger: React.FC<AccordionTriggerProps> = ({ children, className = '' }) => {
  const { toggleItem } = React.useContext(AccordionContext);
  const { value, isOpen } = React.useContext(AccordionItemContext);

  return (
    <button
      className={`flex flex-1 items-center justify-between py-4 text-left transition-all hover:underline focus:outline-none focus:ring-2 focus:ring-[var(--temple-saffron)] focus:ring-offset-2 ${className}`}
      onClick={() => toggleItem(value)}
    >
      {children}
      <ChevronDown 
        className={`h-4 w-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} 
      />
    </button>
  );
};

const AccordionContent: React.FC<AccordionContentProps> = ({ children, className = '' }) => {
  const { isOpen } = React.useContext(AccordionItemContext);

  return (
    <div 
      className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}
    >
      <div className={`pb-4 pt-0 ${className}`}>
        {children}
      </div>
    </div>
  );
};

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };