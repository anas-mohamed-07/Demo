import * as React from "react";
import { X } from "./icons";

interface SheetProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  children: React.ReactNode;
}

interface SheetContentProps {
  className?: string;
  children: React.ReactNode;
  side?: "top" | "right" | "bottom" | "left";
}

const Sheet: React.FC<SheetProps> = ({ open = false, onOpenChange, children }) => {
  return (
    <>
      {React.Children.map(children, child =>
        React.isValidElement(child) && child.type === SheetTrigger
          ? React.cloneElement(child as React.ReactElement, { onOpenChange })
          : child
      )}
      {React.Children.map(children, child =>
        React.isValidElement(child) && child.type === SheetContent
          ? open ? React.cloneElement(child as React.ReactElement, { onOpenChange }) : null
          : null
      )}
    </>
  );
};

const SheetTrigger: React.FC<{ children: React.ReactNode; onOpenChange?: (open: boolean) => void }> = 
  ({ children, onOpenChange }) => {
    const handleClick = () => {
      onOpenChange?.(true);
    };

    return React.isValidElement(children) 
      ? React.cloneElement(children as React.ReactElement, { onClick: handleClick })
      : <button onClick={handleClick}>{children}</button>;
  };

const SheetOverlay: React.FC<{ onOpenChange?: (open: boolean) => void }> = ({ onOpenChange }) => {
  return (
    <div 
      className="fixed inset-0 z-50 bg-black/50 animate-in fade-in-0"
      onClick={() => onOpenChange?.(false)}
    />
  );
};

const SheetContent: React.FC<SheetContentProps & { onOpenChange?: (open: boolean) => void }> = 
  ({ className = '', children, side = "right", onOpenChange }) => {
    React.useEffect(() => {
      const handleEscape = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          onOpenChange?.(false);
        }
      };
      
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }, [onOpenChange]);

    const sideClasses = {
      right: "inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm animate-in slide-in-from-right",
      left: "inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm animate-in slide-in-from-left",
      top: "inset-x-0 top-0 h-auto border-b animate-in slide-in-from-top",
      bottom: "inset-x-0 bottom-0 h-auto border-t animate-in slide-in-from-bottom"
    };

    return (
      <>
        <SheetOverlay onOpenChange={onOpenChange} />
        <div 
          className={`fixed z-50 bg-white shadow-lg transition-all duration-300 ease-in-out flex flex-col gap-4 ${sideClasses[side]} ${className}`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="relative flex-1">
            <button
              className="absolute top-4 right-4 p-1 rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-500"
              onClick={() => onOpenChange?.(false)}
            >
              <X size={16} />
              <span className="sr-only">Close</span>
            </button>
            {children}
          </div>
        </div>
      </>
    );
  };

const SheetHeader: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <div className={`flex flex-col gap-1.5 p-4 ${className}`}>
      {children}
    </div>
  );

const SheetFooter: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <div className={`mt-auto flex flex-col gap-2 p-4 ${className}`}>
      {children}
    </div>
  );

const SheetTitle: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <h2 className={`text-lg font-semibold ${className}`}>
      {children}
    </h2>
  );

const SheetDescription: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <p className={`text-sm text-gray-600 ${className}`}>
      {children}
    </p>
  );

const SheetClose = SheetTrigger;

export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription,
};