import * as React from "react";
import { X } from "./icons";
// import { X } from "./icons";

interface DialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  children: React.ReactNode;
}

interface DialogContentProps {
  className?: string;
  children: React.ReactNode;
}

const Dialog: React.FC<DialogProps> = ({ open = false, onOpenChange, children }) => {
  return (
    <>
      {React.Children.map(children, child =>
        React.isValidElement(child) && child.type === DialogTrigger
          ? React.cloneElement(child as React.ReactElement, { onOpenChange })
          : child
      )}
      {React.Children.map(children, child =>
        React.isValidElement(child) && child.type === DialogContent
          ? open ? React.cloneElement(child as React.ReactElement, { onOpenChange }) : null
          : null
      )}
    </>
  );
};

const DialogTrigger: React.FC<{ children: React.ReactNode; onOpenChange?: (open: boolean) => void }> = 
  ({ children, onOpenChange }) => {
    const handleClick = () => {
      onOpenChange?.(true);
    };

    return React.isValidElement(children) 
      ? React.cloneElement(children as React.ReactElement, { onClick: handleClick })
      : <button onClick={handleClick}>{children}</button>;
  };

const DialogOverlay: React.FC<{ onOpenChange?: (open: boolean) => void }> = ({ onOpenChange }) => {
  return (
    <div 
      className="fixed inset-0 z-50 bg-black/50 animate-in fade-in-0"
      onClick={() => onOpenChange?.(false)}
    />
  );
};

const DialogContent: React.FC<DialogContentProps & { onOpenChange?: (open: boolean) => void }> = 
  ({ className = '', children, onOpenChange }) => {
    React.useEffect(() => {
      const handleEscape = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          onOpenChange?.(false);
        }
      };
      
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }, [onOpenChange]);

    return (
      <>
        <DialogOverlay onOpenChange={onOpenChange} />
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className={`bg-white rounded-lg border shadow-lg max-w-lg w-full max-h-[90vh] overflow-auto animate-in fade-in-0 zoom-in-95 ${className}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <button
                className="absolute top-4 right-4 p-1 rounded hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-500"
                onClick={() => onOpenChange?.(false)}
              >
                <X size={16} />
                <span className="sr-only">Close</span>
              </button>
              {children}
            </div>
          </div>
        </div>
      </>
    );
  };

const DialogHeader: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <div className={`flex flex-col gap-2 text-center sm:text-left p-6 pb-0 ${className}`}>
      {children}
    </div>
  );

const DialogFooter: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <div className={`flex flex-col-reverse gap-2 sm:flex-row sm:justify-end p-6 pt-0 ${className}`}>
      {children}
    </div>
  );

const DialogTitle: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <h2 className={`text-lg font-semibold leading-none ${className}`}>
      {children}
    </h2>
  );

const DialogDescription: React.FC<{ className?: string; children: React.ReactNode }> = 
  ({ className = '', children }) => (
    <p className={`text-sm text-gray-600 ${className}`}>
      {children}
    </p>
  );

const DialogClose = DialogTrigger;

export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogTitle,
  DialogTrigger,
};