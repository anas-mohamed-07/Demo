import React from 'react';
import { Route, Routes, Navigate } from 'react-router-dom'; 
import AuthLandingPage from '../AuthLandingPage/AuthLandingPage';
import ResetPasswordPage from '../ResetPasswordPage/ResetPasswordPage';
import SignupPage from '../SignupPage/SignupPage';
import PostMessagesPage from '../PostMessagesPage/PostMessagesPage';

function Routeres() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<AuthLandingPage />} />
        <Route path="/reset" element={<ResetPasswordPage />} />
        <Route path="/SignupPage" element={<SignupPage />} />
        <Route path="/PostMessagesPage"  element={<PostMessagesPage />} />
      </Routes>
    </div>
  );
}

export default Routeres;
