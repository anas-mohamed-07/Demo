import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./AuthLandingPage.css";
import { API_URL } from "../config";

export default function AuthLandingPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      setMessage("Please fill all fields.");
      return;
    }

    try {
      const res = await fetch(`${API_URL}/login.php`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      const result = await res.json();
      setMessage(result.message);

      if (result.status === "success") {
        localStorage.removeItem("auth");

        const encryptedPassword = btoa(formData.password); 
        const authData = formData.email

        localStorage.setItem("auth", JSON.stringify(authData));

        setTimeout(() => {
          navigate("/PostMessagesPage");
        }, 3000);
      }
    } catch (error) {
      setMessage("Something went wrong. Try again.");
    }
  };

  const togglePasswordVisibility = () => setShowPassword(!showPassword);
  const handleReset = () => navigate("/reset");
  const goToSignup = () => navigate("/SignupPage");

  return (
    <div className="auth-container">
      <div className="auth-box">
        <div className="form-wrapper">
          <h2 className="form-title">Welcome Back!</h2>

          <form className="auth-form" onSubmit={handleSubmit}>
            <input
              type="email"
              placeholder="Email"
              className="auth-input"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />
            <div className="password-wrapper">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                className="auth-input password-input"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
              />
              <span className="toggle-password" onClick={togglePasswordVisibility}>
                {showPassword ? "🙈" : "👁️"}
              </span>
            </div>
            <button type="submit" className="auth-submit">Login</button>
          </form>

          {message && <p className="form-message">{message}</p>}

          <p className="forgot-text" onClick={handleReset}>
            Forgot password? <span className="reset-link">Reset</span>
          </p>

          <p className="signup-link">
            Don’t have an account?{" "}
            <span onClick={goToSignup} style={{ color: "#4CAF50", cursor: "pointer" }}>
              Signup
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
