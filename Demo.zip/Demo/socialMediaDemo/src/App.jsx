import React from 'react'
import Routeres from './Routeres/Routeres'
import { BrowserRouter } from 'react-router-dom'
import "./App.css"

function App() {
  return (
    <BrowserRouter>
      <Routeres/>
    </BrowserRouter>
  )
}

export default App
