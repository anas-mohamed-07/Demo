
const API_URL = "http://localhost/task";
export { API_URL };
