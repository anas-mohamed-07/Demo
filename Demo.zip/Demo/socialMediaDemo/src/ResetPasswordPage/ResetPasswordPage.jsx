  import { useState } from "react";
  import "./ResetPasswordPage.css";
  import { useNavigate } from "react-router-dom";
  import { API_URL } from "../config";

  export default function ResetPasswordPage() {
    const [email, setEmail] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [message, setMessage] = useState(""); 
    const [messageType, setMessageType] = useState(""); 

    const Navigate = useNavigate();

    const handleSubmit = async (e) => {
      e.preventDefault();
      if (newPassword !== confirmPassword) {
        setMessage("Passwords do not match!");
        setMessageType("error"); 
        return;
      }
    
      try {
        const response = await fetch(`${API_URL}/resetPassword.php`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, newPassword }),
        });
    
        const result = await response.json();
        if (result.status === "success") {
          setMessage(result.message);
          setMessageType("success"); 
          setEmail("");
          setNewPassword("");
          setConfirmPassword("");
          Navigate("/")
        } else {
          setMessage(result.message);
          setMessageType("error");
        }
      } catch (error) {
        console.error("Error resetting password:", error);
        setMessage("Something went wrong.");
        setMessageType("error"); 
      }
    };
    
    return (
      <div className="auth-container">
        <div className="auth-box">
          <div className="form-wrapper">
            <h2 className="form-title">Reset Your Password</h2>

            <form className="auth-form" onSubmit={handleSubmit}>
              <input
                type="email"
                placeholder="Enter your email"
                className="auth-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <div className="password-wrapper">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="New Password"
                  className="auth-input password-input"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
                <span
                  className="toggle-password"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? "🙈" : "👁️"}
                </span>
              </div>
              <div className="password-wrapper">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Confirm New Password"
                  className="auth-input password-input"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
                <span
                  className="toggle-password"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? "🙈" : "👁️"}
                </span>
              </div>
              <button type="submit" className="auth-submit">
                Reset Password
              </button>
            </form>

            {message && (
              <div
                className={`message ${messageType === "success" ? "success" : "error"}`}
              >
                {message}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
