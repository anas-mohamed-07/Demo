import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { API_URL } from "../config";
import "./SignupPage.css";

export default function SignupPage() {
  const [formData, setFormData] = useState({
    profilePic: null,
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    mobile: "",
    isPrivate: false,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleProfilePicChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prevData) => ({
          ...prevData,
          profilePic: reader.result,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCheckboxChange = (e) => {
    setFormData((prevData) => ({
      ...prevData,
      isPrivate: e.target.checked,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { username, email, password, confirmPassword, mobile, profilePic, isPrivate } = formData;

    if (!username || !email || !password || !confirmPassword || !mobile || !profilePic) {
      setMessage("Please fill in all fields.");
      return;
    }

    if (password !== confirmPassword) {
      setMessage("Passwords do not match.");
      return;
    }

    try {
      const response = await fetch(`${API_URL}/signup.php`, { 
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, email, password, mobile, profilePic, isPrivate }),
      });

      const result = await response.json();

      if (result.status === "success") {
        setMessage("Signup successful!");
        navigate("/");
      } else {
        setMessage(result.message);
      }
    } catch (error) {
      setMessage("Error connecting to the server.");
      console.error(error);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <div className="form-wrapper">
          <h2 className="form-title">Create Your Account</h2>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="profile-pic-wrapper">
              <label htmlFor="profile-pic" className="profile-pic-label">
                {formData.profilePic ? (
                  <img src={formData.profilePic} alt="Profile Preview" className="profile-pic" />
                ) : (
                  <span className="profile-pic-placeholder">+ Upload</span>
                )}
              </label>
              <input
                type="file"
                id="profile-pic"
                className="auth-input profile-pic-input"
                onChange={handleProfilePicChange}
                accept="image/*"
              />
            </div>

            <input
              type="text"
              placeholder="Username"
              className="auth-input"
              name="username"
              value={formData.username}
              onChange={handleInputChange}
            />

            <input
              type="email"
              placeholder="Email"
              className="auth-input"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />

            <div className="password-wrapper">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                className="auth-input password-input"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
              />
              <span
                className="toggle-password"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>

            <div className="password-wrapper">
              <input
                type={showConfirmPassword ? "text" : "password"}
                placeholder="Confirm Password"
                className="auth-input password-input"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
              />
              <span
                className="toggle-password"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>

            <input
              type="tel"
              placeholder="Mobile Number"
              className="auth-input"
              name="mobile"
              value={formData.mobile}
              onChange={handleInputChange}
            />

            <div className="checkbox-wrapper">
              <label>
                <input
                  type="checkbox"
                  checked={formData.isPrivate}
                  onChange={handleCheckboxChange}
                />
                Make this a private account
              </label>
            </div>

            <button type="submit" className="auth-submit">Sign Up</button>
          </form>

          {message && <p className="form-message">{message}</p>}
        </div>
      </div>
    </div>
  );
}
