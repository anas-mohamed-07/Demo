import { useState, useEffect } from "react";
import "./PostMessagesPage.css";
import { useNavigate } from "react-router-dom";
import { API_URL } from "../config";

export default function PostMessagesPage() {
  const [postContent, setPostContent] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [message, setMessage] = useState("");
  const [activeView, setActiveView] = useState("createPost");
  const [profileData, setProfileData] = useState(null);
  const [posts, setPosts] = useState([]);
  const [editingPostId, setEditingPostId] = useState(null);
  const [editContent, setEditContent] = useState("");
  const [editIsPublic, setEditIsPublic] = useState(true);

  const Navigate = useNavigate();

  const email = localStorage.getItem("auth")?.replace(/^"|"$/g, "");

  const showPosts = () => {
    setActiveView("showPosts");

    fetch(`${API_URL}/getPublicPosts.php`)
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          setPosts(data.posts);
        } else {
          setMessage("Failed to fetch posts.");
        }
      })
      .catch((error) => {
        console.error("Error fetching public posts:", error);
        setMessage("Error fetching posts.");
      });
  };

  const showMyPosts = () => {
    setActiveView("showMyPosts");

    fetch(`${API_URL}/getMyPosts.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          setPosts(data.posts);
        } else {
          setMessage("Failed to fetch your posts.");
        }
      })
      .catch((error) => {
        console.error("Error fetching your posts:", error);
        setMessage("Error fetching your posts.");
      });
  };

  const showProfile = () => {
    setActiveView("showProfile");
  };

  const handleLogout = () => {
    localStorage.clear();
    Navigate("/");
  };

  useEffect(() => {
    if (activeView === "showProfile") {
      if (email) {
        fetch(`${API_URL}/getUserProfile.php`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        })
          .then((response) => response.json())
          .then((result) => {
            if (result.status === "success") {
              setProfileData(result.data);
            } else {
              setMessage("Failed to load profile.");
            }
          })
          .catch((error) => {
            console.error("Error fetching profile:", error);
            setMessage("Error fetching profile.");
          });
      } else {
        setMessage("No email found in local storage.");
      }
    }
  }, [activeView]);

  const handlePostSubmit = async (e) => {
    e.preventDefault();
    if (postContent.trim() === "") {
      setMessage("Please enter a message.");
      return;
    }

    const response = await fetch(`${API_URL}/createPost.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        content: postContent,
        is_public: isPublic ? 1 : 0,
      }),
    });

    const result = await response.json();

    if (result.status === "success") {
      const newPost = {
        content: postContent,
        isPublic,
        id: Date.now(),
        username: profileData?.name || "You",
      };
      setPosts([newPost, ...posts]);
      setPostContent("");
      setMessage("Post submitted successfully!");
    } else {
      setMessage(result.message || "Error posting message.");
    }
  };

  const startEditing = (post) => {
    setEditingPostId(post.id);
    setEditContent(post.content);
    setEditIsPublic(post.isPublic);
  };

  const saveEditedPost = () => {
    fetch(`${API_URL}/updatePost.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        post_id: editingPostId,
        email,
        content: editContent,
        is_public: editIsPublic ? 1 : 0,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.status === "success") {
          const updatedPosts = posts.map((post) =>
            post.id === editingPostId
              ? { ...post, content: editContent, isPublic: editIsPublic }
              : post
          );
          setPosts(updatedPosts);
          setEditingPostId(null);
          setMessage("Post updated!");
        } else {
          setMessage("Failed to update post.");
        }
      })
      .catch((err) => {
        console.error(err);
        setMessage("Error updating post.");
      });
  };

  const cancelEdit = () => {
    setEditingPostId(null);
    setEditContent("");
    setEditIsPublic(true);
  };

  const [door, setDoor] = useState("");



  return (
    <div className="post-container">
      <div className="buttons-container">
      <button
  className={`page-btn ${door === "createPost" ? "active" : ""}`}
  onClick={() => setDoor("createPost")}
>
  Create Post
</button>

<button
  className={`page-btn ${door === "showAllPosts" ? "active" : ""}`}
  onClick={() => {
    showPosts();
    setDoor("showAllPosts");
  }}
>
  Show All Posts
</button>

<button
  className={`page-btn ${door === "showMyPosts" ? "active" : ""}`}
  onClick={() => {
    showMyPosts();
    setDoor("showMyPosts");
  }}
>
  Show My Posts
</button>

<button
  className={`page-btn ${door === "showProfile" ? "active" : ""}`}
  onClick={() => {
    showProfile();
    setDoor("showProfile");
  }}
>
  Show Profile
</button>

<button className="page-btn" onClick={handleLogout}>
  Log Out
</button>

      </div>

      {activeView === "createPost" && (
        <div className="post-box">
          <h2>Create a Post</h2>
          <form className="post-form" onSubmit={handlePostSubmit}>
            <textarea
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder="Write your message..."
              className="post-input"
            ></textarea>

            <div>
              <input
                type="checkbox"
                checked={isPublic}
                onChange={() => setIsPublic(!isPublic)}
                id="privacy-toggle"
              />
              <label htmlFor="privacy-toggle" className="privacy-label">
                Public Post
              </label>
            </div>

            <button type="submit" className="post-submit">
              Submit Post
            </button>
          </form>

          {message && <p className="message">{message}</p>}
        </div>
      )}

      {(activeView === "showPosts" || activeView === "showMyPosts") && (
        <div className="post-feed-wrapper">
          <div className="posts">
            {posts.length > 0 ? (
              posts.map((post) => (
                <div key={post.id} className="post-card">
                  {editingPostId === post.id ? (
                    <>
                      <textarea
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        className="post-input"
                      />
                      <div className="privacy-toggle">
                        <input
                          type="checkbox"
                          checked={editIsPublic}
                          onChange={() => setEditIsPublic(!editIsPublic)}
                          id={`edit-toggle-${post.id}`}
                        />
                        <label htmlFor={`edit-toggle-${post.id}`} className="privacy-label">
                          Public Post
                        </label>
                      </div>
                      <button onClick={saveEditedPost} className="post-submit">
                        Save
                      </button>
                      <button onClick={cancelEdit} className="post-cancel">
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <div className="post-header">
                        <span className="post-username">@{post.username}</span>
                        <span
                          className={`post-visibility ${
                            post.isPublic ? "visible-public" : "visible-private"
                          }`}
                        >
                          {post.isPublic ? "🌐 Public" : "🔒 Private"}
                        </span>
                      </div>
                      <p className="post-text">{post.content}</p>
                      {activeView === "showMyPosts" && (
                        <span
                        style={{
                          position: "absolute",
                          bottom: "10px",
                          right: "15px",
                          cursor: "pointer",
                          fontSize: "18px",
                        }}
                        title="Edit Post"
                        onClick={() => startEditing(post)}
                      >
                        ✏️
                      </span>
                      )}
                    </>
                  )}
                </div>
              ))
            ) : (
              <p className="no-posts">No posts yet. Start writing!</p>
            )}
          </div>
        </div>
      )}

      {activeView === "showProfile" && profileData && (
        <div className="ig-profile-container">
          <div className="ig-profile-card">
            <div className="ig-profile-image-wrapper">
              <img
                src={profileData.profile_pic}
                alt="Profile"
                className="ig-profile-image"
              />
            </div>
            <div className="ig-profile-info">
              <h2 className="ig-profile-name">{profileData.name}</h2>
              <p className="ig-profile-username">{profileData.username}</p>
              <p className="ig-profile-email">Email: {profileData.email}</p>
              <p className="ig-profile-mobile">Mobile: {profileData.mobile}</p>
              <p className="ig-profile-date">Joined: {profileData.created_at}</p>
            </div>
            <div className="ig-profile-stats">
              <div className="ig-profile-stat-box">
                <span className="ig-stat-count">{profileData.post_count}</span>
                <span className="ig-stat-label">Posts</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeView === "showProfile" && !profileData && <p>Loading profile...</p>}
    </div>
  );
}
