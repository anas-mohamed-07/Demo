<?php
require_once 'headers.php';
require_once 'db.php';

$input = json_decode(file_get_contents("php://input"), true);

$donorName = trim($input['donorName'] ?? '');
$dob = trim($input['dob'] ?? '');
$mobile = trim($input['mobile'] ?? '');
$email = trim($input['email'] ?? '');
$gender = trim($input['gender'] ?? '');
$address = trim($input['address'] ?? '');
$amount = trim($input['amount'] ?? '');
$purpose = trim($input['purpose'] ?? 'general');


if (
    empty($donorName) || empty($dob) || empty($mobile) || empty($email) ||
    empty($gender) || empty($address) || empty($amount) || empty($purpose)
) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit();
}


$query = "SELECT id FROM users WHERE email = ? AND phonenumber = ? LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $email, $mobile);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $userId = $user['id'];
} else {
    $insertUser = "INSERT INTO users (name, phonenumber, dob, email, gender, address)
                   VALUES (?, ?, ?, ?, ?, ?)";
    $userStmt = $conn->prepare($insertUser);
    $userStmt->bind_param("ssssss", $donorName, $mobile, $dob, $email, $gender, $address);

    if (!$userStmt->execute()) {
        echo json_encode(["status" => "error", "message" => "Failed to insert user"]);
        exit();
    }

    $userId = $userStmt->insert_id;
    $userStmt->close();
}


$today = date("Y-m-d");
$insertPayment = "INSERT INTO payments (user_id, purpose, amount, date)
                  VALUES (?, ?, ?, ?)";
$paymentStmt = $conn->prepare($insertPayment);
$paymentStmt->bind_param("isds", $userId, $purpose, $amount, $today);

if ($paymentStmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Donation recorded successfully"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to record donation"]);
}

$stmt->close();
$paymentStmt->close();
$conn->close();
?>
